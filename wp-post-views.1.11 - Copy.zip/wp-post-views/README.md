# wp-post-views

use Docker To use this Plugin setup. (Not Compulasory)

```
   $ git clone https://github.com/vanpariyar/wp-post-views.git
   $ cd wp-post-views
   $ docker-compose up -d
```
Goto : [localhost:9999/](http://localhost:9999/)

Live URL: https://wordpress.org/plugins/wp-post-views/

This is the simple plugin that counts the views of the your wordpress website and store the views in the database

For this repository i would like to give full credits to [AnkitaTanti](https://github.com/AnkitaTanti).

Contribution is highly appriciated.

### For contribution make the saperate branch.
NOTE : Make sure we are Developing the Plugin.:sweat_smile:
Please Don't upload Whole wordpress setup.

## Features:
- We have option to show views count in the post coloumn.
- (You can disable this)All views are filterd with IP address. To just make sure get right count
-Support for the Custom post type by selecting menually in settings.

INSTALLATION :

1) Upload the plugin in to your wp-content > Plugins folder
2) You can change plugin settings in Admin panel > Settings > Wp Post View Settings
3) There are some options are by default selected for you but you can Change it. 

That's it Thanks.
