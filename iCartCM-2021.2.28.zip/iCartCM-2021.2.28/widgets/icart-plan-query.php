<?php
namespace iCart\ Widgets;

use Elementor\ Widget_Base;
use Elementor\ Controls_Manager;
use Elementor\ Core\ Schemes;
use Elementor\ Group_Control_Border;
use Elementor\ Group_Control_Box_Shadow;
use Elementor\ Group_Control_Typography;
use Elementor\ Icons_Manager;
use Elementor\ Repeater;
use ElementorPro\ Base\ Base_Widget;

if ( !defined( 'ABSPATH' ) )exit; // Exit if accessed directly

/**
 * iCart Plan Query
 *
 * Elementor widget for iCart Plan Query.
 *
 * @since 1.0.0
 */
class iCart_Plan_Query extends Widget_Base {

  public function get_name() {
    return 'iCart_Plan_Query';
  }



  public function get_title() {
    return __( 'iCart Plan Query', 'icart-plan-query' );
  }


  public function get_icon() {
    return 'eicon-columns';
  }

  public function get_categories() {
    return [ 'general' ];
  }


  public function get_script_depends() {
    return [ 'icart-plan-query' ];
  }




  protected function _register_controls() {  




    $primaryColor = "#000000";
    if(get_option('iCart_abc_color_primary1')){
     $primaryColor =  get_option('iCart_abc_color_primary1');
    }
      $primaryColor2 = "#999999";
    if(get_option('iCart_abc_color_primary2')){
     $primaryColor2 =  get_option('iCart_abc_color_primary2');
    }
    $subHeader = "";
    if(get_post_meta( get_the_ID(), 'subHeader', true )){
        $subHeader =  get_post_meta( get_the_ID(), 'subHeader', true );
    }

    $footerText = "";
    if(get_post_meta( get_the_ID(), 'footerText', true )){
     $footerText =  get_post_meta( get_the_ID(), 'clubAccessFooter', true ) . '<br><br>' . get_post_meta( get_the_ID(), 'clubFeeFooter', true );
    }
    $titleFilter = "";
    if($_GET['titleFilter']){
     $titleFilter =  $_GET['titleFilter'];
    }
    $typeFilter = "";
    if($_GET['$typeFilter']){
     $typeFilter =  $_GET['$typeFilter'];
    }
    if(isset($_GET['promoCode'])){
        $promoCode = $_GET['promoCode'];
        $typeFilter =  "";
    } else {
        $promoCode = "";
    }
    if(get_post_meta( get_the_ID(), 'clubNumber', true )){
        $clubNumber = get_post_meta( get_the_ID(), 'clubNumber', true );
    } else if($_GET['club']) {
        $clubNumber = $_GET['club'];
    } else {
        $clubNumber = get_option( 'iCart_abc_clubNumber');
    }
    $campaignIds = ABCCampaignIds($clubNumber);
    //$campaignArray = ABCCampaignArray();


    $this->start_controls_section(
      'section_content', [
        'label' => __( 'Content', 'icart' ),
      ]
    );
    $this->add_control(
      'clubNumber', [
        'label' => __( 'Club Number', 'icart' ),
        'type' => Controls_Manager::TEXT,
        'default' => __( $clubNumber, 'icart' ),
          'dynamic' => [
					'active' => true,
				],
      ]
    );
      $this->add_control(
      'colNumber', [
        'label' => __( 'Column Number', 'icart' ),
        'type' => Controls_Manager::TEXT,
        'default' => __( '3', 'icart' ),

      ]
    );
    $this->add_control(
      'titleFilter', [
        'label' => __( 'Title Filter', 'icart' ),
        'type' => Controls_Manager::TEXT,
        'default' => __( $titleFilter, 'icart' ),

      ]
    );
    $this->add_control(
      'typeFilter', [
        'label' => __( 'Membership Type Filter', 'icart' ),
        'type' => Controls_Manager::TEXT,
        'default' => __( $typeFilter, 'icart' ),

      ]
    );

	  $this->add_control(
			'orderby',
			[
				'label' => __( 'Order By', 'icart' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
                            'title' => __( 'Plan Name', 'icart' ),
                            'date' => __( 'Publish Date', 'icart' ),
                            'rand' => __( 'Randomize', 'icart' ),
                            'meta_value' => __( 'Price', 'icart' ),


                        ],
			]
		);

	  $this->add_control(
			'ordersort',
			[
				'label' => __( 'Sort', 'icart' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'ASC',
				'options' => [
                            'ASC' => __( 'Ascending Order', 'icart' ),
                            'DESC' => __( 'Descending Order', 'icart' )


                        ],
			]
		);


    $this->add_control(
      'promoCode', [
        'label' => __( 'Promo Code (optional)', 'icart' ),
        'type' => Controls_Manager::HIDDEN,
          'default' => $promoCode,
      ]
    );

      $this->add_control(
			'campaignId',
			[
				'label' => __( 'Campaign', 'icart' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => $campaignIds,
			]
		);
  

    $this->end_controls_section();



     $this->start_controls_section(
			'section_features',
			[
				'label' => __( 'Amenities', 'icart' ),
			]
		);
     $repeater = new Repeater();
     $this->add_control(
			'amenities',
			[
				'label' => __( 'Amenities', 'icart' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'amenity_name',
						'label' => __( 'Name', 'icart' ),
                       'label_block' => true,
                        'default' => 'Amenity Name',
						'type' => Controls_Manager::TEXT,
					],
					[
						'name' => 'amenity_search',
						'label' => __( 'If', 'icart' ),
                        'options' => [
                            'all' => __( 'Available on all plans', 'icart' ),
                            'planName' => __( 'If Plan Name', 'icart' ),
                            'clubNumber' => __( 'If Club Number', 'icart' ),
                            'membershiptype' => __( 'If Membership Type', 'icart' ),
                            'promoCode' => __( 'If Promocode', 'icart' ),
                        ],

                        'default' => 'all',
						'type' => Controls_Manager::SELECT,

					],
                    [
						'name' => 'amenity_condition',
						'label' => __( 'Condition', 'icart' ),
                        'options' => [
                            'LIKE' => __( 'Contains', 'icart' ),
                            'NOT LIKE' => __( 'Does Not Contain', 'icart' ),
                        ],
                        'default' => 'LIKE',

						'type' => Controls_Manager::SELECT,
                        'condition' => [
                            'amenity_search!' => 'all',
                        ],
					],
                    [
						'name' => 'amenity_string',
						'label' => __( 'String', 'icart' ),

						'type' => Controls_Manager::TEXT,
                        'condition' => [
                            'amenity_search!' => 'all',
                        ],
					],
                    [
						'name' => 'amenity_display',
						'label' => __( 'Display', 'icart' ),
                        'options' => [
                            'available' => __( 'Show available amenity', 'icart' ),
                            'unavailable' => __( 'Show faded amenity', 'icart' ),
                            'hidden' => __( 'Hide amenity completely', 'icart' ),
                        ],
                        'default' => 'available',
						'type' => Controls_Manager::SELECT,
                        'condition' => [
                            'amenity_search!' => 'all',
                        ],
					],


				],
				'title_field' => '{{{amenity_name}}}',
			]
		);
 $this->end_controls_section();





      $this->start_controls_section(
			'section_pricing',
			[
				'label' => __( 'Pricing', 'icart' ),
			]
		);



		$this->add_control(
			'price',
			[
				'label' => __( 'Price', 'icart' ),
				'type' => Controls_Manager::HIDDEN,
				'default' => '39.99',
				'dynamic' => [
					'active' => true,
				],
			]
		);
    $this->add_control(
      'price_control',
      [
        'label' => __( 'Main Price Source', 'icart' ),
        'description' => __( 'This is the big price value.', 'icart' ),
        'type' => Controls_Manager::SELECT,
        'label_block' => true,
        'options' => [
          'postdata' => __( 'Default - post monthlyFee field', 'icart' ),
          'liverecurring' => __( 'Live recurring fee - pull from ABC in real time', 'icart' ),
          'liveenrollment' => __( 'Live enrollment fee - pull from ABC in real time', 'icart' ),
          'customvalue' => __( 'Custom value as specified:', 'icart' ),
        ],
        'default' => 'postdata',
        
      ]
    );
      $this->add_control(
    'price_override',
    [
      'label' => __( 'Price Override', 'icart' ),
      'type' => Controls_Manager::TEXT,
      'default' => __( '0.00', 'icart' ),
      'condition' => [
         'price_control' => 'customvalue',
      ],
      'dynamic' => [
        'active' => true,
      ],
    ]
  );
      $this->add_control(
			'frequency_control',
			[
                'label' => __( 'Frequency source', 'icart' ),
                'type' => Controls_Manager::SELECT,
                'description' => __( 'This is the text under the big price.', 'icart' ),
                'label_block' => true,
                'options' => [
                  'postdata' => __( 'Default - post frequency field', 'icart' ),
                  'livefrequency' => __( 'Live frequency - pull from ABC in real time', 'icart' ),
                  'customvalue' => __( 'Custom text as specified:', 'icart' ),
                ],
                'default' => 'postdata',

              ]
            );
      $this->add_control(
			'period',
			[
				'label' => __( 'Custom Frequency Override', 'elementor-pro' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Monthly', 'elementor-pro' ),
                 'condition' => [
                     'frequency_control' => 'customvalue',
                  ],
                'dynamic' => [
					'active' => true,
				],
			]
		);
        
    
      $this->add_control(
			'enrollment_control',
			[
                'label' => __( 'Subhead source', 'icart' ),
                'description' => __( 'This is the text under the plan title, usually the enrollment fee.', 'icart' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                  'postdata' => __( 'Default - post downPaymentTotalAmount field', 'icart' ),
                  'liveenrollment' => __( 'Live down payment total - pull from ABC in real time', 'icart' ),
                  'customvalue' => __( 'Custom value as specified:', 'icart' ),
                ],
                'default' => 'postdata',

              ]
            );

       $this->add_control(
			'sub_heading',
			[
				'label' => __( 'Custom Subheading', 'icart' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( $subHeader, 'icart' ),
                'condition' => [
                     'enrollment_control' => 'customvalue',
                  ],
                'dynamic' => [
					'active' => true,
				],
			]
		);
      $this->add_control(
			'show_enrollment_after',
			[
				'label' => __( 'Text After Amount', 'icart' ),
				'type' => Controls_Manager::TEXT,
				'default' => ' To Enroll',
                'condition' => [
                            'enrollment_control!' => 'customvalue',
                        ],
			]
		);
      
      
      
      
      
		$this->add_control(
			'currency_format',
			[
				'label' => __( 'Currency Format', 'icart' ),
				'type' => Controls_Manager::HIDDEN,
				'options' => [
					'' => '1,234.56 (Default)',
					',' => '1.234,56',
				],
			]
		);
      



		$this->end_controls_section();



		$this->start_controls_section(
			'section_footer',
			[
				'label' => __( 'Footer', 'icart' ),
			]
		);

		$this->add_control(
			'button_text',
			[
				'label' => __( 'Button Text', 'icart' ),
				'type' => Controls_Manager::TEXT,
                'description' => __( 'Type CLUBFEE in all caps to make the annual club fee appear within your content', 'icart' ),
				'default' => __( 'Click Here', 'icart' ),
			]
		);






		$this->add_control(
			'footer_additional_info',
			[
				'label' => __( 'Additional Info', 'icart' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __( $footerText, 'icart' ),
				'rows' => 3,
                'dynamic' => [
					'active' => true,
				],
			]
		);



		$this->end_controls_section();

		$this->start_controls_section(
			'section_ribbon',
			[
				'label' => __( 'Ribbon', 'icart' ),
			]
		);

		$this->add_control(
			'show_ribbon',
			[
				'label' => __( 'Show', 'icart' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'ribbon_title',
			[
				'label' => __( 'Title', 'icart' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( $downPaymentTotalAmountString, 'icart' ),
				'condition' => [
					'show_ribbon' => 'yes',
				],
                'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'ribbon_horizontal_position',
			[
				'label' => __( 'Position', 'icart' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'icart' ),
						'icon' => 'eicon-h-align-left',
					],
					'right' => [
						'title' => __( 'Right', 'icart' ),
						'icon' => 'eicon-h-align-right',
					],
				],
				'condition' => [
					'show_ribbon' => 'yes',
				],
			]
		);
      $this->add_control(
			'ribbon_query',
			[
				'label' => __( 'Show if plan name contains...', 'icart' ),
				'type' => Controls_Manager::TEXT,
				'condition' => [
					'show_ribbon' => 'yes',
				],
			]
		);

		$this->end_controls_section();
      $this->start_controls_section(
			'section_header_style',
			[
				'label' => __( 'Header', 'icart' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			]
		);

		$this->add_control(
			'header_bg_color',
			[
				'label' => __( 'Background Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Schemes\Color::get_type(),
					'value' => Schemes\Color::COLOR_2,
				],
                'default' => __( $primaryColor, 'icart' ),
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__header' => 'background-color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
			'body_bg_color',
			[
				'label' => __( 'Body Background Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Schemes\Color::get_type(),
					'value' => Schemes\Color::COLOR_2,
				],
                'default' => __( '#ffffff', 'icart' ),
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table' => 'background-color: {{VALUE}}',
				],
			]
		);


      $this->add_group_control(
			Group_Control_Border::get_type(), [
				'name' => 'box_border',
                'label' => __( 'Box Border', 'icart' ),
				'selector' => '{{WRAPPER}} .elementor-widget-price-table',
				'separator' => 'before',
			]
		);
$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'plan_shadow',
				'selector' => '{{WRAPPER}} .planShadow',
			]
		);




		$this->add_responsive_control(
			'header_padding',
			[
				'label' => __( 'Padding', 'icart' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_heading_style',
			[
				'label' => __( 'Title', 'icart' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'heading_color',
			[
				'label' => __( 'Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__heading' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',
				'selector' => '{{WRAPPER}} .elementor-price-table__heading',
				'scheme' => Schemes\Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'heading_sub_heading_style',
			[
				'label' => __( 'Sub Title', 'icart' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'sub_heading_color',
			[
				'label' => __( 'Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sub_heading' => 'color: {{VALUE}}',
				],
                'default'  => '#FFFFFF',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sub_heading_typography',
				'selector' => '{{WRAPPER}} .icart_subhead',
				'scheme' => Schemes\Typography::TYPOGRAPHY_1,
			]
		);

		$this->end_controls_section();
      $this->start_controls_section(
			'section_promoCode_style',
			[
				'label' => __( 'Promo Code Style', 'icart' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			]
		);

		$this->add_control(
			'promocode_bg_color',
			[
				'label' => __( 'Valid Promocode Background', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Schemes\Color::get_type(),
					'value' => Schemes\Color::COLOR_2,
				],
                'default' => __( $primaryColor, 'icart' ),
				'selectors' => [
					'{{WRAPPER}} .promocode_bg_color' => 'background-color: {{VALUE}}',
				],
			]
		);

      $this->add_control(
			'promocode_heading_color',
			[
				'label' => __( 'Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .promocode_heading_color' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'promocode_heading_typography',
				'selector' => '{{WRAPPER}} .promocode_heading_typography',
				'scheme' => Schemes\Typography::TYPOGRAPHY_1,
			]
		);
		$this->end_controls_section();
      $this->start_controls_section(
			'section_pricing_element_style',
			[
				'label' => __( 'Pricing', 'icart' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			]
		);

		$this->add_control(
			'pricing_element_bg_color',
			[
				'label' => __( 'Background Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__price' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'pricing_element_padding',
			[
				'label' => __( 'Padding', 'icart' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'price_color',
			[
				'label' => __( 'Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__currency, {{WRAPPER}} .elementor-price-table__integer-part, {{WRAPPER}} .elementor-price-table__fractional-part' => 'color: {{VALUE}}',
				],
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_typography',
				'selector' => '{{WRAPPER}} .elementor-price-table__price',
				'scheme' => Schemes\Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'heading_currency_style',
			[
				'label' => __( 'Currency Symbol', 'icart' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'currency_symbol!' => '',
				],
			]
		);

		$this->add_control(
			'currency_size',
			[
				'label' => __( 'Size', 'icart' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__currency' => 'font-size: calc({{SIZE}}em/100)',
				],
				'condition' => [
					'currency_symbol!' => '',
				],
			]
		);

		$this->add_control(
			'currency_position',
			[
				'label' => __( 'Position', 'icart' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => 'before',
				'options' => [
					'before' => [
						'title' => __( 'Before', 'icart' ),
						'icon' => 'eicon-h-align-left',
					],
					'after' => [
						'title' => __( 'After', 'icart' ),
						'icon' => 'eicon-h-align-right',
					],
				],
			]
		);

		$this->add_control(
			'currency_vertical_position',
			[
				'label' => __( 'Vertical Position', 'icart' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'top' => [
						'title' => __( 'Top', 'icart' ),
						'icon' => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => __( 'Middle', 'icart' ),
						'icon' => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => __( 'Bottom', 'icart' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'default' => 'top',
				'selectors_dictionary' => [
					'top' => 'flex-start',
					'middle' => 'center',
					'bottom' => 'flex-end',
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__currency' => 'align-self: {{VALUE}}',
				],
				'condition' => [
					'currency_symbol!' => '',
				],
			]
		);

		$this->add_control(
			'fractional_part_style',
			[
				'label' => __( 'Fractional Part', 'icart' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'fractional-part_size',
			[
				'label' => __( 'Size', 'icart' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__fractional-part' => 'font-size: calc({{SIZE}}em/100)',
				],
			]
		);

		$this->add_control(
			'fractional_part_vertical_position',
			[
				'label' => __( 'Vertical Position', 'icart' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'top' => [
						'title' => __( 'Top', 'icart' ),
						'icon' => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => __( 'Middle', 'icart' ),
						'icon' => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => __( 'Bottom', 'icart' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'default' => 'top',
				'selectors_dictionary' => [
					'top' => 'flex-start',
					'middle' => 'center',
					'bottom' => 'flex-end',
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__after-price' => 'justify-content: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'heading_original_price_style',
			[
				'label' => __( 'Original Price', 'icart' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'sale' => 'yes',
					'original_price!' => '',
				],
			]
		);

		$this->add_control(
			'original_price_color',
			[
				'label' => __( 'Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Schemes\Color::get_type(),
					'value' => Schemes\Color::COLOR_2,
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__original-price' => 'color: {{VALUE}}',
				],
				'condition' => [
					'sale' => 'yes',
					'original_price!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'original_price_typography',
				'selector' => '{{WRAPPER}} .elementor-price-table__original-price',
				'scheme' => Schemes\Typography::TYPOGRAPHY_1,
				'condition' => [
					'sale' => 'yes',
					'original_price!' => '',
				],
			]
		);

		$this->add_control(
			'original_price_vertical_position',
			[
				'label' => __( 'Vertical Position', 'icart' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'top' => [
						'title' => __( 'Top', 'icart' ),
						'icon' => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => __( 'Middle', 'icart' ),
						'icon' => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => __( 'Bottom', 'icart' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'selectors_dictionary' => [
					'top' => 'flex-start',
					'middle' => 'center',
					'bottom' => 'flex-end',
				],
				'default' => 'bottom',
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__original-price' => 'align-self: {{VALUE}}',
				],
				'condition' => [
					'sale' => 'yes',
					'original_price!' => '',
				],
			]
		);

		$this->add_control(
			'heading_period_style',
			[
				'label' => __( 'Period', 'icart' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'period!' => '',
				],
			]
		);

		$this->add_control(
			'period_color',
			[
				'label' => __( 'Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Schemes\Color::get_type(),
					'value' => Schemes\Color::COLOR_2,
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__period' => 'color: {{VALUE}}',
				],
				'condition' => [
					'period!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'period_typography',
				'selector' => '{{WRAPPER}} .elementor-price-table__period',
				'scheme' => Schemes\Typography::TYPOGRAPHY_2,
				'condition' => [
					'period!' => '',
				],
			]
		);

		$this->add_control(
			'period_position',
			[
				'label' => __( 'Position', 'icart' ),
				'type' => Controls_Manager::SELECT,
				'label_block' => false,
				'options' => [
					'below' => __( 'Below', 'icart' ),
					'beside' => __( 'Beside', 'icart' ),
				],
				'default' => 'below',
				'condition' => [
					'period!' => '',
				],
			]
		);

		$this->end_controls_section();



      $this->start_controls_section(
			'section_amenities_style',
			[
				'label' => __( 'Amenities', 'icart' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			]
		);


		$this->add_responsive_control(
			'features_list_padding',
			[
				'label' => __( 'Padding', 'icart' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__features-list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
      $this->add_control(
      'amenity_icon_color',
			[
				'label' => __( 'Icon Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'default' => __( $primaryColor2, 'icart' ),

                'selectors' => [
					'{{WRAPPER}} i' => 'color: {{VALUE}}',
				],
			]
        );
        $this->add_control(
			'selected_icon',
			[
				'label' => __( 'Icon', 'icart' ),
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default' => [
					'value' => 'fa fa-check-circle',
					'library' => 'fa-solid',
				],

			]
		);
		$this->add_control(
			'amenities_available_color',
			[
				'label' => __( 'Available Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Schemes\Color::get_type(),
					'value' => Schemes\Color::COLOR_3,
				],
				'separator' => 'before',
                'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} .amenity_text_available' => 'color: {{VALUE}}',
				],
			]
		);
      $this->add_control(
      'amenities_unavailable_color',
			[
				'label' => __( 'Unavailable Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Schemes\Color::get_type(),
					'value' => Schemes\Color::COLOR_3,
				],
				'separator' => 'before',
                'default' => '#ccc',
				'selectors' => [
					'{{WRAPPER}} .amenity_text_unavailable' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'features_list_typography',
				'selector' => '{{WRAPPER}} .elementor-price-table__features-list li',
				'scheme' => Schemes\Typography::TYPOGRAPHY_3,
			]
		);

		$this->add_control(
			'features_list_alignment',
			[
				'label' => __( 'Alignment', 'icart' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'icart' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'icart' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'icart' ),
						'icon' => 'eicon-text-align-right',
					],
				],
                'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__features-list' => 'text-align: {{VALUE}}',
				],
			]
		);


		$this->add_control(
			'list_divider',
			[
				'label' => __( 'Divider', 'icart' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'divider_style',
			[
				'label' => __( 'Style', 'icart' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'solid' => __( 'Solid', 'icart' ),
					'double' => __( 'Double', 'icart' ),
					'dotted' => __( 'Dotted', 'icart' ),
					'dashed' => __( 'Dashed', 'icart' ),
				],
				'default' => 'solid',
				'condition' => [
					'list_divider' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__features-list li:before' => 'border-top-style: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'divider_color',
			[
				'label' => __( 'Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'default' => $primaryColor,
				'scheme' => [
					'type' => Schemes\Color::get_type(),
					'value' => Schemes\Color::COLOR_3,
				],
				'condition' => [
					'list_divider' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__features-list li:before' => 'border-top-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'divider_weight',
			[
				'label' => __( 'Weight', 'icart' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 2,
					'unit' => 'px',
				],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 10,
					],
				],
				'condition' => [
					'list_divider' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__features-list li:before' => 'border-top-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'divider_width',
			[
				'label' => __( 'Width', 'icart' ),
				'type' => Controls_Manager::SLIDER,
				'condition' => [
					'list_divider' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__features-list li:before' => 'margin-left: calc((100% - {{SIZE}}%)/2); margin-right: calc((100% - {{SIZE}}%)/2)',
				],
			]
		);

		$this->add_control(
			'divider_gap',
			[
				'label' => __( 'Gap', 'icart' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 15,
					'unit' => 'px',
				],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 50,
					],
				],
				'condition' => [
					'list_divider' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__features-list li:before' => 'margin-top: {{SIZE}}{{UNIT}}; margin-bottom: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_footer_style',
			[
				'label' => __( 'Footer', 'icart' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'show_label' => false,
			]
		);

		$this->add_control(
			'footer_bg_color',
			[
				'label' => __( 'Background Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__footer' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'footer_padding',
			[
				'label' => __( 'Padding', 'icart' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_footer_button',
			[
				'label' => __( 'Button', 'icart' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'button_text!' => '',
				],
			]
		);

		$this->add_control(
			'button_size',
			[
				'label' => __( 'Size', 'icart' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'md',
				'options' => [
					'xs' => __( 'Extra Small', 'icart' ),
					'sm' => __( 'Small', 'icart' ),
					'md' => __( 'Medium', 'icart' ),
					'lg' => __( 'Large', 'icart' ),
					'xl' => __( 'Extra Large', 'icart' ),
				],
				'condition' => [
					'button_text!' => '',
				],
			]
		);
      $this->add_control(
			'button_location',
			[
				'label' => __( 'Location', 'icart' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'below',
				'options' => [

					'below' => __( 'Below Amenities', 'icart' ),
                    'above' => __( 'Above Amenities', 'icart' ),

				],
				'condition' => [
					'button_text!' => '',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_button_style' );

		$this->start_controls_tab(
			'tab_button_normal',
			[
				'label' => __( 'Normal', 'icart' ),
				'condition' => [
					'button_text!' => '',
				],
			]
		);

		$this->add_control(
			'button_text_color',
			[
				'label' => __( 'Text Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'scheme' => Schemes\Typography::TYPOGRAPHY_4,
				'selector' => '{{WRAPPER}} .elementor-price-table__button',
			]
		);

		$this->add_control(
			'button_background_color',
			[
				'label' => __( 'Background Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Schemes\Color::get_type(),
					'value' => Schemes\Color::COLOR_4,
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__button' => 'background-color: {{VALUE}};',
				],
                'default' => $primaryColor,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(), [
				'name' => 'button_border',
				'selector' => '{{WRAPPER}} .elementor-price-table__button',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'button_border_radius',
			[
				'label' => __( 'Border Radius', 'icart' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'button_text_padding',
			[
				'label' => __( 'Text Padding', 'icart' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label' => __( 'Hover', 'icart' ),
				'condition' => [
					'button_text!' => '',
				],
			]
		);

		$this->add_control(
			'button_hover_color',
			[
				'label' => __( 'Text Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__button:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_background_hover_color',
			[
				'label' => __( 'Background Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_hover_border_color',
			[
				'label' => __( 'Border Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__button:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_hover_animation',
			[
				'label' => __( 'Animation', 'icart' ),
				'type' => Controls_Manager::HOVER_ANIMATION,
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'heading_additional_info',
			[
				'label' => __( 'Additional Info', 'icart' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'footer_additional_info!' => '',
				],
			]
		);

		$this->add_control(
			'additional_info_color',
			[
				'label' => __( 'Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Schemes\Color::get_type(),
					'value' => Schemes\Color::COLOR_3,
				],
				'selectors' => [
					'.icartFooterText' => 'color: {{VALUE}}',
				],

			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'additional_info_typography',
				'selector' => '{{WRAPPER}} .elementor-price-table__additional_info',
				'scheme' => Schemes\Typography::TYPOGRAPHY_3,
				'condition' => [
					'footer_additional_info!' => '',
				],
			]
		);

		$this->add_control(
			'additional_info_margin',
			[
				'label' => __( 'Margin', 'icart' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top' => 15,
					'right' => 30,
					'bottom' => 0,
					'left' => 30,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__additional_info' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'condition' => [
					'footer_additional_info!' => '',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_ribbon_style',
			[
				'label' => __( 'Ribbon', 'icart' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'show_label' => false,
				'condition' => [
					'show_ribbon' => 'yes',
				],
			]
		);

		$this->add_control(
			'ribbon_bg_color',
			[
				'label' => __( 'Background Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Schemes\Color::get_type(),
					'value' => Schemes\Color::COLOR_4,
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__ribbon-inner' => 'background-color: {{VALUE}}',
				],
			]
		);

		$ribbon_distance_transform = is_rtl() ? 'translateY(-50%) translateX({{SIZE}}{{UNIT}}) rotate(-45deg)' : 'translateY(-50%) translateX(-50%) translateX({{SIZE}}{{UNIT}}) rotate(-45deg)';

		$this->add_responsive_control(
			'ribbon_distance',
			[
				'label' => __( 'Distance', 'icart' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__ribbon-inner' => 'margin-top: {{SIZE}}{{UNIT}}; transform: ' . $ribbon_distance_transform,
				],
			]
		);

		$this->add_control(
			'ribbon_text_color',
			[
				'label' => __( 'Text Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .elementor-price-table__ribbon-inner' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'ribbon_typography',
				'selector' => '{{WRAPPER}} .elementor-price-table__ribbon-inner',
				'scheme' => Schemes\Typography::TYPOGRAPHY_4,
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'selector' => '{{WRAPPER}} .elementor-price-table__ribbon-inner',
			]
		);

		$this->end_controls_section();
  }

  /**
   * Render the widget output on the frontend.
   *
   * Written in PHP and used to generate the final HTML.
   *
   * @since 1.0.0
   *
   * @access protected
   */


  protected function render() {

    //get the iCart widget settings
    $settings = $this->get_settings_for_display();


    //get the planId setting and pull the response from ABC



    $campaignId = "";

    if( $_GET['campaignId'] && $_GET['campaignId'] != "" ){
        $campaignId = $_GET['campaignId'];
    } else if( $settings['campaignId'] && $settings['campaignId'] != "" ){
        $campaignId = $settings['campaignId'];
    } else if(get_option('iCart_abc_campaignId') && get_option('iCart_abc_campaignId') != ""){
        $campaignId = get_option('iCart_abc_campaignId');
    }
     

    if(get_post_meta( get_the_ID(), 'clubNumber', true )){
        $metaClub =  get_post_meta( get_the_ID(), 'clubNumber', true );
        $thisclubNumber = $metaClub;
    } else if($_GET['club']){
        $thisclubNumber = $_GET['club'];
    } else if ($settings[ 'clubNumber' ] != "") {
        $thisclubNumber = $settings[ 'clubNumber' ];

    } else {
        $thisclubNumber = get_option( 'iCart_abc_clubNumber');
    }
    
   if($_GET['club']){
        $thisclubNumber = $_GET['club'];
    }
    if(isset( $_GET['resync']  ) && $_GET['resync'] == 1){
       ABCClubResync($thisclubNumber);
   }
 if ($_GET['campaign'] && $_GET['campaign'] != ""){
          $campaignId = ABCCampaignSelect($thisclubNumber,$_GET['campaign']);
      }
    ?>
  <?php
    $user = wp_get_current_user();
    $allowed_roles = array( 'editor', 'administrator', 'author' );
    if ( current_user_can( 'edit_post', $postId ) ) {
       //echo '<div style="position:absolute; top:-110px; right:0px; color:white; font-weight:bold; font-size:1.3em; background:orange; padding:15px; z-index:333; border-radius:100px; background-image:url(https://i.pinimg.com/originals/37/3f/77/373f77f1eb1a21c1c7e627c42c6b6136.gif)"><a style=" color:white;" href="?resync=1"><i class="fa fa-kiss-wink-heart" style="color:white;"></i> Resync Plans</a></div>';
    }
    ?>
  <?php
   $cat_id = get_cat_ID ( 'Plans' );

    if($_GET['titleFilter']){
        $titleFilter =  $_GET['titleFilter'];
    } else if( $settings['titleFilter'] != "") {
        $titleFilter = $settings['titleFilter'];
    } else {
        $titleFilter = "";
    }
    if($_GET['typeFilter']){
        $typeFilter =  $_GET['typeFilter'];
    } else if( $settings['typeFilter'] != "") {
        $typeFilter = $settings['typeFilter'];
    } else {
        $typeFilter = "";
    }



    if ( $settings['orderby'] != "" ){
		$orderby = $settings['orderby'];
	} else {
		$orderby = 'title';
	}
	if ( $settings['ordersort'] != "" ){
		$ordersort = $settings['ordersort'];
	} else {
		$ordersort = 'ASC';
	}

  

$promoCount = 0;
if( $_GET['promoCode'] && $_GET['promoCode'] != "" ){
	$upperCode = strtoupper($_GET['promoCode']);
    $thispromoCode = $_GET['promoCode'];
    $cat_id = get_cat_ID ( 'Promo Plans' );
    $args = array(
		'post_type'  => 'post',
        'post_status' => 'publish',
		'orderby' => $orderby,
		'order'   => $ordersort,
		'meta_key'   => 'scheduleTotalAmount',

		'meta_query' => array(
			array(
				'key'   => 'clubNumber',
				'value' => $thisclubNumber,
				'compare' => '='
			),
			array(
				'key' => 'planName',
				'value' => $titleFilter,
				'compare' => 'LIKE'
			),
			array(
				'key'   => 'promoCode',
				'value' => $thispromoCode,
				'compare' => 'LIKE'
			),

			array(
				'key'   => 'scheduleTotalAmount',
				'compare' => 'EXISTS'
			)
		)
	);
	$posts = get_posts( $args );
	$promoCount = $posts->found_posts;
}

if( !isset ( $_GET['promoCode'] )  ){
    $thispromoCode = "";
    $cat_id = get_cat_ID ( 'Default Plans' );
    $args = array(
    'post_type'  => 'post',
    'post_status' => 'publish',
    'category'  =>  $cat_id,
    'orderby' => $orderby,
    'order'   => $ordersort,
    'meta_key'   => 'scheduleTotalAmount',
    'meta_query' => array(
        array(
            'key'   => 'clubNumber',
            'value' => $thisclubNumber,
            'compare' => '='
        ),
        array(
            'key' => 'planName',
            'value' => $titleFilter,
            'compare' => 'LIKE'
        ),
        array(
			'key'   => 'scheduleTotalAmount',
            'compare' => 'EXISTS'
		),
        array(
            'key' => 'membershiptype',
            'value' => $typeFilter,
            'compare' => 'LIKE'
        ),
        array(
            'key' => 'promoCode',
            'value' => "",
            'compare' => '='
        ),

    )
	);
	$posts = get_posts( $args );
}

 if($settings['colNumber'] != ""){
      	$colLayout = $settings['colNumber'];
   } else {
      if($numberposts % 3 === 0){
         $colLayout = 3;
      }
      else if($numberposts % 2 === 0){
         $colLayout = 2;
      }
      else if($numberposts % 4 === 0){
         $colLayout = 4;
      }
      else {
         $colLayout = 3;
      }

  }
  if($colLayout == 3){
        $thisclass = "elementor-col-33";
        $thiswidth = "33%";
        $cols = 3;
    } else if($colLayout == 2){
        $thisclass = "elementor-col-50";
        $thiswidth = "50%";
        $cols = 2;
    } else if($colLayout == 4){
        $thisclass = "elementor-col-25";
        $thiswidth = "25%";
        $cols = 4;
    } else if($colLayout == 1){
        $thisclass = "elementor-col-100";
        $thiswidth = "100%";
        $cols = 1;
    } else {
      $thisclass = "elementor-col-33";
        $thiswidth = "33%";
        $cols = 3;
    }
    $primaryColor = "#000000";
    if(get_option('iCart_abc_color_primary1')){
        $primaryColor =  get_option('iCart_abc_color_primary1');
    }
    $primaryColor2 = "#999999";
    if(get_option('iCart_abc_color_primary2')){
        $primaryColor2 =  get_option('iCart_abc_color_primary2');
    }
    $showPlan = "yes";
    if($titleFilter != ""){
        $titlePos = strpos($planName, $titleFilter);

        if ($titlePos === false) {
            $showPlan = "no";
        } else {
            $showPlan = "yes";
        }
    }
    if($typeFilter != ""){
        $typePos = strpos($membershiptype, $typeFilter);

        if ($typePos === false) {
            $showPlan = "no";
        } else {
            $showPlan = "yes";
        }
    }
//$colCount = 3;
 $c = 1;

foreach( $posts as $post ){
    $availability = "";
if($c == 1){
    echo '<div class="elementor-container elementor-column-gap-default icartpost">
        <div class="elementor-row" style="margin-top:25px">';
}
// get the post meta
  $postId = $post->ID;
  $promoCode = get_post_meta($postId, 'promoCode', true);
  $clubNumber = get_post_meta($postId, 'clubNumber', true);
  $agreementDescription = get_post_meta($postId, 'agreementDescription', true);
      //$content = apply_filters( 'the_content', get_the_content() );
    $planName = get_post_meta($postId, 'planName', true);
    $planId = get_post_meta($postId, 'planId', true);
    $popularFlag = get_post_meta($postId, 'popularFlag', true);
    $agreementTerm = get_post_meta($postId, 'agreementTerm', true);
    if($agreementTerm == "Installment"){
        $termStatement = "Annual membership.";
    }
    if($agreementTerm == "Open"){
        $termStatement = "No commitment.";
    }
    if($planId == "12eba874e1b34430935fdd77947f4490"){
        $termStatement = "";
    }

    if( get_post_meta($postId, 'termStatement', true) != "" ){
        $termStatement = get_post_meta($postId, 'termStatement', true);
    }
    $termInMonths = get_post_meta($postId, 'termInMonths', true);
    $scheduleFrequency = get_post_meta($postId, 'scheduleFrequency', true);
    $dueDay = get_post_meta($postId, 'dueDay', true);
    $firstDueDate = get_post_meta($postId, 'firstDueDate', true);
    $activePresale = get_post_meta($postId, 'activePresale', true);
    $expirationDate = get_post_meta($postId, 'expirationDate', true);
    $onlineSignupAllowedPaymentMethods = get_post_meta($postId, 'onlineSignupAllowedPaymentMethods', true);
    $preferredPaymentMethod = get_post_meta($postId, 'preferredPaymentMethod', true);
    $totalContractValue = get_post_meta($postId, 'totalContractValue', true);
    $downPaymentName = get_post_meta($postId, 'downPaymentName', true);
    $downPaymentTotalAmount = get_post_meta($postId, 'downPaymentTotalAmount', true);
    $downPaymentTotalAmountString = $downPaymentTotalAmount . " Due Today";
    $scheduleTotalAmount = get_post_meta($postId, 'scheduleTotalAmount', true);
    $schedulePreTaxAmount = get_post_meta($postId, 'schedulePreTaxAmount', true);
    $clubFeeTotalAmount = get_post_meta($postId, 'clubFeeTotalAmount', true);
    $planValidation = get_post_meta($postId, 'planValidation', true);
    $planLink = get_option( 'siteurl' ) . '/checkout/?planId=' . $planId . '&planValidation=' . $planValidation . '&club=' . $clubNumber . '&campaignId=' . $campaignId;
    $membershiptype = get_post_meta($postId, 'membershiptype', true);
    if( $scheduleTotalAmount == "$0.00"){
        $schedulePreTaxAmount = "0.00";
    }
    $monthlyfee = $schedulePreTaxAmount;

    if( get_post_meta($postId, 'enrollmentFee', true) != "" ){
        $downPaymentTotalAmount = get_post_meta($postId, 'enrollmentFee', true);

    }
    $footerText = "";
    if(get_post_meta( $postId, 'clubFeeFooter', true )){
        $footerText = get_post_meta( $postId, 'clubAccessFooter', true ) . ' ' . get_post_meta( $postId, 'clubFeeFooter', true );
    }


    $clubFeeTotalAmount = get_post_meta($postId, 'clubFeeTotalAmount', true);
    $agreementTerm = get_post_meta( $postId, 'agreementTerm', true );
    $bigPrice = $monthlyfee;
    
    //get schedule price from price source control.  Default is post price.
    $priceControl = $settings['price_control'];
    switch ($priceControl) {
        case "liverecurring":
          $planArray = ABCPlanArray( $clubNumber, $planId );
          //$scheduleFrequency = ABCScheduleFrequency( $planArray );
          $bigPrice = ABCSchedulePreTaxAmount($planArray);
          break;
        case "liveenrollment":
            $planArray = ABCPlanArray( $clubNumber, $planId );
            $bigPrice = ABCDueToday($planArray);
            break;
        case "postdata":
            $bigPrice = $monthlyfee;
            break;
        case "customvalue":
            $bigPrice = $settings['price_override'];
            break;
    }
    
    //get schedule frequency from frequency source control.  Default is post frequency.
    $frequencyControl = $settings['frequency_control'];
    switch ($frequencyControl) {
        case "livefrequency":
          $planArray = ABCPlanArray( $clubNumber, $planId );
          $scheduleFrequency = ABCScheduleFrequency( $planArray );
          break;
        case "postdata":
            $scheduleFrequency = get_post_meta($postId, 'scheduleFrequency', true);
            break;
        case "customvalue":
            $scheduleFrequency = $settings['period'];
            break;
    }
    //additional ABC fields
    //if($planArray){
    //$agreementDescription = base64_decode( $planArray->paymentPlan->agreementDescription );  
    //$clubFeeTotalAmount =  $planArray->paymentPlan->clubFeeTotalAmount;
    //$planPreTax = ABCSchedulePreTaxAmount($planArray);
    //$planPostTax = ABCScheduleAmount($planArray);
    //$planTax = $planPostTax - $planPreTax;
    //$planDueToday = ABCDueToday($planArray);
    //$planDueDate = ABCDueDate($planArray);
    //}
    
    $currency = explode( ".", $bigPrice );
    $dollars = str_replace( '$', '', $currency[ 0 ] ); // piece1
    $cents = $currency[ 1 ];
    $sub_heading = "";
    
    
    //get down payment price from price source control.  Default is post price.
    $enrollmentControl = $settings['enrollment_control'];
    switch ($enrollmentControl) {
        case "liveenrollment":
          $planArray = ABCPlanArray( $clubNumber, $planId );
          $thisDownPayment = ABCDueToday($planArray);
          $sub_heading = $thisDownPayment . $settings['show_enrollment_after'] . '. ' . $termStatement;
          break;
        case "postdata":
            $thisDownPayment = $downPaymentTotalAmount;
            $sub_heading = $thisDownPayment . $settings['show_enrollment_after'] . '. ' . $termStatement;
            break;
        case "customvalue":
            $bigPrice = $settings['price_override'];
            $sub_heading = $settings['sub_heading'];
            break;
    }
    
    
    
     
    ?>


    <div class="elementor-element elementor-column <?php echo $thisclass; ?> elementor-inner-column" data-id="581798f1" data-element_type="column" data-postId="<?php echo $postId; ?>" >
      <div class="elementor-column-wrap  elementor-element-populated">
        <div class="elementor-widget-wrap">
          <div class="elementor-element elementor-element-73fa3e83 elementor-widget elementor-widget-price-table planShadow" data-id="73fa3e83" data-element_type="widget" data-widget_type="price-table.default">
            <div class="elementor-widget-container">
              <div class="elementor-price-table">
                <div class="elementor-price-table__header" >
                  <h3 class="elementor-price-table__heading " style="text-transform: uppercase"><?php echo $planName; ?></h3>
                  <?php if ( ! empty( $sub_heading ) ) { ?>
						<span class="sub_heading icart_subhead"><?php echo $sub_heading; ?></span>
                  <?php }  ?>

                  </div>
                <div class="elementor-price-table__price">

                  <span class="elementor-price-table__currency elementor-currency--before"  style="display:block; clear:both; ">&#36;</span> <span class="elementor-price-table__integer-part" style="font-size:5rem; font-weight:bold; letter-spacing: 0em"><?php echo $dollars;  ?></span>
                  <div class="elementor-price-table__after-price"> <span class="elementor-price-table__fractional-part"><?php echo $cents;  ?></span> </div>
                  <span class="elementor-price-table__period elementor-typo-excluded"><?php echo $scheduleFrequency; ?></span> </div>
                  <?php

                    /* if($agreementDescription != ""){
                    echo '<div style="padding-left:20px; padding-right:20px;  font-size:1.4rem; color: #333; text-align:left; display:none">';
                    echo $agreementDescription;
                    echo '</div>';
                    }
                    */

                  ?>
                   <?php if($settings['button_location'] == "above"){ ?>
                    <a class="elementor-price-table__button elementor-button elementor-size-md elementor-animation-grow-rotate" href="<?php echo $planLink; ?>" >Join Now</a>
                    <?php } ?>
                  <ul class="elementor-price-table__features-list">

                      <?php if ( $promoCode == "NOCONTRACT" || $promoCode == "nocontract" ){ ?>

                                <li class="elementor-repeater-item-001">
                                    <div class="elementor-price-table__feature-inner">
								 <span class="icon-color">
                                        <i class="fa fa-star" style="color:#FFDD00"></i>
                                   </span>


                                        <span class="amenity_text amenity_text_available">
                                            <span style="background-color: #FFF8CB">
                                              Free <b>30 Days</b> of Gold's OnDemand
                                            </span>

                                        </span>

                                        </div>
                                    </li>
                      <li class="elementor-repeater-item-001">
                                    <div class="elementor-price-table__feature-inner">
								 <span class="icon-color">
                                        <i class="fa fa-star" style="color:#FFDD00"></i>
                                   </span>


                                        <span class="amenity_text amenity_text_available">
                                            <span style="background-color: #FFF8CB">
                                              No long term contracts!
                                            </span>

                                        </span>

                                        </div>
                                    </li>
                  <?php

                                                                                           }

                    if(get_option('iCart_abc_color_default_amenities')){
                      $defaultAmenities = explode('|', get_option('iCart_abc_color_default_amenities'));
                    }




					foreach ( $settings['amenities'] as $index => $item ) {
                        $pos = strpos($item['amenity_name'], '**');
                                        if($pos !== false){
                                            $availability = "** Available at participating locations.";
                                        }

                        if ( ! empty( $item['amenity_string'] ) ){
                                        $searchfield = $item['amenity_search'];
                                        $mystring = get_post_meta($postId, $searchfield, true);
                                        $findme   = $item['amenity_string'];
                                        $condition = $item['amenity_condition'];
                                        $display = $item['amenity_display'];
                                        $pos = strpos($mystring, $findme);
                                          if ($pos === false) {
                                              if($condition == "NOT LIKE"){
                                                  $conditionMet = "yes";
                                              } else {
                                                  $conditionMet = "no";
                                              }
                                          } else {
                                              if($condition == "LIKE"){
                                                  $conditionMet = "yes";
                                              } else {
                                                  $conditionMet = "no";
                                              }
                                          }
                                        if($conditionMet == "yes"){
                                            if($display == "available"){
                                                $showAmenity = "available";
                                            } else if($display == "unavailable") {
                                                $showAmenity = "unavailable";
                                            } else if($display == "hidden") {
                                                $showAmenity = "hidden";
                                            }
                                        }
                                    } else {
                                        $showAmenity = "available";
                                        $conditionMet = "yes";
                                    }


                                    if ($conditionMet ==
"yes" && $showAmenity == "available") {
						?>
                                <li class="elementor-repeater-item-<?php echo $item['_id']; ?>">
                                    <div class="elementor-price-table__feature-inner">
								 <span class="icon-color">
                                        <?php Icons_Manager::render_icon( $settings['selected_icon'] ); ?>
                                   </span>


                                        <span class="amenity_text amenity_text_available">
                                            <span>
                                               <?php


                                        echo $item['amenity_name'];

                                                ?>
                                            </span>
                                        </span>

                                        </div>
                                    </li>
                      <?php
                                    } else {}
                        if ($conditionMet ==
"yes" && $showAmenity == "unavailable") {
                                    ?><li class="elementor-repeater-item-<?php echo $item['_id']; ?>">
							             <div class="elementor-price-table__feature-inner">
                                        <i class="fa fa-circle" aria-hidden="true" style='color:#ccc'></i>
                                        <span class="amenity_text amenity_text_unavailable">
                                            <span style="color:#ccc">
                                               <?php echo $item['amenity_name']; ?>
                                            </span>
                                       </span>
                                        </div>
                                      </li>
                                    <?php
                                    }    else {}

                        }
                    ?>

                  </ul>


                <div class="elementor-price-table__footer">
                    <?php if($settings['button_location'] != "above"){ ?>
                    <a class="elementor-price-table__button elementor-button elementor-size-md elementor-animation-grow-rotate" href="<?php echo $planLink; ?>" >Join Now</a>
                    <?php } ?>

              <div <?php echo $this->get_render_attribute_string( 'footer_additional_info' ); ?> style="font-size:.8em; text-align:center; padding:12px; padding-bottom:5px; padding-top:20px;" class="icartFooterText">
                  <?php
                    if($settings['footer_additional_info'] != ""){

                        $footerText = str_replace( 'CLUBFEE', $clubFeeTotalAmount, $settings['footer_additional_info']);

                        echo $footerText;
                    } else {
                      echo "An annual club fee of " . $clubFeeTotalAmount . " will charged at a later date.";
                    }
                  ?>

                    </div>

              </div>







              </div>
              <?php if ( $popularFlag == "yes"  ) :
			$this->add_render_attribute( 'ribbon-wrapper', 'class', 'elementor-price-table__ribbon' );

			if ( ! empty( $settings['ribbon_horizontal_position'] ) ) :
				$this->add_render_attribute( 'ribbon-wrapper', 'class', 'elementor-ribbon-' . $settings['ribbon_horizontal_position'] );
			endif;

			?>
			<div  class="elementor-price-table__ribbon elementor-ribbon-right">
				<div class="elementor-price-table__ribbon-inner"  style="color:white; background:#00ADEF; font-size:.7em;">
                    MOST POPULAR
                </div>
			</div>

			<?php
		endif;
            ?>
                <?php if ( $popularFlag != "no" && $popularFlag != "" && $popularFlag != "yes") :
			$this->add_render_attribute( 'ribbon-wrapper', 'class', 'elementor-price-table__ribbon' );

			if ( ! empty( $settings['ribbon_horizontal_position'] ) ) :
				$this->add_render_attribute( 'ribbon-wrapper', 'class', 'elementor-ribbon-' . $settings['ribbon_horizontal_position'] );
			endif;

			?>
			<div  class="elementor-price-table__ribbon elementor-ribbon-right">
				<div class="elementor-price-table__ribbon-inner"  style="color:white; background:#00ADEF; font-size:.7em;">
                    <?php echo $popularFlag; ?>
                </div>
			</div>

			<?php
		endif;
            ?>

                <?php

    if ( 'yes' === $settings['show_ribbon']  ) :
			$this->add_render_attribute( 'ribbon-wrapper', 'class', 'elementor-price-table__ribbon' );

			if ( ! empty( $settings['ribbon_horizontal_position'] ) ) :
				$this->add_render_attribute( 'ribbon-wrapper', 'class', 'elementor-ribbon-' . $settings['ribbon_horizontal_position'] );
			endif;

			?>
			<div  class="elementor-price-table__ribbon elementor-ribbon-right">
				<div class="elementor-price-table__ribbon-inner">
                    <?php
                    if ( empty( $settings['ribbon_title'] ) ){
                        echo $downPaymentTotalAmountString;
                    } else {
                       echo $settings['ribbon_title'];
                    }
                    ?>
                </div>
			</div>

			<?php
		endif;
            ?>
            </div>
          </div>
        </div>
      </div>
    <?php
    $user = wp_get_current_user();
    $allowed_roles = array( 'editor', 'administrator', 'author' );
    if ( current_user_can( 'edit_post', $postId ) ) {
       echo '<div style="position:absolute; top:0px; left0px; color:white; background:orange; padding:4px"><a style=" color:white;" href="' . get_option( 'siteurl' ) . '/wp-admin/post.php?post=' . $postId . '&action=edit"><i class="fa fa-edit" style="color:white;"></i> Edit Plan</a></div>';
    }
    ?>
    </div>

  <?php

      if($c == $colLayout){
          echo '
          </div>
          </div>


        ';
          $c = 0;
      }
      $c++;




   } // end foreach loop

//wp_reset_postdata();

}

/**
 * Render the widget output in the editor.
 *
 * Written as a Backbone JavaScript template and used to generate the live preview.
 *
 * @since 1.0.0
 *
 * @access protected
 */
protected function _content_template() {


}
}
