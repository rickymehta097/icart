<?php
namespace iCart;

/**
 * Main Plugin class
 */


class Plugin {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Include Widgets files
	 */
	private function include_widgets_files() {

		require_once( __DIR__ . '/widgets/icart-price-summary.php' );
		require_once( __DIR__ . '/widgets/icart-checkout.php' );
        require_once( __DIR__ . '/widgets/icart-promocode.php' );
        require_once( __DIR__ . '/widgets/icart-plan-query.php' );
        //require_once( __DIR__ . '/widgets/icart-auto-checkout.php' );
	}

	/**
	 * Register Widgets
	 *
	 */
	public function register_widgets() {
		$this->include_widgets_files();
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\iCart_Price_Summary() );
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\iCart_Checkout() );
	        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\iCart_Promo_Code() );
	        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\iCart_Plan_Query() );
	       // \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\iCart_Auto_Checkout() );
	}
	/**
	 *  Plugin class constructor
	 *
	 */
	public function __construct() {
		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
	}
}

// Instantiate Plugin Class
Plugin::instance();