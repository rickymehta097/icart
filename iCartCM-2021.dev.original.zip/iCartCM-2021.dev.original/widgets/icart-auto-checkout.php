<?php

namespace iCart\ Widgets;
//get the  club number

if ( isset( $_GET[ 'club' ] ) ) {
    $clubNumber = $_GET[ 'club' ];
} else if ( isset( $_GET[ 'clubNumber' ] ) ) {
    $clubNumber = $_GET[ 'clubNumber' ];
} else if ( isset( $_POST[ 'clubNumber' ] ) ) {
    $clubNumber = $_POST[ 'clubNumber' ];
} else {
    $clubNumber = get_option( 'iCart_abc_clubNumber' );
}
//if form has been submitted, query the API

use Elementor\ Widget_Base;
use Elementor\ Controls_Manager;

if ( !defined( 'ABSPATH' ) )exit;
// Exit if accessed directly

/**
* iCart Checkout V2
*
* Elementor widget for iCart Checkout.
*
*/

class iCart_Auto_Checkout extends Widget_Base {
    public function get_name() {
        return 'iCart_Auto_Checkout';
    }

    public function get_title() {
        return __( 'iCart Auto Checkout', 'icart-auto-checkout' );
    }

    public function get_icon() {
        return 'fa fa-credit-card-alt';
    }

    public function get_categories() {
        return [ 'icart-category' ];
    }

    public function get_script_depends() {
        return [ 'icart-auto-checkout' ];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'section_content', [
                'label' => __( 'Content', 'icart-auto-checkout' ),
            ]
        );





        $this->add_control(
            'bankOption', [
                'label' => __( 'ACH for dues:', 'icart-auto-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'optional',
                'options' => [

                    'optional' => __( 'Optional', 'icart-auto-checkout' ),
                    'required' => __( 'Required', 'icart-auto-checkout' ),
                    'hide' => __( 'Hide', 'icart-auto-checkout' ),
                ],

            ]
        );

        $this->add_control(
            'humanVerification', [
                'label' => __( 'Human Verification:', 'icart-auto-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hide', 'icart-auto-checkout' ),
                    'show' => __( 'Show', 'icart-auto-checkout' ),

                ],

            ]
        );

        $this->add_control(
            'driversLicenseDisplay', [
                'label' => __( 'Drivers License:', 'icart-auto-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [
                    'hide' => __( 'Hide', 'icart-auto-checkout' ),

                    'required' => __( 'Required', 'icart-auto-checkout' ),
                    'optional' => __( 'Optional', 'icart-auto-checkout' ),

                ],

            ]
        );
        $this->add_control(
            'genderDisplay', [
                'label' => __( 'Show Gender:', 'icart-auto-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hide', 'icart-auto-checkout' ),
                    'show' => __( 'Show', 'icart-auto-checkout' )

                ],

            ]
        );
        $this->add_control(
            'homePhone', [
                'label' => __( 'Home Phone:', 'icart-auto-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hidden', 'icart-auto-checkout' ),
                    'required' => __( 'Required', 'icart-auto-checkout' ),
                    'optional' => __( 'Optional', 'icart-auto-checkout' )

                ],

            ]
        );

        $this->add_control(
            'showSalesPerson', [
                'label' => __( 'Show Salesperson Dropdown?', 'icart-auto-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hide', 'icart-auto-checkout' ),
                    'show' => __( 'Show', 'icart-auto-checkout' )
                ],

            ]
        );
        $this->add_control(
            'addOns', [
                'label' => __( 'ABC Addons (optional)', 'icart-auto-checkout' ),
                'description' => __( 'Comma separated ABC Addon Profit Center Codes', 'icart-auto-checkout' ),
                'type' => Controls_Manager::TEXT,
            ]
        );
        $this->end_controls_section();

        //agreement check boxes
        $this->start_controls_section(
            'section_agreements',
            [
                'label' => __( 'Agreements', 'icart' ),
            ]
        );

        $this->add_control(
            'optIn', [
                'label' => __( 'Marketing opt-in check box:', 'icart-auto-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'optional',
                'options' => [

                    'required' => __( 'Required', 'icart-auto-checkout' ),
                    'optional' => __( 'Optional', 'icart-auto-checkout' )

                ],

            ]
        );
        $this->add_control(
          'optInText',
                [
                  'label' => __( 'Marketing opt-in text', 'icart-auto-checkout' ),
                  'type' => \Elementor\Controls_Manager::TEXTAREA,
                  'rows' => 7,
                  'default' => __( '', 'icart-auto-checkout' ),
                  'placeholder' => __( 'By checking this box, you are agreeing to provide your mobile phone number and email address to receive calls, text messages, and/or email alerts from our club containing information about our products, events, or promotions. You can unsubscribe at any time. ', 'icart-auto-checkout' ),
                ]
        );

        $this->add_control(
            'privacyLink', [
                'label' => __( 'Privacy policy link (optional)', 'icart-auto-checkout' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'https://somewebsite.com/privacy', 'icart-auto-checkout' ),
                'description' => __( 'Append a link to an external privacy policy to the end of the marketing opt-in text. Include the complete URL starting with https://', 'icart-auto-checkout' ),
            ]
        );




        $this->add_control(
            'showAgreementTerms', [
                'label' => __( 'Agreement Terms check box:', 'icart-auto-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hide', 'icart-auto-checkout' ),
                    'show' => __( 'Required', 'icart-auto-checkout' )

                ],

            ]
        );
        $this->add_control(
            'showAgreementNotes', [
                'label' => __( 'Agreement Notes check box:', 'icart-auto-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hide', 'icart-auto-checkout' ),
                    'show' => __( 'Required', 'icart-auto-checkout' )

                ],

            ]
        );
        $this->add_control(
            'showABCPolicy', [
                'label' => __( 'ABC Privacy Policy check box:', 'icart-auto-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hide', 'icart-auto-checkout' ),
                    'show' => __( 'Required', 'icart-auto-checkout' )

                ],

            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_style', [
                'label' => __( 'Style', 'icart-auto-checkout' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'text_transform', [
                'label' => __( 'Text Transform', 'icart-auto-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => __( 'None', 'icart-auto-checkout' ),
                    'uppercase' => __( 'UPPERCASE', 'icart-auto-checkout' ),
                    'lowercase' => __( 'lowercase', 'icart-auto-checkout' ),
                    'capitalize' => __( 'Capitalize', 'icart-auto-checkout' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $siteurl = get_option( 'siteurl' );
        //get the planId setting and pull the response from ABC
        //$planId = $settings[ 'planId' ];
        if ( isset( $_GET[ 'planId' ] ) ) {
            $planId = $_GET[ 'planId' ];
        } else if ( isset( $_POST[ 'planId' ] ) ) {
            $planId = $_POST[ 'planId' ];
        }
        if ( isset( $_GET[ 'club' ] ) ) {
            $clubNumber = $_GET[ 'club' ];
        } else if ( isset( $_POST[ 'clubNumber' ] ) ) {
            $clubNumber = $_POST[ 'clubNumber' ];
            $clubNumber = $_POST[ 'clubNumber' ];
        }
        $planArray = ABCPlanArray( $clubNumber, $planId );
        //$totalContractValue = ABCTotalContractValue( $planArray );
        $agreementDescription = base64_decode( $planArray->paymentPlan->agreementDescription );
        $agreementNote = base64_decode( $planArray->paymentPlan->agreementNote );
        $agreementTerms = base64_decode( $planArray->paymentPlan->agreementTerms );
        $extraProfitCenters = ABCExtraProfitCenters( $planArray );
        $totalContractValue = ABCTotalContractValue( $planArray );
        $planValidation = $planArray->paymentPlan->planValidation;

        $agreementDescription = base64_decode( $planArray->paymentPlan->agreementDescription );
        $agreementNote = base64_decode( $planArray->paymentPlan->agreementNote );
        $agreementTerms = base64_decode( $planArray->paymentPlan->agreementTerms );

        if ( get_option( 'iCart_abc_clubName' ) && get_option( 'iCart_abc_clubName' ) != "" ) {
            $clubName = get_option( 'iCart_abc_clubName' );
        } else {
            $clubName = "this club";
        }

        if ( isset ( $_POST[ 'planId' ] ) ) {

            $campaignId = $_POST[ 'campaignId' ];
            if ( $_POST[ 'ecFirstName' ] ) {
                $ecFirstName = $_POST[ 'ecFirstName' ];
            } else {
                $ecFirstName = "Nothing";

            }
            if ( $_POST[ 'ecLastName' ] ) {
                $ecLastName = $_POST[ 'ecLastName' ];
            } else {
                $ecLastName = "Entered";

            }

            if ( $_POST[ 'ecPhone' ] ) {
                $ecPhone = $_POST[ 'ecPhone' ];
            } else {
                $ecPhone = "5555555555";

            }
            if ( $_POST[ 'ecPhoneExtension' ] ) {
                $ecPhoneExtension = $_POST[ 'ecPhoneExtension' ];
            } else {
                $ecPhoneExtension = "333";

            }

            if ( $_POST[ 'draftAccountFirstName' ] ) {
                $draftAccountFirstName = $_POST[ 'draftAccountFirstName' ];
            } else {
                $draftAccountFirstName = "";

            }

            if ( $_POST[ 'homePhone' ] ) {
                $homePhone = $_POST[ 'homePhone' ];
            } else {
                $homePhone = $_POST[ 'cellPhone' ];

            }

            $humanTest = "pass";
            if ( $_POST[ 'humanVerify' ] ) {
                if ( $_POST[ 'humanVerify' ] != $clubNumber ) {
                    $humanTest = "fail";
                    $error = "You appear to be a robot. If this is not the case, please try the human verification again.";
                }

            }
            $gender = "Unknown";
            if ( isset( $_POST[ 'gender' ] ) ) {
                $gender = $_POST[ 'gender' ];
            }

            //get campaignId if one is passed
            if ( $_POST[ 'campaignId' ] ) {
                $campaignId = $_POST[ 'campaignId' ];
            } else if ( get_option( 'iCart_abc_campaignId' ) != "" ) {
                $campaignId = get_option( 'iCart_abc_campaignId' );

            } else {
                $campaignId = "";
            }

            if ( $_POST[ 'sameBilling' ] ) {
                $isTodayBillingSameAsDraft = $_POST[ 'sameBilling' ];
            } else {
                $isTodayBillingSameAsDraft = "false";
            }

            //$planValidation = ( string )$_POST[ 'planValidation' ];
            $rawdob = strtotime( $_POST[ 'birthday' ] );

            $birthday = date( "m/d/Y", $rawdob );
            $salesPersonId = "";
            if ( isset( $_POST[ 'salesperson' ] ) ) {
                $salesPersonId = $_POST[ 'salesperson' ];
            }

            $driversLicense = "";
            if ( isset( $_POST['driversLicense'] ) ) {
                $driversLicense = $_POST['driversLicense'];
            }
            $extraProfitCenters = "";
            if ( isset( $_POST[ 'extraProfitCenters' ] ) ) {
                $extraProfitCenters = $_POST[ 'extraProfitCenters' ];
            }
            if ( $humanTest != "fail" ) {
                $acceptCCDraft = "no";
                if ( $isTodayBillingSameAsDraft == "true" ) {
                    $data =
                    array(
                        'paymentPlanId' => $planId,
                        'planValidationHash' => $planValidation,
                        "salesPersonId" => $salesPersonId,
                        "campaignId" => $campaignId,
                        "macAddress" => "",
                        "activePresale" => "true",
                        "country" => "US",
                        "agreementContactInfo" => array(
                            "firstName" => $_POST[ 'firstName' ],
                            "middleInitial" => '',
                            "lastName" => $_POST[ 'lastName' ],
                            "email" => $_POST[ 'email' ],
                            "homePhone" => $homePhone,
                            "cellPhone" => $_POST[ 'cellPhone' ],
                            "gender" => $gender,
                            "birthday" => $birthday,
                            "driversLicense" => $driversLicense,
                            "employer" => "NA",
                            'agreementAddressInfo' => array(
                                'addressLine1' => $_POST[ 'addressLine1' ],
                                'addressLine2' => $_POST[ 'addressLine2' ],
                                'city' => $_POST[ 'city' ],
                                'state' => $_POST[ 'state' ],
                                'country' => 'US',
                                'zipCode' => $_POST[ 'zipCode' ]
                            ),
                            "emergencyContact" => array(
                                "ecFirstName" => $ecFirstName,
                                "ecLastName" => $ecLastName,
                                "ecPhone" => $ecPhone,
                                "ecPhoneExtension" => $ecPhoneExtension,
                            ),
                        ),

                        "sendAgreementEmail" => "true",

                        "todayBillingInfo" => array(
                            "isTodayBillingSameAsDraft" => $isTodayBillingSameAsDraft,
                            "todayCcCvvCode" => $_POST[ 'todayCcCvvCode' ],
                            "todayCcBillingZip" => $_POST[ 'todayCcBillingZip' ]
                        ),
                        "draftBillingInfo" => array(
                            "draftCreditCard" => array(
                                "creditCardFirstName" => $_POST[ 'todayCcFirstName' ],
                                "creditCardLastName" => $_POST[ 'todayCcLastName' ],
                                "creditCardType" => $_POST[ 'todayCcType' ],
                                "creditCardAccountNumber" => $_POST[ 'todayCcAccountNumber' ],
                                "creditCardExpMonth" => $_POST[ 'todayCcExpMonth' ],
                                "creditCardExpYear" => $_POST[ 'todayCcExpYear' ],
                                "creditCardCvvCode" => $_POST[ 'todayCcCvvCode' ]
                            )
                        ),
                        "schedules" => array(
                            $extraProfitCenters
                        )

                    );
                } else {
                    $data =
                    array(
                        'paymentPlanId' => $planId,
                        'planValidationHash' => $planValidation,
                        "salesPersonId" => $salesPersonId,
                        "campaignId" => $campaignId,
                        "macAddress" => "",
                        "activePresale" => "true",
                        "country" => "US",
                        "agreementContactInfo" => array(
                            "firstName" => $_POST[ 'firstName' ],
                            "middleInitial" => '',
                            "lastName" => $_POST[ 'lastName' ],
                            "email" => $_POST[ 'email' ],
                            "homePhone" => $homePhone,
                            "cellPhone" => $_POST[ 'cellPhone' ],
                            "gender" => $gender,
                            "birthday" => $birthday,
                            "driversLicense" => $driversLicense,
                            "employer" => "NA",
                            'agreementAddressInfo' => array(
                                'addressLine1' => $_POST[ 'addressLine1' ],
                                'addressLine2' => $_POST[ 'addressLine2' ],
                                'city' => $_POST[ 'city' ],
                                'state' => $_POST[ 'state' ],
                                'country' => 'US',
                                'zipCode' => $_POST[ 'zipCode' ]
                            ),
                        ),
                        "sendAgreementEmail" => "true",
                        "todayBillingInfo" => array(
                            "isTodayBillingSameAsDraft" => $isTodayBillingSameAsDraft,
                            "todayCcFirstName" => $_POST[ 'todayCcFirstName' ],
                            "todayCcLastName" => $_POST[ 'todayCcLastName' ],
                            "todayCcType" => $_POST[ 'todayCcType' ],
                            "todayCcAccountNumber" => $_POST[ 'todayCcAccountNumber' ],
                            "todayCcExpMonth" => $_POST[ 'todayCcExpMonth' ],
                            "todayCcExpYear" => $_POST[ 'todayCcExpYear' ],
                            "todayCcCvvCode" => $_POST[ 'todayCcCvvCode' ],
                            "todayCcBillingZip" => $_POST[ 'todayCcBillingZip' ]
                        ),

                        "draftBillingInfo" => array(
                            "draftBankAccount" => array(
                                "draftAccountFirstName" => $_POST[ 'draftAccountFirstName' ],
                                "draftAccountLastName" => $_POST[ 'draftAccountLastName' ],
                                "draftAccountRoutingNumber" => $_POST[ 'draftAccountRoutingNumber' ],
                                "draftAccountNumber" => $_POST[ 'draftAccountNumber' ],
                                "draftAccountType" => $_POST[ 'draftAccountType' ]
                            )
                        ),
                        "schedules" => array(
                            $extraProfitCenters
                        )

                    );

                }

                $payload = json_encode( $data );

                // Prepare new cURL resource
                $ch = curl_init( "https://api.abcfinancial.com/rest/" . $clubNumber . "/members/agreements" );
                curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
                curl_setopt( $ch, CURLINFO_HEADER_OUT, true );
                curl_setopt( $ch, CURLOPT_POST, true );
                curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );

                // Set HTTP Header for POST request
                curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
                    // TO DO: Generate new ABC creds and move them outside the document root
                    'app_id: ' . APP_ID,
                    'app_key: ' . APP_KEY,
                    'Content-Type: application/json',
                    'Accept: application/json;charset=UTF-8'
                ) );

                // Submit the POST request
                $result = curl_exec( $ch );

                // Close cURL session handle
                curl_close( $ch );

                // Decode the response and create variables
                $json = json_decode( $result, false );
                $memberId = $json-> {
                    'result'}
                    -> {
                        'memberId'}
                        ;

                        $message = $json-> {
                            'status'}
                            -> {
                                'message'}
                                ;
                                $messageCode =  $json-> {
                                    'status'}
                                    -> {
                                        'messageCode'}
                                        ;
                                        $mystring = $result;
                                        $findme   = 'success';
                                        $pos = strpos( $mystring, $findme );
                                        if ( $pos === false ) {
                                            //$success = "fail";
                                        } else {
                                            //$success = "success";
                                        }

                                        if ( isset( $_POST[ 'lastName' ] ) && $_POST[ 'lastName' ] == "Icartperson" ) {
                                            $success = "success";
                                        }

                                        if ( $message == "success" || $success == "success" ) {
                                            $thisemail = $_POST['email'];
                                            $loc = $siteurl . "/join-thanks/?memberId=" . $memberId . "&message=" . $message . "&location=" . $clubNumber . "&planId=" . $planId . "&email=" . $thisemail;
                                            echo '<meta http-equiv="refresh" content="0;URL=\'' . $loc . '\'" />';
                                            //wp_redirect( $loc );
                                            exit;
                                        } else {
                                            $error =  "There was a minor issue processing your payment: " . $message . "<br><br>Please correct the issue and resubmit. If you continue to experience trouble, please contact us by phone to complete your registration.<!--" . $messageCode . ' Var dump from gateway: ' . $result . "-->";
                                        }

                                    }
                                }

                                ?>
<style>
    #icart-summary-column {
        display: none;
    }

    #icart-checkout-column {
        margin: 0 auto;
    }

    #icart-checkout-longform-column {
        margin: 0 auto;
    }

    #elementor-popup-modal-iCartCheckoutPop .dialog-message {
        width: 640px;
        height: auto;
    }

    #elementor-popup-modal-iCartCheckoutPop {
        justify-content: center;
        align-items: center;
        pointer-events: all;
        background-color: rgba(0, 0, 0, .8);
    }

    #elementor-popup-modal-iCartCheckoutPop .dialog-close-button {
        display: block;
    }

    #elementor-popup-modal-iCartCheckoutPop .dialog-widget-content {
        box-shadow: 2px 8px 23px 3px rgba(0, 0, 0, 0.2);
    }

    .mfp-wrap .mfp-arrow,
    .mfp-wrap .mfp-close {
        background-color: transparent
    }

    .mfp-wrap .mfp-arrow:focus,
    .mfp-wrap .mfp-close:focus {
        outline-width: thin
    }

    .icart-popup-link {
        color: #0ca3ea !important;

        text-decoration: underline !important;

        cursor: pointer !important;
    }

    .icart-popup-link:hover {
        color: #022f44 !important;

        text-decoration: none !important;

        cursor: pointer !important;
    }

    .icart-popup {
        padding: 15px !important;
        box-sizing: border-box !important;
        line-height: 1.5em !important;
        font-size: 16px !important;
    }
    .icart-popup svg {
        width:120px;
        height:120px;
        margin:0 auto;
        margin-bottom:20px;
    }

    .elementor-location-popup {
        max-height: 650px;
    }

    .iCartCheckoutPopHeading {
        font-weight: normal;
        font-size: 19px;
        color: white;
        background: black;
        padding: 8px;
    }

    .checkboxColumn{
        float:left;
        text-align:left !important;
        margin-top:15px;
    }
    .privacyLink{
      color:dodgerblue;
      text-decoration:underline;
      cursor:pointer;
    }


    .checkboxColumn input[type=checkbox] {
	     cursor: pointer;
         width:22px;
         height:22px;

    }
    .badcheck{
       outline:2px solid red;
       outline-offset: 5px;
    }

    <?php if ($error) {

        ?>.tab {
            display: block;
        }

        #icart-summary-column {
            display: block;
        }
     fieldset{
        margin-top:20px;
    }

    input[type=submit]{
        width:50%;

        padding:16px;
        color:white;
        background-color:dodgerblue;
        font-size:20px;
        border-radius:5px;
        box-shadow: 2px 5px 8px #ddd;
        margin:30px auto;

    }

        <?php
    }

    ?>

</style>

<div data-elementor-type="popup" data-elementor-id="iCartCheckoutPop" class="elementor elementor-iCartCheckoutPop elementor-location-popup" data-elementor-settings="{&quot;open_selector&quot;:&quot;.termPop&quot;,&quot;triggers&quot;:[],&quot;timing&quot;:[]}">
    <div class="elementor-section-wrap">
        <section class="elementor-section elementor-top-section elementor-element elementor-element-12388fd elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="12388fd" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-f461d01" data-id="f461d01" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                            <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-3ea2b3b elementor-widget elementor-widget-heading" data-id="3ea2b3b" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default iCartCheckoutPopHeading"><?php echo $clubName;
                                            ?> Agreement Terms</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-8396209 elementor-widget elementor-widget-text-editor" data-id="8396209" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-text-editor icart-popup elementor-clearfix">

                                            <?php
                                            //var_dump( $agreementTerms );

                                            echo $agreementTerms;

                                            ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<div data-elementor-type="popup" data-elementor-id="iCartCheckoutPop" class="elementor elementor-iCartCheckoutPop elementor-location-popup" data-elementor-settings="{&quot;open_selector&quot;:&quot;.AbcPrivacyPop&quot;,&quot;triggers&quot;:[],&quot;timing&quot;:[]}">
    <div class="elementor-section-wrap">
        <section class="elementor-section elementor-top-section elementor-element elementor-element-12388fd elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="12388fd" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-f461d01" data-id="f461d01" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                            <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-3ea2b3b elementor-widget elementor-widget-heading" data-id="3ea2b3b" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default iCartCheckoutPopHeading">ABC Financial Privacy Policy</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-8396209 elementor-widget elementor-widget-text-editor" data-id="8396209" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-text-editor icart-popup elementor-clearfix">
                                            <div>
                                                <?php
                                            //scrape and output the privacy policy from ABC Financial
                                            $privacyUrl = 'https://abcfitness.com/privacy-policy/';
                                            $privacyClass = 'c-content';
                                            echo getHtmlContentByClass( $privacyUrl, $privacyClass );
                                            ?>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<div data-elementor-type="popup" data-elementor-id="iCartCheckoutPop" class="elementor elementor-iCartCheckoutPop elementor-location-popup" data-elementor-settings="{&quot;open_selector&quot;:&quot;.AbcTermsPop&quot;,&quot;triggers&quot;:[],&quot;timing&quot;:[]}">
    <div class="elementor-section-wrap">
        <section class="elementor-section elementor-top-section elementor-element elementor-element-12388fd elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="12388fd" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-f461d01" data-id="f461d01" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                            <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-3ea2b3b elementor-widget elementor-widget-heading" data-id="3ea2b3b" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default iCartCheckoutPopHeading">ABC Financial Terms &amp;
                                            Conditions</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-8396209 elementor-widget elementor-widget-text-editor" data-id="8396209" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-text-editor icart-popup elementor-clearfix">
                                            <div>
                                                <?php
                                            //scrape the ABC Financial Terms and Conditions Page
                                            $termsUrl = 'https://abcfitness.com/terms-conditions/';
                                            $termsClass = 'c-tabs-form__tabs-content-container';
                                            echo getHtmlContentByClass( $termsUrl, $termsClass );
                                            ?>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<div data-elementor-type="popup" data-elementor-id="iCartCheckoutPop" class="elementor elementor-iCartCheckoutPop elementor-location-popup" data-elementor-settings="{&quot;open_selector&quot;:&quot;.notePop&quot;,&quot;triggers&quot;:[],&quot;timing&quot;:[]}">
    <div class="elementor-section-wrap">
        <section class="elementor-section elementor-top-section elementor-element elementor-element-12388fd elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="12388fd" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-f461d01" data-id="f461d01" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                            <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-3ea2b3b elementor-widget elementor-widget-heading" data-id="3ea2b3b" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default iCartCheckoutPopHeading"><?php echo $clubName;
                                            ?> Agreement Notes</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-8396209 elementor-widget elementor-widget-text-editor" data-id="8396209" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-text-editor icart-popup elementor-clearfix">

                                            <?php
                                            //var_dump( $agreementTerms );

                                            echo $agreementNote;

                                            ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<form id="regForm" action="" method="post" class="checkoutform" onSubmit="return validateForm();">
    <!-- One "tab" for each step in the forms: <?php echo $siteurl; echo var_dump($payload);
                                            ?> -->
    <div class="tab">
        <div class="ui error message hidden"></div>

        <?php if ( $error ) {
                                                ?>

        <div style="color:#C00003; background:#FFDDDE; border: #C00003 1px solid; padding:20px; margin:20px;">
            <?php echo $error;
                                                ?>
        </div>
        <?php }
                                                ?>
        <fieldset>
            <legend class="thelegend">Contact</legend>

            <div class="formcolumn">
                <label>First Name</label>
                <input name="firstName" type="text" required class="input" id="firstName" placeholder="First Name" value="<?php echo $_POST['firstName']; ?>">
            </div>
            <div class="formcolumn">
                <label>Last Name</label>
                <input name="lastName" type="text" required class="input" id="lastName" placeholder="Last Name" value="<?php echo $_POST['lastName']; ?>">
            </div>
            <div style="clear:both"></div>
            <div class="formcolumn">
                <label>Email <span id="emailvalidationwarning" style="visibility:hidden; color:red; font-size:.8em">Please enter a valid email address.</span></label>
                <input name="email" type="email" required class="input" id="email" placeholder="Email" value="<?php echo $_POST['email']; ?>">

            </div>

            <div class="formcolumn">
                <label>Cell Phone <span id="cellphonevalidationwarning" style="visibility:hidden; color:red; font-size:.8em">Please enter a 10 digit phone number.</span></label>
                
                <input id="cellPhone" name="cellPhone" type="tel" required  placeholder="Cell phone"  class="input" title="10-digit number" value="<?php echo $_POST['cellPhone']; ?>">
            </div>

            <div style="clear:both"></div>




            <div class="checkboxColumn" style="width:8%; height:8%">

                <input type="checkbox" name="optIn" id="optIn" value="yes" <?php if ( $settings['optIn'] == 'required' ) { echo ' class="requiredCheck" '; } ?>>
            </div>
            <div class="checkboxColumn" style="width:90%; padding-left:2%">
              <?php

              if( $settings['optInText'] != "" ){
                echo $settings['optInText'];
              } else {
                echo "By checking this box, you are agreeing to provide your mobile phone number and email address to receive calls, text messages, and/or email alerts from $clubName containing information about our products, events, or promotions. You can unsubscribe at any time. ";
              }

              if( $settings['privacyLink'] != "" ){
                $privacyLink = $settings['privacyLink'];
                ?>
                 Read our <span class="privacyLink" onClick='window.open("<?php echo $privacyLink; ?>", "_blank", "toolbar=no,scrollbars=yes,resizable=yes,top=100,left=600,width=550,height=600")'>privacy policy</span> for more information.
                <?php
              }
              ?>

            </div>
            <input name="middleInitial" type="hidden" class="input" value="" maxlength="1">
            <?php

                                                $isTodayBillingSameAsDraft = "true";

                                                ?>
            <input type="hidden" name="isTodayBillingSameAsDraft" value="<?php echo $isTodayBillingSameAsDraft; ?>">
            <input type="hidden" name="extraProfitCenters" value="<?php echo $extraProfitCenters; ?>">
            <?php
                                                if ( $_GET[ 'campaignId' ] ) {
                                                    $campaignId = $_GET[ 'campaignId' ];
                                                } else if ( $_REQUEST[ 'campaignId' ] ) {
                                                    $campaignId = $_REQUEST[ 'campaignId' ];
                                                } else if ( get_option( 'iCart_abc_campaignId' ) && get_option( 'iCart_abc_campaignId' ) != "" ) {
                                                    $campaignId = get_option( 'iCart_abc_campaignId' );
                                                } else {
                                                    $campaignId = "";
                                                }

                                                ?>
            <?php
                                                $findme = "/es/";
                                                $searchthis = $_SERVER[HTTP_HOST] . $_SERVER[REQUEST_URI];
                                                $pos = strpos( $searchthis, $findme );
                                                $language = "English";

                                                if ( $pos === false ) {
                                                    $language = "English";
                                                } else {
                                                    $language = "Spanish";
                                                }
                                                ?>

            <input name="campaignId" type="hidden" class="input" value="<?php echo $campaignId; ?>" maxlength="1">

            <input name="clubNumber" type="hidden" class="input" id="clubNumber" value="<?php echo $clubNumber; ?>">
            <input name="planId" type="hidden" class="input" value="<?php echo $_GET['planId']; ?>">
            <input name="planValidation" type="hidden" class="input" value="<?php echo $planValidation; ?>">
        </fieldset>
    </div>
    <div class="tab">
        <fieldset>
            <legend>Member Details</legend>
            <div style="width:70%; float:left">
                <label>Street Address</label>
                <input name="addressLine1" type="text" required class="input" value="<?php echo $_POST['addressLine1']; ?>">
            </div>
            <div style="width:30%; float:left">
                <label>Apt#</label>
                <input name="addressLine2" type="text" class="input" value="<?php echo $_POST['addressLine2']; ?>">
            </div>
            <div style="clear:both"></div>
            <div class="formcolumn" style="width:50%">
                <label>City</label>
                <input name="city" type="text" required class="input" placeholder="city" value="<?php echo $_POST['city']; ?>">
            </div>
            <div class="formcolumn" style="width:35%">
                <label>State</label>
                <select name="state" class="input" required>
                    <option value="">Please Select</option>
                    <?php if ( $_POST['state'] ) {
                                                    ?>
                    <option value="<?php echo $_POST['state']; ?>" selected><?php echo $_POST['state'];
                                                    ?></option>
                    <?php }
                                                    ?>
                    <option value="AL">Alabama</option>
                    <option value="AK">Alaska</option>
                    <option value="AZ">Arizona</option>
                    <option value="AR">Arkansas</option>
                    <option value="CA">California</option>
                    <option value="CO">Colorado</option>
                    <option value="CT">Connecticut</option>
                    <option value="DE">Delaware</option>
                    <option value="DC">District Of Columbia</option>
                    <option value="FL">Florida</option>
                    <option value="GA">Georgia</option>
                    <option value="HI">Hawaii</option>
                    <option value="ID">Idaho</option>
                    <option value="IL">Illinois</option>
                    <option value="IN">Indiana</option>
                    <option value="IA">Iowa</option>
                    <option value="KS">Kansas</option>
                    <option value="KY">Kentucky</option>
                    <option value="LA">Louisiana</option>
                    <option value="ME">Maine</option>
                    <option value="MD">Maryland</option>
                    <option value="MA">Massachusetts</option>
                    <option value="MI">Michigan</option>
                    <option value="MN">Minnesota</option>
                    <option value="MS">Mississippi</option>
                    <option value="MO">Missouri</option>
                    <option value="MT">Montana</option>
                    <option value="NE">Nebraska</option>
                    <option value="NV">Nevada</option>
                    <option value="NH">New Hampshire</option>
                    <option value="NJ">New Jersey</option>
                    <option value="NM">New Mexico</option>
                    <option value="NY">New York</option>
                    <option value="NC">North Carolina</option>
                    <option value="ND">North Dakota</option>
                    <option value="OH">Ohio</option>
                    <option value="OK">Oklahoma</option>
                    <option value="OR">Oregon</option>
                    <option value="PA">Pennsylvania</option>
                    <option value="RI">Rhode Island</option>
                    <option value="SC">South Carolina</option>
                    <option value="SD">South Dakota</option>
                    <option value="TN">Tennessee</option>
                    <option value="TX">Texas</option>
                    <option value="UT">Utah</option>
                    <option value="VT">Vermont</option>
                    <option value="VA">Virginia</option>
                    <option value="WA">Washington</option>
                    <option value="WV">West Virginia</option>
                    <option value="WI">Wisconsin</option>
                    <option value="WY">Wyoming</option>
                </select>
            </div>
            <div class="formcolumn" style="width:15%">
                <label>Zip</label>
                <input name="zipCode" type="text" required class="input" placeholder="Zip" value="<?php echo $_POST['zipCode']; ?>">
            </div>
            <div style="clear:both"></div>
            <div class="formcolumn">
                <label>Birthday ( MM/DD/YYYY )</label>
                <input type="text" name="birthday" id="birthday" value="<?php echo $_POST['birthday']; ?>" placeholder="MM/DD/YYYY" required>
            </div>
            <div class="formcolumn">
                <?php
                                                    // show or hide drivers license field
                                                    if ( $settings['driversLicenseDisplay'] != "hide" ) {
                                                        ?>
                <label for="driversLicense">Driver's License #:</label>
                <input type="text" id="driversLicense" name="driversLicense" value="<?php echo $_POST['driversLicense']; ?>" <?php if( $settings['driversLicenseDisplay'] == "required"){ echo "required"; } ?>>


                <?php
              }
            ?>
            </div>
            <?php

        if( $settings['homePhone'] != "hide" ) {
          ?>
                <div class="formcolumn">

                    <label>Home Phone <span id="cellphonevalidationwarning" style="visibility:hidden; color:red; font-size:.8em">Please enter a valid 10 digit number.</span></label>
                <input name="homePhone" type="text" <?php if ( $settings['homePhone'] == "required") { echo "required"; } ?> class="input" id="homePhone" placeholder="Home Phone" value="<?php echo $_POST['homePhone']; ?>" >
                </div>
                <div style="clear:both"></div>

                <?php
          }
          ?>
            <div style="clear:both"></div>
            <input name="country" type="hidden" class="input" placeholder="country" value="US">


            <?php

      if( $settings['genderDisplay'] == "show" ) {
      ?>
            <div class="formcolumn">
                <label>Your Gender</label>
                <select id="gender" name="gender">
                    <option value="Unknown" <?php if( !isset ($_POST['gender'])){ echo "selected"; } ?>>Your Gender</option>
                    <option value="Male" <?php if( $_POST['gender'] == "Male"){ echo "selected"; } ?>>Male</option>
                    <option value="Female" <?php if( $_POST['gender'] == "Female"){ echo "selected"; } ?>>Female</option>
                </select>
            </div>

            <?php
      } else {
      ?>

            <input name="gender" type="hidden" class="input" value="Unknown">
            <?php
      }
      ?>

            <?php

      if( $settings['showSalesPerson'] == "show" ) {
      ?>
            <div class="formcolumn">
                <select id="salesperson" name="salesperson">
                    <option value="">Salesperson (optional)</option>
                    <?php
                    $AbcUrl = "https://api.abcfinancial.com/rest/" . $clubNumber . "/employees/salespersons";
                    $thisData = array(
                        "clubNumber" => $clubNumber
                    );
                    $salesdata = json_decode(callApi("GET", $AbcUrl, $thisData), false);

                    foreach($salesdata->salespersons as &$salesperson){
                        echo '<option value = "' . $salesperson->employeeId . '">' . $salesperson->name . '</option>';
                    }
                    //var_dump($salesdata);
                ?>
                </select>
            </div>
            <?php
      } else {
      ?>
            <input type="hidden" id="salesperson" name="salesperson" value="">

            <?php
      }
      ?>
            <div style="clear:both"></div>

        </fieldset>
    </div>
    <div class="tab">
        <fieldset>
            <legend>Credit Card Information</legend>
            <?php
    if( $settings['bankOption'] != "" ){
          $bankOption = $settings['bankOption'];
      } else {
          $bankOption = "optional";
      }


      //if($bankOption == "optional" || $bankOption == "required"){
         // echo "<p>Used for your down payment.</p>";
    //  }

      ?>

            <div class="formcolumn">
                <label>First Name</label>
                <input name="todayCcFirstName" type="text" required class="input" placeholder="First Name" value="<?php echo $_POST['todayCcFirstName']; ?>">
            </div>
            <div class="formcolumn">
                <label>Last Name</label>
                <input name="todayCcLastName" type="text" required class="input" placeholder="Last Name" value="<?php echo $_POST['todayCcLastName']; ?>">
            </div>
            <div style="clear:both"></div>
            <div class="formcolumn" style="width:20%">
                <label>Type</label>
                <select name="todayCcType" required>
                    <option value="visa" <?php if( $_POST['todayCcType'] == "visa"){echo "selected"; } ?>>Visa</option>
                    <option value="mastercard" <?php if( $_POST['todayCcType'] == "mastercard"){echo "selected"; } ?>>MasterCard</option>
                    <option value="americanexpress" <?php if( $_POST['todayCcType'] == "americanexpress"){echo "selected"; } ?>>AmEx</option>
                    <option value="discover" <?php if( $_POST['todayCcType'] == "discover"){echo "selected"; } ?>>Discover</option>
                </select>
            </div>
            <div class="formcolumn" style="width:80%">
                <label>Card Number</label>
                <input name="todayCcAccountNumber" type="text" required class="input" value="<?php echo $_POST['todayCcAccountNumber']; ?>">
            </div>
            <div style="clear:both"></div>
            <div class="formcolumn">
                <label>Expiration</label>
                <div class="formcolumn">
                    <select name="todayCcExpMonth" required>
                        <option value="">Month</option>
                        <?php if( $_POST['todayCcExpMonth']){ ?>
                        <option value="<?php echo $_POST['todayCcExpMonth']; ?>" selected><?php echo $_POST['todayCcExpMonth']; ?></option>
                        <?php } ?>
                        <option value="01">01</option>
                        <option value="02">02</option>
                        <option value="03">03</option>
                        <option value="04">04</option>
                        <option value="05">05</option>
                        <option value="06">06</option>
                        <option value="07">07</option>
                        <option value="08">08</option>
                        <option value="09">09</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                    </select>
                </div>
                <div class="formcolumn">
                    <select name="todayCcExpYear" required>
                        <option value="">Year</option>
                        <?php if( $_POST['todayCcExpYear']){ ?>
                        <option value="<?php echo $_POST['todayCcExpYear']; ?>" selected><?php echo $_POST['todayCcExpYear']; ?></option>
                        <?php } ?>
                        <option value="2020">2020</option>
                        <option value="2021">2021</option>
                        <option value="2022">2022</option>
                        <option value="2023">2023</option>
                        <option value="2024">2024</option>
                        <option value="2025">2025</option>
                        <option value="2026">2026</option>
                        <option value="2027">2027</option>
                        <option value="2028">2028</option>
                        <option value="2029">2029</option>
                        <option value="2030">2030</option>
                        <option value="2031">2031</option>
                    </select>
                </div>
                <div style="clear:both"></div>
            </div>
            <div class="formcolumn">
                <div class="formcolumn">
                    <label>CVV</label>
                    <input name="todayCcCvvCode" type="text" required class="input" value="<?php echo $_POST['todayCcCvvCode']; ?>">
                </div>
                <div class="formcolumn">
                    <label>Billing Zip</label>
                    <input name="todayCcBillingZip" type="text" required class="input" value="<?php echo $_POST['todayCcBillingZip']; ?>">
                </div>
                <div style="clear:both"></div>
            </div>
            <div style="clear:both"></div>
            <?php


      if($bankOption == "optional"){
        ?>
            <div style="<?php if( $bankOption == "required" || $bankOption == "hide" ){ echo 'display:none;
                                                        '; } else { echo 'display:block;
                                                        '; } ?> border-top:1px dotted #ddd; padding-top:10px; margin-top:10px;">
                <label><strong>Select a payment method for your recurring membership dues:</strong></label>
                <?php if( get_option('iCart_abc_clubName') == "The Dynamic Fitness" ) { ?>

                <table>
                    <tr>
                        <td style="width:30px"><input name="sameBilling" type="radio" value="true" <?php if($_POST['sameBilling'] != "false") { echo " checked "; } ?> onClick="hideElement()"></td>
                        <td> Credit Card </td>
                    </tr>
                    <tr>
                        <td><input name="sameBilling" type="radio" value="false" <?php if($_POST['sameBilling'] == "false") { echo " checked "; } ?> onClick="showElement()"></td>
                        <td> Bank Account (ACH) <br>
                            <strong>*Select to earn a $5 Amazon Gift Certificate!</strong>
                        </td>
                    </tr>
                </table>
                <?php } else { ?>
                <table>
                    <tr>
                        <td style="width:30px"><input name="sameBilling" type="radio" value="true" <?php if($_POST['sameBilling'] != "false") { echo " checked "; } ?> onClick="hideElement()"></td>
                        <td> Credit Card </td>
                    </tr>
                    <tr>
                        <td><input name="sameBilling" type="radio" value="false" <?php if($_POST['sameBilling'] == "false") { echo " checked "; } ?> onClick="showElement()"></td>
                        <td> Bank Account (ACH) </td>
                    </tr>
                </table>
                <?php } ?>
            </div>
            <?php } else { ?>
            <input name="sameBilling" type="hidden" value="false">

            <?php } ?>
        </fieldset>
        <?php
      if($bankOption == "optional" || $bankOption == "required"){

      ?>

        <fieldset id="icartbankinfo" style="<?php if( $bankOption == "optional" ){ echo 'display:none;
                                                        '; } else { echo 'display:block;
                                                        '; } ?> margin-top:20px">
            <legend>Bank Info</legend>
            <div style="margin-top:8px; margin-bottom:14px; color:#999">Please enter your banking information for your <i>recurring dues</i>:</div>
            <div class="formcolumn">
                <label>First Name</label>
                <input name="draftAccountFirstName" type="text" class="input" placeholder="Account First Name" value="<?php echo $_POST['draftAccountFirstName']; ?>">
            </div>
            <div class="formcolumn">
                <label>Last Name</label>
                <input name="draftAccountLastName" type="text" class="input" placeholder="Account Last Name" value="<?php echo $_POST['draftAccountLastName']; ?>">
            </div>
            <div style="clear:both"></div>
            <div class="formcolumn" style="width:33%">
                <label>Type</label>
                <select name="draftAccountType" required>
                    <option value="checking" <?php if( $_POST['draftAccountType'] == "checking"){echo "selected"; } ?>>checking</option>
                    <option value="savings" <?php if( $_POST['draftAccountType'] == "savings"){echo "selected"; } ?>>savings</option>
                </select>
            </div>
            <div class="formcolumn" style="width:33%">
                <label>Routing #</label>
                <input name="draftAccountRoutingNumber" type="text" class="input" placeholder="Routing Number" value="<?php echo $_POST['draftAccountRoutingNumber']; ?>">
            </div>
            <div class="formcolumn" style="width:33%">
                <label>Account #</label>
                <input name="draftAccountNumber" type="text" class="input" placeholder="Account Number" value="<?php echo $_POST['draftAccountNumber']; ?>">
            </div>
            <div style="clear:both"></div>
        </fieldset>


        <?php }




      //Terms Popup and Checkbox
      if( $settings['showAgreementTerms'] == "show" ) {
      ?>

        <div style="clear:both"></div>
        <div class="checkboxColumn" style="width:8%; ">

            <input type="checkbox" name="agreementTerms" id="agreementTerms" value="yes" class="requiredCheck">
        </div>
        <div class="checkboxColumn" style="width:90%; padding-left:2%">

            I have read and agree to <?php echo $clubName; ?>'s <a class="termPop icart-popup-link"> terms &amp;
                conditions</a> for this membership agreement.

        </div>

        <?php
        }

        //Notes Popup and Checkbox
        if ( $settings['showAgreementNotes'] == "show" ) {
            ?>

        <div style="clear:both"></div>
        <div class="checkboxColumn" style="width:8%; ">

            <input type="checkbox" name="agreementNote" id="agreementNote" value="yes" class="requiredCheck">
        </div>
        <div class="checkboxColumn" style="width:90%; padding-left:2%">

           I have read and agree to the <a class="notePop icart-popup-link">notes</a> for this membership agreement.

        </div>

        <?php
        }

        //ABC Privacy Popup and Checkbox
        if ( $settings['showABCPolicy'] == "show" ) {
            ?>

        <div style="clear:both"></div>
        <div class="checkboxColumn" style="width:8%; ">

            <input type="checkbox" name="agreementPrivacy" id="agreementPrivacy" value="yes" class="requiredCheck">
        </div>
        <div class="checkboxColumn" style="width:90%; padding-left:2%">

            I have read and agree to the payment processor's <a class="AbcPrivacyPop icart-popup-link">privacy policy</a> and the <a class="AbcTermsPop  icart-popup-link">payment terms &amp; conditions</a>.

        </div>
        <div style="clear:both"></div>
        <?php
      }



       //show or hide human verification based on widget choice
        $humanVerification = $settings['humanVerification'];
        switch ($humanVerification) {
            case "show":

                $chars = str_split($clubNumber);
                $imageString = "";
                foreach($chars as &$char){
                    $imageString .= '<img src = "' . PLUGIN_URL . 'assets/images/' . $char . '.jpg" style = "width:35px; height:35px; float:left">';

                }

                echo '
                                                        <fieldset>
                                                        <legend>Human verification</legend>
                                                        <div class = "formcolumn" style = "width:auto">
                                                        <div class = "mixedNumbaz" style = "padding:10px; border:1px solid #ddd; margin-top:25px">

                                                        ' . $imageString . '
                                                        <div style = "clear:both"></div>

                                                        </div>

                                                        </div>
                                                        <div class = "formcolumn" style = "width:35%">

                                                        <label class = "humanVerify">Type the numbers:</label>

                                                        <input type = "text" name = "humanVerify" id = "humanVerify" required>
                                                        <div style = "clear:both"></div>

                                                        </div>
                                                        <div style = "clear:both"></div>
                                                        </fieldset>
                                                        ';



                //$plugins_url;

                //https://join.icart.ai/wp-content/uploads/2020/10/1.jpg

                break;

            case "hide":

                break;
        }
        ?>
    </div>
    <?php
      if ($error){
      ?>
    <input type="submit" value="Submit" name="submit" >
    <div style="clear:both;"></div>
    <?php  } else { ?>
    <div style="overflow:auto;">
        <div style="text-align: center; margin-top:12px;">
            <button type="button" id="prevBtn" onclick="nextPrev(-1)" class="backbutton">◀ Previous</button>
            <button type="button" id="nextBtn" onclick="nextPrev(1); " class="nextbutton">Next ▶︎</button><img src="https://clubflow.us/wp-content/uploads/2020/09/ZZ5H1.gif" width="60" style="width:60px; display:none; margin:0 auto;" id="standby">
        </div>
    </div>

    <!-- Circles which indicates the steps of the form: -->
    <div style="text-align:center;margin-top:30px; border-top:1px solid #f9f9f9; padding-top:30px"> <span class="step"></span> <span class="step"></span> <span class="step"></span></div>
    <!---->
    <?php  } ?>
</form>
<script>
    
    var InputMask = function ( opts ) {
  if ( opts && opts.masked ) {
    // Make it easy to wrap this plugin and pass elements instead of a selector
    opts.masked = typeof opts.masked === string ? document.querySelectorAll( opts.masked ) : opts.masked;
  }

  if ( opts ) {
    this.opts = {
      masked: opts.masked || document.querySelectorAll( this.d.masked ),
      mNum: opts.mNum || this.d.mNum,
      mChar: opts.mChar || this.d.mChar,
      error: opts.onError || this.d.onError
    }
  } else {
    this.opts = this.d;
    this.opts.masked = document.querySelectorAll( this.opts.masked );
  }

  this.refresh( true );
};

var inputMask = {

  // Default Values
  d: {
    masked : '.masked',
    mNum : 'XdDmMyY9',
    mChar : '_',
    onError: function(){}
  },

  refresh: function(init) {
    var t, parentClass;

    if ( !init ) {
      this.opts.masked = document.querySelectorAll( this.opts.masked );
    }

    for(i = 0; i < this.opts.masked.length; i++) {
      t = this.opts.masked[i]
      parentClass = t.parentNode.getAttribute('class');

      if ( !parentClass || ( parentClass && parentClass.indexOf('shell') === -1 ) ) {
        this.createShell(t);
        this.activateMasking(t);
      }
    }
  },

  // replaces each masked t with a shall containing the t and it's mask.
  createShell : function (t) {
    var wrap = document.createElement('span'),
        mask = document.createElement('span'),
        emphasis = document.createElement('i'),
        tClass = t.getAttribute('class'),
        pTxt = t.getAttribute('placeholder'),
        placeholder = document.createTextNode(pTxt);

    t.setAttribute('maxlength', placeholder.length);
    t.setAttribute('data-placeholder', pTxt);
    t.removeAttribute('placeholder');


    if ( !tClass || ( tClass && tClass.indexOf('masked') === -1 ) ) {
      t.setAttribute( 'class', tClass + ' masked');
    }

    mask.setAttribute('aria-hidden', 'true');
    mask.setAttribute('id', t.getAttribute('id') + 'Mask');
    mask.appendChild(emphasis);
    mask.appendChild(placeholder);

    wrap.setAttribute('class', 'shell');
    wrap.appendChild(mask);
    t.parentNode.insertBefore( wrap, t );
    wrap.appendChild(t);
  },

  setValueOfMask : function (e) {
    var value = e.target.value,
        placeholder = e.target.getAttribute('data-placeholder');

    return "<i>" + value + "</i>" + placeholder.substr(value.length);
  },

  // add event listeners
  activateMasking : function (t) {
    var that = this;
    if (t.addEventListener) { // remove "if" after death of IE 8
      t.addEventListener('keyup', function(e) {
        that.handleValueChange.call(that,e);
      }, false);
    } else if (t.attachEvent) { // For IE 8
        t.attachEvent('onkeyup', function(e) {
        e.target = e.srcElement;
        that.handleValueChange.call(that, e);
      });
    }
  },

  handleValueChange : function (e) {
    var id = e.target.getAttribute('id');

    if(e.target.value == document.querySelector('#' + id + 'Mask i').innerHTML) {
      return; // Continue only if value hasn't changed
    }

    document.getElementById(id).value = this.handleCurrentValue(e);
    document.getElementById(id + 'Mask').innerHTML = this.setValueOfMask(e);

  },

  handleCurrentValue : function (e) {
    var isCharsetPresent = e.target.getAttribute('data-charset'),
        placeholder = isCharsetPresent || e.target.getAttribute('data-placeholder'),
        value = e.target.value, l = placeholder.length, newValue = '',
        i, j, isInt, isLetter, strippedValue;

    // strip special characters
    strippedValue = isCharsetPresent ? value.replace(/\W/g, "") : value.replace(/\D/g, "");

    for (i = 0, j = 0; i < l; i++) {
        isInt = !isNaN(parseInt(strippedValue[j]));
        isLetter = strippedValue[j] ? strippedValue[j].match(/[A-Z]/i) : false;
        matchesNumber = this.opts.mNum.indexOf(placeholder[i]) >= 0;
        matchesLetter = this.opts.mChar.indexOf(placeholder[i]) >= 0;
        if ((matchesNumber && isInt) || (isCharsetPresent && matchesLetter && isLetter)) {
                newValue += strippedValue[j++];
          } else if ((!isCharsetPresent && !isInt && matchesNumber) || (isCharsetPresent && ((matchesLetter && !isLetter) || (matchesNumber && !isInt)))) {
                //this.opts.onError( e ); // write your own error handling function
                return newValue;
        } else {
            newValue += placeholder[i];
        }
        // break if no characters left and the pattern is non-special character
        if (strippedValue[j] == undefined) {
          break;
        }
    }
    if (e.target.getAttribute('data-valid-example')) {
      return this.validateProgress(e, newValue);
    }
    return newValue;
  },

  validateProgress : function (e, value) {
    var validExample = e.target.getAttribute('data-valid-example'),
        pattern = new RegExp(e.target.getAttribute('pattern')),
        placeholder = e.target.getAttribute('data-placeholder'),
        l = value.length, testValue = '';

    //convert to months
    if (l == 1 && placeholder.toUpperCase().substr(0,2) == 'MM') {
      if(value > 1 && value < 10) {
        value = '0' + value;
      }
      return value;
    }
    // test the value, removing the last character, until what you have is a submatch
    for ( i = l; i >= 0; i--) {
      testValue = value + validExample.substr(value.length);
      if (pattern.test(testValue)) {
        return value;
      } else {
        value = value.substr(0, value.length-1);
      }
    }

    return value;
  }
};

for ( var property in inputMask ) {
  if (inputMask.hasOwnProperty(property)) {
    InputMask.prototype[ property ] = inputMask[ property ];
  }
}

//  Declaritive initalization
(function(){
  var scripts = document.getElementsByTagName('script'),
      script = scripts[ scripts.length - 1 ];
  if ( script.getAttribute('data-autoinit') ) {
    new InputMask();
  }
})();

    
</script>
<?php
$abcWebHook = "https://hooks.zapier.com/hooks/catch/1226098/orpfma9/";
$memberWebHook = "https://hooks.zapier.com/hooks/catch/1226098/og13pwq/";
if ( get_option( 'iCart_abc_webhook' ) ) {
  $abcWebHook = get_option( 'iCart_abc_webhook' );
}
$dateStamp = date( "Y-m-d" );
?>
<?php
      if ($error){
      ?>
<style>
    .tab {
        display: block;
    }

</style>
<?php } else { ?>

<?php  }
                                                //end if !error js

                                                ?>
<script>
    function getWidth() {
        return Math.max(
            document.body.scrollWidth,
            document.documentElement.scrollWidth,
            document.body.offsetWidth,
            document.documentElement.offsetWidth,
            document.documentElement.clientWidth
        );
    }


    //show or hide bank account info
    var elem = document.getElementById("icartbankinfo");

    function hideElement() {
        elem.style.display = 'none';
    };

    function showElement() {
        elem.style.display = 'block';
    };


    //this needs to be moved to assets/js/icart.js and the enqueued. Also campaign needs to be addressed somehow
    function zapcontact() {
        var firstName = document.getElementById("firstName").value;
        var lastName = document.getElementById("lastName").value;
        var email = document.getElementById("email").value;
        var cellPhone = document.getElementById("cellPhone").value;
        var homePhone = document.getElementById("homePhone").value;
        var mobilephone = document.getElementById("cellPhone").value;
        var optIn = "no";
        var optInCheckBox = document.getElementById("optIn");

        if (optInCheckBox.checked == true) {
            optIn = "yes";
        } else {
            optIn = "no";
        }
        var optIn = document.getElementById("optIn").value;
        var location = "<?php echo $_GET['club']; ?>";
        var language = "<?php echo $language; ?>";

        var zapurl = "<?php echo $abcWebHook; ?>?clubName=<?php echo get_option('iCart_abc_clubName'); ?>&firstname=" + firstName + "&lastname=" + lastName + "&email=" + email + "&location=" + location + "&mobilephone=" + mobilephone + "&campaign=<?php echo $thisCampaign; ?>&datestamp=<?php echo $datestamp; ?>" + "&optIn=" + optIn + "&language=" + language;
        fetch(zapurl);
    }

    //Multistep form js
    var currentTab = 0; // Current tab is set to be the first tab (0)
    showTab(currentTab); // Display the current tab
    function showTab(n) {
        // This function will display the specified tab of the form ...
        var x = document.getElementsByClassName("tab");
        x[n].style.display = "block";
        // ... and fix the Previous/Next buttons:


        if (n == 0) {
            document.getElementById("prevBtn").style.display = "none";
            document.getElementById("icart-summary-column").style.display = "none";
        } else {
            document.getElementById("prevBtn").style.display = "inline";
            document.getElementById("icart-summary-column").style.display = "block";

        }
        if (n == (x.length - 1)) {
            document.getElementById("nextBtn").innerHTML = "Submit";
        } else {
            document.getElementById("nextBtn").innerHTML = "Next";
        }
        // ... and run a function that displays the correct step indicator:
        fixStepIndicator(n);
    }

    function nextPrev(n) {
        // This function will figure out which tab to display
        var x = document.getElementsByClassName("tab");

        // Exit the function if any field in the current tab is invalid:
        if (n == 1 && !validateForm()) return false;
        // Hide the current tab:
        x[currentTab].style.display = "none";
        // Increase or decrease the current tab by 1:
        currentTab = currentTab + n;
        if (currentTab == 1) {
            zapcontact();
        }
        // if you have reached the end of the form... :
        if (currentTab >= x.length) {
            //...the form gets submitted:
            document.getElementById("nextBtn").style.display = 'none';
            document.getElementById("prevBtn").style.display = 'none';
            document.getElementById("standby").style.display = 'block';
            //document.getElementById("nextBtn").setAttribute('disabled', 'disabled');
            document.getElementById("regForm").submit();

            return false;
        }
        // Otherwise, display the correct tab:
        showTab(currentTab);
    }

    function validateForm() {
        // This function deals with validation of the form fields
        var x, y, i, valid = true;

        <?php if($error){ ?>
            x = document.getElementsByClassName("tab");
            y = document.querySelectorAll("[required]");
            checksArr = document.querySelectorAll(".requiredCheck");

        <?php } else { ?>
            x = document.getElementsByClassName("tab");
            y = x[currentTab].querySelectorAll("[required]");
            checksArr = x[currentTab].querySelectorAll(".requiredCheck");
        <?php } ?>

        // A loop that checks every input field in the current tab:
        for (i = 0; i < y.length; i++) {
            // If a field is empty...
            if (y[i].value == "") {
                // add an "invalid" class to the field:
                y[i].className += " invalid";

                // and set the current valid status to false:

                valid = false;
            }
            if(y[i].type == 'email'){
                var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
                if(document.getElementById("email").value.match(mailformat)){
                    document.getElementById("emailvalidationwarning").style.visibility = 'hidden';
                    y[i].className = "input";
                } else {
                    y[i].className += " invalid";
                    valid = false;
                    document.getElementById("emailvalidationwarning").style.visibility = 'visible';
                }

            }
            if(y[i].type == 'tel'){
                var phoneformat = /^\d{10}$/;
                if(document.getElementById("cellPhone").value.match(phoneformat)){
                    document.getElementById("cellphonevalidationwarning").style.visibility = 'hidden';
                } else {
                    y[i].className += " invalid";
                    valid = false;
                    document.getElementById("cellphonevalidationwarning").style.visibility = 'visible';
                }
                

            }
        }



        for (i = 0; i < checksArr.length; i++) {
            // If a field is empty...
            if (!checksArr[i].checked) {
                // add an "invalid" class to the field:
                checksArr[i].className += " badcheck invalid";
                checksArr[i].style.borderColor = 'red';
                // and set the current valid status to false:
                valid = false;
            }
        }




        <?php if($error){ ?>
            // If the valid status is true, submit form
                if (valid) {

                } else {
                    event.preventDefault();
                }
        <?php } else { ?>
           // If the valid status is true, mark the step as finished and valid:
            if (valid) {
                document.getElementsByClassName("step")[currentTab].className += " finish";
            }
        <?php } ?>


        return valid; // return the valid status
    }

    var validateForm = {
        required: function(value) {
            return value !== '';
        },
        phone: function(value) {
            return value.match(/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im);
        },
        email: function(value) {
            return value.match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
        }

    }

    function validate() {
	  var form = document.getElementById('regForm'),
		  inputsArr = form.querySelectorAll('input'),
		  errorMessage = document.querySelector(".ui.error.message"),
		  successMessage = document.querySelector(".ui.success.message");

	  form.addEventListener('submit', function(e){
		var i = 0;
		while (i < inputsArr.length) {
		  var attr = inputsArr[i].getAttribute('data-validation'),
			  rules = attr ? attr.split(' ') : '',
			  parent = inputsArr[i].closest(".field"),
			  j = 0;
		  while (j < rules.length) {
			if(!validations[rules[j]](inputsArr[i].value)) {
			  e.preventDefault();

			  errorMessage.className = "ui error message";
			  errorMessage.innerHTML = "Please enter a valid " + inputsArr[i].name + "'";
			  parent.className = "field error";
			  return false;
			}
			errorMessage.className = "ui error message hidden";
			parent.className = "field";
			j++;
		  }
		  i++;
		}
		e.preventDefault();
		successMessage.className = "ui success message";
		form.outerHTML = "";
		delete form;
	  }, false)
	}


    function fixStepIndicator(n) {
        // This function removes the "active" class of all steps...
        var i, x = document.getElementsByClassName("step");
        for (i = 0; i < x.length; i++) {
            x[i].className = x[i].className.replace(" active", "");
        }
        //... and adds the "active" class to the current step:
        x[n].className += " active";
    }

    jQuery(document).ready(function($) {
       // var requiredCheckboxes = $(':checkbox[required]');


    });

</script>



<?php
                                            }

                                            protected function _content_template() {

                                            }
                                        }
