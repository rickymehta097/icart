<?php
/**
 * Main iCart functions
 *
 * Contents:
 * 1. Clubs
 * 2. Plans
 * 3. Admin
 * 4. Misc
 */
add_action( 'admin_init', 'iCart_settings_init' );
//add_action( 'admin_init', 'iCart_register_settings' );
add_action( 'admin_menu', 'iCart_register_options_page' );
//add_action( 'admin_submenu', 'iCart_plan_resync_page' );

$plugins_url = plugin_dir_url( __FILE__ );
define( 'PLUGIN_URL', $plugins_url  );


/*
 * Custom CSS
*/
//for dev purpose, prevents the css from being cached.
//$rand_css = '1.9.2' . rand(12, 999);
$rand_css = '1.9.2';
wp_register_style( 'icart_css', $plugins_url . 'assets/css/icart.css', false, $rand_css );
wp_enqueue_style( 'icart_css', $plugins_url . 'assets/css/icart.css' );


//Generic API call/response function, which can be used for ABC or any other API
function CallAPI( $method, $url, $data = false ) {
  //initiate curl. The default method is GET if no other method is passed.
  $curl = curl_init();
  switch ( $method ) {
    case "POST":
      curl_setopt( $curl, CURLOPT_POST, 1 );
      if ( $data )
        curl_setopt( $curl, CURLOPT_POSTFIELDS, $data );
      break;
    case "PUT":
      curl_setopt( $curl, CURLOPT_PUT, 1 );
      break;
    default:
      if ( $data )
        $url = sprintf( "%s?%s", $url, http_build_query( $data ) );
  }

  // Accepts an API endpoint URL
  curl_setopt( $curl, CURLOPT_URL, $url );
  curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
  curl_setopt( $curl, CURLOPT_URL, $url );
  curl_setopt( $curl, CURLOPT_HTTPHEADER, array(
    'app_id: ' . APP_ID,
    'app_key: ' . APP_KEY,
    'Content-Type: application/json',
    'Accept: application/json'
  ) );

  $result = curl_exec( $curl );

  curl_close( $curl );

  return $result;
}

//Cron jobs - used to store the various arrays for a club in order to prevent lag when calling the API
function icart_deactivate() {
   // wp_clear_scheduled_hook( 'icart_cron' );
}

//initiates the cron job twice daily
add_action('init', function() {
    //add_action( 'icart_cron', 'ABCDailyArrays' );
    //register_deactivation_hook( __FILE__, 'icart_deactivate' );

    /*if (! wp_next_scheduled ( 'icart_cron' )) {
        wp_schedule_event( time(), 'twicedaily', 'icart_cron' );
    }*/
});

//creates the arrays to hold in order to prevent API call lag
function ABCDailyArrays() {
   update_option( 'iCart_abc_clubArray', ABCClubArray() );
}



//ABC API functions
//API Documentation: https://abcfinancial.3scale.net/docs
//The club number(s) must be manually set in the WP Admin backend - Settings: iCart

//Call the ABC /plans endpoint and convert response to an array
//To use: ABCPlanList(get_option('iCart_abc_clubNumber'), $planId)
//To avoid calling the API constantly which causes latency, you can hold the ABCPlanArray in a variable and then reference that variable in the below functions, e.g. $planArray = ABCPlanList(get_option('iCart_abc_clubNumber'), $planId); ABCPlanLink($planArray);
function ABCPlanArray( $club, $planId ) {
  $AbcUrl = "https://api.abcfinancial.com/rest/" . $club . "/clubs/plans/" . $planId;
  $thisMethod = "";
  $thisData = array(
    "clubNumber" => $club,
    "planId" => $planId
  );
  return json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );
}



//returns html content from a page, given a URL and a CSS Class
function getHtmlContentByClass($url, $class){

    $html = file_get_contents( $url ); //get the html returned from the following url
    $doc = new DOMDocument();

    libxml_use_internal_errors(TRUE); //disable libxml errors

    if(!empty($html)){ //if any html is actually returned

        $doc->loadHTML($html);
        libxml_clear_errors(); //remove errors for yucky html

        $xpath = new DOMXPath($doc);


        //get all the h2's with an id
        $row = $xpath->query("//*[contains(@class, '$class')]");

        $htmlString = $doc->saveHTML($row->item(0));
        $finalHtml = str_replace("href=", ' target="_blank" href=', $htmlString);

        return $finalHtml;


    } else {

        return 'No content found.';
    }


}
    
    



//Gets the published plans and updates pricing info.
function ABCPlanResync(){
        // Initialize database object
    global $wpdb;

    $category_id = get_cat_ID('plans');
    $args = array(  'category' => $category_id, 'post_status'  => 'publish', 'numberposts' => -1 );
    $plan_posts = get_posts( $args );

     foreach ($plan_posts as $post){
        $thisId = $post->ID;
        $clubNumber = get_post_meta($thisId,'clubNumber',true);
         if(isset($_POST['clubNumber'])){
             //$clubNumber = $_POST['clubNumber'];
         }
        $thisPlanId = get_post_meta($thisId,'planId',true);
        if($thisPlanId != ""){
            $planArray = ABCPlanArray($clubNumber, $thisPlanId);
            $scheduleFrequency = $planArray->paymentPlan->scheduleFrequency;
            $dueDay = $planArray->paymentPlan->dueDay;
            $firstDueDate = $planArray->paymentPlan->firstDueDate;
            $activePresale = $planArray->paymentPlan->activePresale;
            $expirationDate = $planArrady->paymentPlan->expirationDate;
            $onlineSignupAllowedPaymentMethods = $planArray->paymentPlan->onlineSignupAllowedPaymentMethods;
            $preferredPaymentMethod = $planArray->paymentPlan->preferredPaymentMethod;
            $totalContractValue = $planArray->paymentPlan->totalContractValue;
            $downPaymentName = $planArray->paymentPlan->downPaymentName;
            $downPaymentTotalAmount = $planArray->paymentPlan->downPaymentTotalAmount;
            $scheduleTotalAmount = $planArray->paymentPlan->scheduleTotalAmount;

            $clubFeeTotalAmount = $planArray->paymentPlan->clubFeeTotalAmount;
            $planValidation = $planArray->paymentPlan->planValidation;
            $planLink = ABCPlanLink( $planArray );
            $membershiptype = $planArray->paymentPlan->membershipType;

            $agreementTerm = $planArray->paymentPlan->agreementTerm;
            $agreementDescription = $planArray->paymentPlan->agreementDescription;
            $agreementNote = $planArray->paymentPlan->agreementNote;
            $agreementTerms = $planArray->paymentPlan->agreementTerms;



            if ( $planArray->paymentPlan->downPayments ) {
            foreach ( $planArray->paymentPlan->downPayments as $downPayment ) {
                $thisName = $downPayment->name;
                $thisTax = $downPayment->tax;
                $thisSubTotal = $downPayment->subTotal;
                $thisTotal = $downPayment->total;
                if($thisName == "Processing Fee" || $thisName == "Enrollment"  || $thisName == "Enrollment Fee"){
                    $enrollmentFee = $downPayment->subTotal;
                }
            }
            }
            $monthlyFee = 0;

            foreach ( $planArray->paymentPlan->schedules as $schedule ) {

                $profitCenter = $schedule->profitCenter;

                $scheduleDueDate = $schedule->scheduleDueDate;
                $scheduleAmount = $schedule->scheduleAmount;
                $numberOfPayments = $schedule->numberOfPayments;
                $recurring = $schedule->recurring;
                $addon = $schedule->addon;
                $defaultChecked = $schedule->defaultChecked;
                $description = $schedule->description;

                $addon = $schedule->addon;
                $allfactors = strtoupper($profitCenter . $description);
                $findme   = 'DUES';
				$findme2 = 'DFIT';
				$findme3 = 'Smgrptrn';
                $pos = strpos($allfactors, $findme);
				$pos2 = strpos($allfactors, $findme2);
				$pos3 = strpos($allfactors, $findme3);
                
                if ( $defaultChecked !== false ) {
                    +$schedulePreTaxAmount = str_replace( $schedule->schedulePreTaxAmount );
                    +$monthlyFee = $monthlyFee + $schedulePreTaxAmount;
                    
                }
                //$defaultChecked = $schedule->defaultChecked;
                //$schedules .=  $description . ',' . $schedulePreTaxAmount . ',' . $scheduleAmount . ',' . $numberOfPayments . ',' . $recurring . ',' . $scheduleDueDate . ',' . $profitCenter . '|';

                //$schedulePreTaxAmount += $schedulePreTaxAmount;
            }

            if( $scheduleTotalAmount == "$0.00"){
                $schedulePreTaxAmount = "0.00";
            }

            if($planArray->request->clubNumber){

                update_post_meta($thisId, 'scheduleFrequency', $scheduleFrequency );
                update_post_meta($thisId, 'downPaymentTotalAmount', $downPaymentTotalAmount );
                update_post_meta($thisId, 'schedulePreTaxAmount', $schedulePreTaxAmount );
                update_post_meta($thisId, 'monthlyfee', $monthlyFee );
                update_post_meta($thisId, 'scheduleTotalAmount', $scheduleTotalAmount );
                update_post_meta($thisId, 'planValidation', $planValidation );
                update_post_meta($thisId, 'planLink', $planLink );
                update_post_meta($thisId, 'clubFeeTotalAmount', $clubFeeTotalAmount );
                update_post_meta($thisId, 'agreementTerm', $agreementTerm );
                update_post_meta($thisId, 'agreementTerms', $agreementTerms );
                update_post_meta($thisId, 'agreementDescription', $agreementDescription );
                update_post_meta($thisId, 'agreementNote', $agreementNote );
                update_post_meta($thisId, 'enrollmentFee', $enrollmentFee );

            }
        }
     }
    return "Plans have been successfully updated.";
}

//resync info for single club
function ABCClubResync($clubNumber){
        // Initialize database object
    global $wpdb;
    $category_id = get_cat_ID('plans');
    $args = array(
      'category' => $category_id,
      'post_status'  => 'publish',
      'numberposts' => -1,

  		'meta_query' => array(
  			array(
  				'key'   => 'clubNumber',
  				'value' => $clubNumber,
  				'compare' => '='
  			),
      ) 
     );
    $plan_posts = get_posts( $args );

     foreach ($plan_posts as $post){
        $thisId = $post->ID;
        $clubNumber = get_post_meta($thisId,'clubNumber',true);
         if(isset($_POST['clubNumber'])){
             //$clubNumber = $_POST['clubNumber'];
         }
        $thisPlanId = get_post_meta($thisId,'planId',true);
        if($thisPlanId != ""){
            $planArray = ABCPlanArray($clubNumber, $thisPlanId);
            $scheduleFrequency = $planArray->paymentPlan->scheduleFrequency;
            $dueDay = $planArray->paymentPlan->dueDay;
            $firstDueDate = $planArray->paymentPlan->firstDueDate;
            $activePresale = $planArray->paymentPlan->activePresale;
            $expirationDate = $planArrady->paymentPlan->expirationDate;
            $onlineSignupAllowedPaymentMethods = $planArray->paymentPlan->onlineSignupAllowedPaymentMethods;
            $preferredPaymentMethod = $planArray->paymentPlan->preferredPaymentMethod;
            $totalContractValue = $planArray->paymentPlan->totalContractValue;
            $downPaymentName = $planArray->paymentPlan->downPaymentName;
            $downPaymentTotalAmount = $planArray->paymentPlan->downPaymentTotalAmount;
            $scheduleTotalAmount = $planArray->paymentPlan->scheduleTotalAmount;

            $clubFeeTotalAmount = $planArray->paymentPlan->clubFeeTotalAmount;
            $planValidation = $planArray->paymentPlan->planValidation;
            $planLink = ABCPlanLink( $planArray );
            $membershiptype = $planArray->paymentPlan->membershipType;

            $agreementTerm = $planArray->paymentPlan->agreementTerm;
            $agreementDescription = $planArray->paymentPlan->agreementDescription;
            $agreementNote = $planArray->paymentPlan->agreementNote;
            $agreementTerms = $planArray->paymentPlan->agreementTerms;



            if ( $planArray->paymentPlan->downPayments ) {
            foreach ( $planArray->paymentPlan->downPayments as $downPayment ) {
                $thisName = $downPayment->name;
                $thisTax = $downPayment->tax;
                $thisSubTotal = $downPayment->subTotal;
                $thisTotal = $downPayment->total;
                if($thisName == "Processing Fee" || $thisName == "Enrollment"  || $thisName == "Enrollment Fee"){
                    $enrollmentFee = $downPayment->subTotal;
                }
            }
            }
            $monthlyFee = 0;
            $schedulePreTaxAmount = 0;
            foreach ( $planArray->paymentPlan->schedules as $schedule ) {

                $profitCenter = $schedule->profitCenter;

                $scheduleDueDate = $schedule->scheduleDueDate;
                $scheduleAmount = $schedule->scheduleAmount;
                $numberOfPayments = $schedule->numberOfPayments;
                $recurring = $schedule->recurring;
                $addon = $schedule->addon;
                $defaultChecked = $schedule->defaultChecked;
                $description = $schedule->description;

                $addon = $schedule->addon;
                $allfactors = strtoupper($profitCenter . $description);
                $findme   = 'DUES';
				$findme2 = 'DFIT';
                $pos = strpos($allfactors, $findme);
				$pos2 = strpos($allfactors, $findme2);


                if ( $pos !== false || $pos2 !== false ) {
                    $thisamount = floatval(str_replace( '$', '', $schedule->schedulePreTaxAmount));
                    $monthlyFee = $monthlyFee + $thisamount;
                    $schedulePreTaxAmount = $schedulePreTaxAmount + $thisamount;
                    
                }
                
                if ( $addon && $defaultChecked ) {
                    $thisamount = floatval(str_replace( '$', '', $schedule->schedulePreTaxAmount));
                    $monthlyFee = $monthlyFee + $thisamount;
                    $schedulePreTaxAmount = $schedulePreTaxAmount + $thisamount;
                }
                //$defaultChecked = $schedule->defaultChecked;
                //$schedules .=  $description . ',' . $schedulePreTaxAmount . ',' . $scheduleAmount . ',' . $numberOfPayments . ',' . $recurring . ',' . $scheduleDueDate . ',' . $profitCenter . '|';

                //$schedulePreTaxAmount += $schedulePreTaxAmount;
            }

            if( $scheduleTotalAmount == "$0.00"){
                $schedulePreTaxAmount = "0.00";
            }

            if($planArray->request->clubNumber){

                update_post_meta($thisId, 'scheduleFrequency', $scheduleFrequency );
                update_post_meta($thisId, 'downPaymentTotalAmount', $downPaymentTotalAmount );
                update_post_meta($thisId, 'schedulePreTaxAmount', $schedulePreTaxAmount );
                update_post_meta($thisId, 'monthlyFee', $monthlyFee );
                update_post_meta($thisId, 'scheduleTotalAmount', $scheduleTotalAmount );
                update_post_meta($thisId, 'planValidation', $planValidation );
                update_post_meta($thisId, 'planLink', $planLink );
                update_post_meta($thisId, 'clubFeeTotalAmount', $clubFeeTotalAmount );
                update_post_meta($thisId, 'agreementTerm', $agreementTerm );
                update_post_meta($thisId, 'agreementTerms', $agreementTerms );
                update_post_meta($thisId, 'agreementDescription', $agreementDescription );
                update_post_meta($thisId, 'agreementNote', $agreementNote );
                update_post_meta($thisId, 'enrollmentFee', $enrollmentFee );

            }
        }
     }
    return "Plans have been successfully updated.";
}
//ingest club and plans (accepts club number)
function ABCClubIngest($thisclub){
    //create club category
    wp_insert_term('Clubs', 'category', array(
                'description' => 'Club Landing Pages',
                'slug' => 'clubs'
    ));
    $term = get_term_by('slug', 'clubs', 'category');
    $term_ID = $term->term_id;
    $clubCatId = array( $term_ID) ;


    $clubNumber = $thisclub;

    //create plan categories
    wp_insert_term('Plans', 'category', array(
        'description' => 'Club Plans',
        'slug' => 'plans'
    ));
    $term = get_term_by('slug', 'plans', 'category');
    $term_ID = $term->term_id;
    $planCatId = $term_ID;

    wp_insert_term('Default Plans', 'category', array(
        'description' => 'Default Plans',
        'slug' => 'default-plans',
        'parent' => $planCatId
    ));
    $term = get_term_by('slug', 'default-plans', 'category');
    $term_ID = $term->term_id;
    $defaultCatId = $term_ID;

    wp_insert_term('Promo Plans', 'category', array(
        'description' => 'Promo Plans',
        'slug' => 'promo-plans',
        'parent' => $planCatId
    ));

    $term = get_term_by('slug', 'promo-plans', 'category');
    $term_ID = $term->term_id;
    $promoCatId = $term_ID;






        $clubArray = ABCClubInfo( $clubNumber );
        if($clubArray->club->name){
            $clubName =  $clubArray->club->name;
            $clubAddress1 = $clubArray->club->address1;
            $clubAddress2 = $clubArray->club->address2;
            $clubCity = $clubArray->club->city;
            $clubState = $clubArray->club->state;
            $clubZip = $clubArray->club->postalCode;
            $clubEmail = $clubArray->club->email;
            $shortName = $clubArray->club->shortName;

            $timeZone = $clubArray->club->timeZone;

            $allowMinors = $clubArray->online->minors->allowMinors;
            $minorAge = $clubArray->online->minors->minorAge;



            $clubExcerpt = $clubAddress1 . ' ' . $clubAddress2 . '<br>' . $clubCity . ', ' . $clubState . ' ' . $clubZip;


            $post_arr = array(
                'post_title'   => $clubName,
                'post_content' => '',
                'post_excerpt' => $clubExcerpt,
                'post_status'  => 'draft',
                'post_author'  => get_current_user_id(),
                'post_category' => $clubCatId,
                'meta_input'   => array(
                    'clubName' => $clubName,
                    'clubAddress1' => $clubAddress1,
                    'clubAddress2' => $clubAddress2,
                    'clubCity' => $clubCity,
                    'clubState' => $clubState,
                    'clubZip' => $clubZip,
                    'clubNumber' => $clubNumber,
                    'clubEmail' => $clubEmail,
                    'clubPhone' => '',
                    'allowMinors' => $allowMinors,
                    'minorAge' => $minorAge,
                    'shortName' => $shortName,
                    'timeZone' => $timeZone,
                    'creditCardPaymentMethods' => $creditCardPaymentMethods


                ),

            );
            $clubPostId = wp_insert_post( $post_arr );
            $message = $clubName . ' and its plans have been ingested.
            <h3>Next Steps</h3>
            <ul>
                <li>Review club information: <a href="edit.php?category_name=clubs" target="_blank">Click here</a></li>
                <li>Review and publish club plans: <a href="edit.php?category_name=plans" target="_blank">Click here</a></li>
            </ul>';


    }




    //$clubNumber = $_POST['clubNumber'];
    $clubargs = array(
    'post_type'  => 'post',
    'category'  =>  $clubCatId,
    'meta_key'   => 'clubNumber',
    'meta_query' => array(
        array(
            'key'   => 'clubNumber',
            'value' => $clubNumber,
            'compare' => '='
        )

    )
	);
	   $clubposts = get_posts( $clubargs );
        foreach ($clubposts as $club){
            $clubId = $club->ID;
            $clubName = get_post_meta($clubId,'clubName',true);
            //insert category for club if it does not exist
            wp_insert_term($clubName, 'category', array(
                'description' => 'Plans for ' . $clubName . ' - ' . $clubNumber,
                'slug' => 'club-' . $clubNumber,
                'parent' => $planCatId // must be the ID, not name
            ));
            $term = get_term_by('slug', 'club-' . $clubNumber, 'category');
            $term_ID = $term->term_id;
            $singClubCatId = $term_ID;
        }
        $promoCode = "";
        $campaignId = "";

        //$promoCode = $promoCode;
        $thisData = "";


        $AbcUrl = "https://api.abcfinancial.com/rest/" . $clubNumber . "/clubs/plans?onlyPromoPlans=false&inClubPlans=false&ignorePlanAvailabilityWindow=false";
        $thisMethod = "";
        $response = CallAPI( $thisMethod, $AbcUrl, $thisData );

        $data = json_decode( $response , false );
        $findme = "success";
        //$promoPos = "doogle";
        $thispos = strpos($response, $findme);


    foreach ( $data->plans as & $plan ) {
       $thisPlanId = $plan->planId;
       $planArray = ABCPlanArray($clubNumber, $thisPlanId);
       if($plan->promoCode){
                   $promoCode = $plan->promoCode;
                   //array_push($fullclubArray, $thisclubArray);


        }


    $planName = $planArray->paymentPlan->planName;
    $clubNumber = $planArray->request->clubNumber;
    $planId = $planArray->paymentPlan->planId;
    $agreementTerm = $planArray->paymentPlan->agreementTerm;
    $termInMonths = $planArray->paymentPlan->termInMonths;
    $scheduleFrequency = $planArray->paymentPlan->scheduleFrequency;
    $dueDay = $planArray->paymentPlan->dueDay;
    $firstDueDate = $planArray->paymentPlan->firstDueDate;
    $activePresale = $planArray->paymentPlan->activePresale;
    $expirationDate = $planArrady->paymentPlan->expirationDate;
    $onlineSignupAllowedPaymentMethods = $planArray->paymentPlan->onlineSignupAllowedPaymentMethods;
    $preferredPaymentMethod = $planArray->paymentPlan->preferredPaymentMethod;
    $totalContractValue = $planArray->paymentPlan->totalContractValue;
    $downPaymentName = $planArray->paymentPlan->downPaymentName;
    $downPaymentTotalAmount = $planArray->paymentPlan->downPaymentTotalAmount;
    $scheduleTotalAmount = $planArray->paymentPlan->scheduleTotalAmount;
    $schedulePreTaxAmodunt = $planArray->paymentPlan->schedules->schedulePreTaxAmount;
    $clubFeeTotalAmount = $planArray->paymentPlan->clubFeeTotalAmount;
    $planValidation = $planArray->paymentPlan->planValidation;
    $planLink = ABCPlanLink( $planArray );
    $membershiptype = $planArray->paymentPlan->membershipType;
    $monthlyfee = $scheduleTotalAmount;
    $planLink = ABCPlanLink( $planArray );
    $agreementDescription = $planArray->paymentPlan->agreementDescription;
    $agreementNote = $planArray->paymentPlan->agreementNote;
    $agreementTerms = $planArray->paymentPlan->agreementTerms;

    //$category_id = get_cat_ID('Plans');
    //$category_id = get_category_by_slug( 'plans' );
    $thisCat = array($planCatId,$defaultCatId,$singClubCatId);
    $downpayments = "";
    if ( $planArray->paymentPlan->downPayments ) {
    foreach ( $planArray->paymentPlan->downPayments as $downPayment ) {

        $thisName = $downPayment->name;
        $thisTax = $downPayment->tax;
        $thisSubTotal = $downPayment->subTotal;
        $thisTotal = $downPayment->total;
        $downpayments .=  $thisName . ',' . $thisSubTotal . ',' . $thisTax . ',' . $thisTotal . '|';
        if($thisName == "Processing Fee" || $thisName == "Enrollment"  || $thisName == "Enrollment Fee"){
            $enrollmentFee = $downPayment->subTotal;
        }
    }
   $schedules = "";
   $schedulePreTaxAmount = "";

    foreach ( $planArray->paymentPlan->schedules as $schedule ) {

        $profitCenter = $schedule->profitCenter;
        $schedulePreTaxAmount = str_replace( '$', '', $schedule->schedulePreTaxAmount);
        $scheduleDueDate = $schedule->scheduleDueDate;
        $scheduleAmount = $schedule->scheduleAmount;
        $numberOfPayments = $schedule->numberOfPayments;
        $recurring = $schedule->recurring;
        $addon = $schedule->addon;
        $defaultChecked = $schedule->defaultChecked;
        $description = $schedule->description;
        $profitCenter = $schedule->profitCenter;
        $addon = $schedule->addon;
        $defaultChecked = $schedule->defaultChecked;
        //$schedules .=  $description . ',' . $schedulePreTaxAmount . ',' . $scheduleAmount . ',' . $numberOfPayments . ',' . $recurring . ',' . $scheduleDueDate . ',' . $profitCenter . '|';

        //$schedulePreTaxAmount += $schedulePreTaxAmount;
    }


  }
    if($planArray->request->clubNumber){
        $clubNumber = $planArray->request->clubNumber;
        $post_arr = array(
            'post_title'   => $planName,
            'post_content' => '',
            'post_status'  => 'draft',
            'post_author'  => get_current_user_id(),
            'post_category' => $thisCat,
            'meta_input'   => array(
                'planName' => $planName,
                'promoCode' => $promoCode,
                'clubNumber' => $clubNumber,
                'planId' => $planId,
                'agreementTerm' => $agreementTerm,
                'termInMonths' => $termInMonths,
                'scheduleFrequency' => $scheduleFrequency,
                'dueDay' => $dueDay,
                'firstDueDate' => $firstDueDate,
                'activePresale' => $activePresale,
                'expirationDate' => $expirationDate,
                'onlineSignupAllowedPaymentMethods' => $onlineSignupAllowedPaymentMethods,
                'preferredPaymentMethod' => $preferredPaymentMethod,
                'totalContractValue' => $totalContractValue,
                'downPaymentName' => $downPaymentName,
                'downPaymentTotalAmount' => $downPaymentTotalAmount,
                'scheduleTotalAmount' => $scheduleTotalAmount,
                'schedulePreTaxAmount' => $schedulePreTaxAmount,
                'clubFeeTotalAmount' => $clubFeeTotalAmount,
                'planValidation' => $planValidation,
                'planLink' => $planLink,
                'membershiptype' => $membershiptype,
                'monthlyfee' => $monthlyfee,
                'downpayments' => $downpayments,
                'schedules' => $schedules,
                'enrollmentFee' => $enrollmentFee,
                'clubName' => $clubName,
                'agreementTerms' => $agreementTerms,
                'agreementDescription' => $agreementDescription,
                'agreementNote' => $agreementNote
            ),

        );
        wp_insert_post( $post_arr );




    }
}
        $clubNumber = $thisclub;
        $promoCode = "";
        $campaignId = "";

        //$promoCode = $promoCode;
        $thisData = "";


        $AbcUrl = "https://api.abcfinancial.com/rest/" . $clubNumber . "/clubs/plans?onlyPromoPlans=true&inClubPlans=false&ignorePlanAvailabilityWindow=false";
        $thisMethod = "";
        $response = CallAPI( $thisMethod, $AbcUrl, $thisData );

        $data2 = json_decode( $response , false );
        $findme = "success";
        //$promoPos = "doogle";
        $thispos = strpos($response, $findme);


    foreach ( $data2->plans as & $plan ) {
            if($plan->promoCode){
                   $promoCode = $plan->promoCode;

            }
       $thisPlanId = $plan->planId;
       //$thisPromoCode = $_POST['promoCode'];
       $goPromo = "yes";

        if( $goPromo == "yes"){
            $planArray = ABCPlanArray($clubNumber, $thisPlanId);
            $planName = $planArray->paymentPlan->planName;
            $clubNumber = $planArray->request->clubNumber;
            $planId = $planArray->paymentPlan->planId;
            $agreementTerm = $planArray->paymentPlan->agreementTerm;
            $termInMonths = $planArray->paymentPlan->termInMonths;
            $scheduleFrequency = $planArray->paymentPlan->scheduleFrequency;
            $dueDay = $planArray->paymentPlan->dueDay;
            $firstDueDate = $planArray->paymentPlan->firstDueDate;
            $activePresale = $planArray->paymentPlan->activePresale;
            $expirationDate = $planArrady->paymentPlan->expirationDate;
            $onlineSignupAllowedPaymentMethods = $planArray->paymentPlan->onlineSignupAllowedPaymentMethods;
            $preferredPaymentMethod = $planArray->paymentPlan->preferredPaymentMethod;
            $totalContractValue = $planArray->paymentPlan->totalContractValue;
            $downPaymentName = $planArray->paymentPlan->downPaymentName;
            $downPaymentTotalAmount = $planArray->paymentPlan->downPaymentTotalAmount;
            $scheduleTotalAmount = $planArray->paymentPlan->scheduleTotalAmount;

            $clubFeeTotalAmount = $planArray->paymentPlan->clubFeeTotalAmount;
            $planValidation = $planArray->paymentPlan->planValidation;
            $planLink = ABCPlanLink( $planArray );
            $membershiptype = $planArray->paymentPlan->membershipType;
            $monthlyfee = $scheduleTotalAmount;
            $planLink = ABCPlanLink( $planArray );
            $agreementDescription = $planArray->paymentPlan->agreementDescription;
            $agreementNote = $planArray->paymentPlan->agreementNote;
            $agreementTerms = $planArray->paymentPlan->agreementTerms;


            $thisCat = array($planCatId,$promoCatId,$singClubCatId);
        $downpaymentList = "";
        if ( $planArray->paymentPlan->downPayments ) {
        foreach ( $planArray->paymentPlan->downPayments as $downPayment ) {

            $thisName = $downPayment->name;
            $thisTax = $downPayment->tax;
            $thisSubTotal = $downPayment->subTotal;
            $thisTotal = $downPayment->total;
            $downpaymentList .=  $thisName . ',' . $thisSubTotal . ',' . $thisTax . ',' . $thisTotal . '|';
            if($thisName == "Processing Fee" || $thisName == "Enrollment"  || $thisName == "Enrollment Fee"){
                $enrollmentFee = $downPayment->subTotal;
            }
        }
       $scheduleList = "";
       if ( $planArray->paymentPlan->schedules ) {
        foreach ( $planArray->paymentPlan->schedules as $schedule ) {
          if ( $i == 1 ) {
            $schedulePreTaxAmount = $schedule->schedulePreTaxAmount;
            $scheduleDueDate = $schedule->scheduleDueDate;
            $scheduleAmount = $schedule->scheduleAmount;
            $numberOfPayments = $schedule->numberOfPayments;
            $recurring = $schedule->recurring;
            $addon = $schedule->addon;
            $defaultChecked = $schedule->defaultChecked;
            $description = $schedule->description;
            $profitCenter = $schedule->profitCenter;

          }
          $scheduleList .=  $description . ',' . $schedulePreTaxAmount . ',' . $scheduleAmount . ',' . $numberOfPayments . ',' . $recurring . ',' . $scheduleDueDate . ',' . $profitCenter . '|';
        }
        $schedulePreTaxAmount = str_replace( '$', '', $schedulePreTaxAmount );
      }
      }
        if($planArray->request->clubNumber){
            $clubNumber = $planArray->request->clubNumber;
            $post_arr = array(
                'post_title'   => $planName,
                'post_content' => '',
                'post_status'  => 'draft',
                'post_author'  => get_current_user_id(),
                'post_category' => $thisCat,
                'meta_input'   => array(
                    'planName' => $planName,
                    'promoCode' => $promoCode,
                    'clubNumber' => $clubNumber,
                    'planId' => $planId,
                    'agreementTerm' => $agreementTerm,
                    'termInMonths' => $termInMonths,
                    'scheduleFrequency' => $scheduleFrequency,
                    'dueDay' => $dueDay,
                    'firstDueDate' => $firstDueDate,
                    'activePresale' => $activePresale,
                    'expirationDate' => $expirationDate,
                    'onlineSignupAllowedPaymentMethods' => $onlineSignupAllowedPaymentMethods,
                    'preferredPaymentMethod' => $preferredPaymentMethod,
                    'totalContractValue' => $totalContractValue,
                    'downPaymentName' => $downPaymentName,
                    'downPaymentTotalAmount' => $downPaymentTotalAmount,
                    'scheduleTotalAmount' => $scheduleTotalAmount,
                    'schedulePreTaxAmount' => $schedulePreTaxAmount,
                    'clubFeeTotalAmount' => $clubFeeTotalAmount,
                    'planValidation' => $planValidation,
                    'planLink' => $planLink,
                    'membershiptype' => $membershiptype,
                    'monthlyfee' => $monthlyfee,
                    'downpaymentList' => $downpaymentList,
                    'scheduleList' => $scheduleList,
                    'schedules' => $schedules,
                    'enrollmentFee' => $enrollmentFee,
                    'clubName' => $clubName,
                    'agreementTerms' => $agreementTerms,
                    'agreementDescription' => $agreementDescription,
                    'agreementNote' => $agreementNote
                ),

            );
            wp_insert_post( $post_arr );

    }


    }
}
    return $message;
}

//ingest promo plans (accepts club number)
function ABCPromoCodeIngest($thisclub, $thisPromoCode){
    
    $message = "";

    $clubNumbers = $thisclub;
    $promoCode = $thisPromoCode;
    
    //get club and plan categories
    $term = get_term_by('slug', 'clubs', 'category');
    $term_ID = $term->term_id;
    $clubCatId = array( $term_ID) ;

    $term = get_term_by('slug', 'promo-plans', 'category');
    $term_ID = $term->term_id;
    $promoCatId = $term_ID;
    
    $term = get_term_by('slug', 'plans', 'category');
    $term_ID = $term->term_id;
    $planCatId = $term_ID;


    $array = explode(',', $clubNumbers); //split string into array seperated by ', '
    foreach($array as $value){
        $clubNumber = $value;
    


    //$clubNumber = $_POST['clubNumber'];
    $clubargs = array(
    'post_type'  => 'post',
    'category'  =>  $clubCatId,
    'meta_key'   => 'clubNumber',
    'meta_query' => array(
        array(
            'key'   => 'clubNumber',
            'value' => $clubNumber,
            'compare' => '='
        )

    )
	);
	   $clubposts = get_posts( $clubargs );
        foreach ($clubposts as $club){
            $clubId = $club->ID;
            $clubName = get_post_meta($clubId,'clubName',true);
            //insert category for club if it does not exist
            wp_insert_term($clubName, 'category', array(
                'description' => 'Plans for ' . $clubName . ' - ' . $clubNumber,
                'slug' => 'club-' . $clubNumber,
                'parent' => $planCatId // must be the ID, not name
            ));
            $term = get_term_by('slug', 'club-' . $clubNumber, 'category');
            $term_ID = $term->term_id;
            $singClubCatId = $term_ID;
        }
        
        $campaignId = "";

        //$promoCode = $promoCode;
        $thisData = "";


        


        $AbcUrl = "https://api.abcfinancial.com/rest/" . $clubNumber . "/clubs/plans?onlyPromoPlans=true&inClubPlans=false&ignorePlanAvailabilityWindow=false";
        $thisMethod = "";
        $response = CallAPI( $thisMethod, $AbcUrl, $thisData );
        $data2 = json_decode( $response , false );
        $findme = "success";
        //$promoPos = "doogle";
        $thispos = strpos($response, $findme);


        foreach ( $data2->plans as & $plan ) {
            if($plan->promoCode && $plan->promoCode == $promoCode){
                $promoCode = $plan->promoCode;
                $goPromo = "yes";
                $thisPlanId = $plan->planId;

            } else if($plan->promoCode && $plan->promoCode == strtoupper($promoCode)){
                $promoCode = $plan->promoCode;
                $goPromo = "yes";
                $thisPlanId = $plan->planId;

            }
       
       //$thisPromoCode = $_POST['promoCode'];
      

        if( $goPromo == "yes"){
            $planArray = ABCPlanArray($clubNumber, $thisPlanId);
            $planName = $planArray->paymentPlan->planName;
            $clubNumber = $planArray->request->clubNumber;
            $planId = $planArray->paymentPlan->planId;
            $agreementTerm = $planArray->paymentPlan->agreementTerm;
            $termInMonths = $planArray->paymentPlan->termInMonths;
            $scheduleFrequency = $planArray->paymentPlan->scheduleFrequency;
            $dueDay = $planArray->paymentPlan->dueDay;
            $firstDueDate = $planArray->paymentPlan->firstDueDate;
            $activePresale = $planArray->paymentPlan->activePresale;
            $expirationDate = $planArrady->paymentPlan->expirationDate;
            $onlineSignupAllowedPaymentMethods = $planArray->paymentPlan->onlineSignupAllowedPaymentMethods;
            $preferredPaymentMethod = $planArray->paymentPlan->preferredPaymentMethod;
            $totalContractValue = $planArray->paymentPlan->totalContractValue;
            $downPaymentName = $planArray->paymentPlan->downPaymentName;
            $downPaymentTotalAmount = $planArray->paymentPlan->downPaymentTotalAmount;
            $scheduleTotalAmount = $planArray->paymentPlan->scheduleTotalAmount;

            $clubFeeTotalAmount = $planArray->paymentPlan->clubFeeTotalAmount;
            $planValidation = $planArray->paymentPlan->planValidation;
            $planLink = ABCPlanLink( $planArray );
            $membershiptype = $planArray->paymentPlan->membershipType;
            $monthlyfee = $scheduleTotalAmount;
            $planLink = ABCPlanLink( $planArray );
            $agreementDescription = $planArray->paymentPlan->agreementDescription;
            $agreementNote = $planArray->paymentPlan->agreementNote;
            $agreementTerms = $planArray->paymentPlan->agreementTerms;


            $thisCat = array($planCatId,$promoCatId,$singClubCatId);
        $downpaymentList = "";
        if ( $planArray->paymentPlan->downPayments ) {
        foreach ( $planArray->paymentPlan->downPayments as $downPayment ) {

            $thisName = $downPayment->name;
            $thisTax = $downPayment->tax;
            $thisSubTotal = $downPayment->subTotal;
            $thisTotal = $downPayment->total;
            $downpaymentList .=  $thisName . ',' . $thisSubTotal . ',' . $thisTax . ',' . $thisTotal . '|';
            if($thisName == "Processing Fee" || $thisName == "Enrollment"  || $thisName == "Enrollment Fee"){
                $enrollmentFee = $downPayment->subTotal;
            }
        }
       $scheduleList = "";
       if ( $planArray->paymentPlan->schedules ) {
        foreach ( $planArray->paymentPlan->schedules as $schedule ) {
          if ( $i == 1 ) {
            $schedulePreTaxAmount = $schedule->schedulePreTaxAmount;
            $scheduleDueDate = $schedule->scheduleDueDate;
            $scheduleAmount = $schedule->scheduleAmount;
            $numberOfPayments = $schedule->numberOfPayments;
            $recurring = $schedule->recurring;
            $addon = $schedule->addon;
            $defaultChecked = $schedule->defaultChecked;
            $description = $schedule->description;
            $profitCenter = $schedule->profitCenter;

          }
          $scheduleList .=  $description . ',' . $schedulePreTaxAmount . ',' . $scheduleAmount . ',' . $numberOfPayments . ',' . $recurring . ',' . $scheduleDueDate . ',' . $profitCenter . '|';
        }
        $schedulePreTaxAmount = str_replace( '$', '', $schedulePreTaxAmount );
      }
      }
        if($planArray->request->clubNumber){
            $clubNumber = $planArray->request->clubNumber;
            $message .= "&bull; Plans with promocode <strong>" . $promoCode . "</strong> have been successfully imported for club <strong>#" . $clubNumber . " - " . $clubName . "</strong> have been successfully imported. <br>";
            $post_arr = array(
                'post_title'   => $planName,
                'post_content' => '',
                'post_status'  => 'draft',
                'post_author'  => get_current_user_id(),
                'post_category' => $thisCat,
                'meta_input'   => array(
                    'planName' => $planName,
                    'promoCode' => $promoCode,
                    'clubNumber' => $clubNumber,
                    'planId' => $planId,
                    'agreementTerm' => $agreementTerm,
                    'termInMonths' => $termInMonths,
                    'scheduleFrequency' => $scheduleFrequency,
                    'dueDay' => $dueDay,
                    'firstDueDate' => $firstDueDate,
                    'activePresale' => $activePresale,
                    'expirationDate' => $expirationDate,
                    'onlineSignupAllowedPaymentMethods' => $onlineSignupAllowedPaymentMethods,
                    'preferredPaymentMethod' => $preferredPaymentMethod,
                    'totalContractValue' => $totalContractValue,
                    'downPaymentName' => $downPaymentName,
                    'downPaymentTotalAmount' => $downPaymentTotalAmount,
                    'scheduleTotalAmount' => $scheduleTotalAmount,
                    'schedulePreTaxAmount' => $schedulePreTaxAmount,
                    'clubFeeTotalAmount' => $clubFeeTotalAmount,
                    'planValidation' => $planValidation,
                    'planLink' => $planLink,
                    'membershiptype' => $membershiptype,
                    'monthlyfee' => $monthlyfee,
                    'downpaymentList' => $downpaymentList,
                    'scheduleList' => $scheduleList,
                    'schedules' => $schedules,
                    'enrollmentFee' => $enrollmentFee,
                    'clubName' => $clubName,
                    'agreementTerms' => $agreementTerms,
                    'agreementDescription' => $agreementDescription,
                    'agreementNote' => $agreementNote
                ),

            );
            wp_insert_post( $post_arr );
            
    }


    }
}
} // end clubnumber post array loop
    if($message == ""){
        "Sorry, no active plans match this promocode. Check the spelling and case and try again.";
    }
    return $message;
}

//Retrieve a list of active campaigns for this club
function ABCCampaignArray() {
  if( get_option('iCart_abc_clubNumber') != "" ){
      $club = get_option('iCart_abc_clubNumber');
      $AbcUrl = "https://api.abcfinancial.com/rest/" . $club . "/clubs/campaigns?activeStatus=active";
      $thisMethod = "";
      $thisData = "";
      return json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );
  } else {
      return false;
  }
}

// Populates control with campaignIds
function ABCCampaignIds($clubNumber) {
  $club = $clubNumber;
  $AbcUrl = "https://api.abcfinancial.com/rest/" . $club . "/clubs/campaigns?activeStatus=active";
  $thisMethod = "";
  $thisData = "";
  $data = json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );
  $resultArray = array();
  if ( $data->campaigns != ""){
      foreach ( $data->campaigns as & $campaign ) {
        $resultArray[ $campaign->id ] = __( $campaign->name, 'icart' );
      }
  } else {
      $resultArray[ '' ] = __( 'None Found', 'icart' );
  }
  return $resultArray;
}

function ABCSinglePlanArrayCache( $club, $planId ) {


    $cache_key = 'planarraycache_'. $planId;
    if($refresh == "yes"){
        wp_cache_delete( $cache_key );
    }
    $planCache = wp_cache_get( $cache_key );
    if ( false === $planCache ) {
          $AbcUrl = "https://api.abcfinancial.com/rest/" . $club . "/clubs/plans/" . $planId;
          $thisMethod = "";
          $thisData = array(
            "clubNumber" => $club,
            "planId" => $planId
          );
          $planArray = CallAPI( $thisMethod, $AbcUrl, $thisData );
        //number of seconds when cache should expire
        $seconds = 60*60*12;
        //set plan cache
        wp_cache_set( $cache_key, $planArray, $group=null, $seconds);
       }

    //$planCache = ;
    return wp_cache_get( $cache_key );





}

//pull the plan name from the plan array
function ABCPlanName( $planArray ) {
  return $planArray->paymentPlan->planName;
}

//pull the plan name from the plan array
function ABCTotalContractValue( $planArray ) {
	$totalContractValue = $planArray->paymentPlan->totalContractValue;
	$totalValue = str_replace( '$', '', $totalContractValue );
	if($totalValue != ""){
		return $totalValue;
	} else {
		return "0";
	}
}

//pull the initial down payment amount
function ABCDueToday( $planArray ) {
  return $planArray->paymentPlan->downPaymentTotalAmount;
}

//assemble the plan link from the plan array.  You must pass the array response from ABCPlanArray above
function ABCPlanLink( $planArray ) {
  $planValidation = $planArray->paymentPlan->planValidation;
  $planId = $planArray->paymentPlan->planId;
  $club = $planArray->request->clubNumber;
  $planLink = site_url() . '/checkout/?planId=' . $planId . '&planValidation=' . $planValidation . '&club=' . $club;
  return $planLink;
}

//assemble the location link
function ABCLocationLink( $clubNumber ) {
  $planLink = site_url() . '/plans/?club=' . $clubNumber;
  return $planLink;
}


//returns the plan frequency from a single club array
function ABCScheduleFrequency( $planArray ) {
  return $planArray->paymentPlan->scheduleFrequency;
}



//pull the monthly pre-tax price from the plan array without dollar sign
function ABCMonthly( $planArray ) {
  $i = 1;
  if ( $planArray->paymentPlan->schedules ) {
    foreach ( $planArray->paymentPlan->schedules as $schedule ) {
      if ( $i == 1 ) {
        $schedulePreTaxAmount = $schedule->schedulePreTaxAmount;
      }
      $i++;
    }
    $schedulePreTaxAmount = str_replace( '$', '', $schedulePreTaxAmount );
  } else {
    $schedulePreTaxAmount = 0;
  }

  return $schedulePreTaxAmount;
}

//pull the monthly pre-tax price from the plan array
function ABCSchedulePreTaxAmount( $planArray ) {
  $i = 1;
  if ( $planArray->paymentPlan->schedules ) {
    foreach ( $planArray->paymentPlan->schedules as $schedule ) {
      if ( $i == 1 ) {
        $schedulePreTaxAmount = $schedule->schedulePreTaxAmount;
      }
    }
    $schedulePreTaxAmount = str_replace( '$', '', $schedulePreTaxAmount );
  } else {
    $schedulePreTaxAmount = 0;
  }

  return $schedulePreTaxAmount;
}

//pull the monthly total with tax applied
function ABCScheduleAmount( $planArray ) {

  return $planArray->paymentPlan->scheduleTotalAmount;
}

//get the clubNumber based on heirarchy.  The heirarchy is:  POST (overrides all other values for clubNumber) > GET (overrides default clubNumber) > OPTION iCart_abc_clubNumber (finally defaults to the option specified in the Admin:iCart Settings for "Default club number")
function ABCClubNumber(){
    if(isset($_POST['clubNumber'])){
        $clubNumber = $_POST['clubNumber'];
    } else if(isset($_POST['club'])){
        $clubNumber = $_POST['club'];
    } else if(isset($_GET['club'])){
        $clubNumber = $_GET['club'];
    } else if(isset($_GET['clubNumber'])){
        $clubNumber = $_GET['clubNumber'];
    } else if(get_option('iCart_abc_clubNumber') != "") {
        $clubNumber = get_option('iCart_abc_clubNumber');
    } else {
        $clubNumber = "9003";
    }
    return $clubNumber;
}

//get the campaignId based on heirarchy.  The heirarchy is:  POST > GET > OPTION iCart_abc_campaignId
function ABCCampaignId(){
    if(isset($_POST['campaignId'])){
        $campaignId = $_POST['campaignId'];
    } else if(isset($_GET['campaignId'])){
        $campaignId = $_GET['campaignId'];
    } else if(get_option('iCart_abc_campaignId') != "") {
        $campaignId = get_option('iCart_abc_campaignId');
    } else {
        $campaignId = "";
    }
    return $campaignId;
}

//get the promoCode based on heirarchy.  The heirarchy is:  POST > GET > OPTION iCart_abc_promoCode
function ABCPromoCode(){
    if(isset($_POST['promoCode'])){
        $promoCode = $_POST['promoCode'];
    } else if(isset($_GET['promoCode'])){
        $promoCode = $_GET['promoCode'];
    } else if(get_option('iCart_abc_promoCode') != ""){
        $promoCode = get_option('iCart_abc_promoCode');
    } else {
        $promoCode = "";
    }
    return $promoCode;
}

// pull the list of plans to prepopulate the widget control. This is mainly used in the Single Plan widget and returns a key/value pair that poplates a select box in the widget editor.

// To use: ABCPlanIds(get_option('iCart_abc_clubNumber'))
function ABCPlanIds( $club ) {
  $AbcUrl = "https://api.abcfinancial.com/rest/" . $club . "/clubs/plans";
  $thisMethod = "";
  $thisData = "";
  $data = json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );
  $resultArray = array();
  foreach ( $data->plans as & $plan ) {
    $resultArray[ $plan->planId ] = __( $plan->planName, 'icart' );
  }
  return $resultArray;
}
// getsthe plans for a club and keword
function ABCPlanLinkByKeyword( $club, $keyword ) {

  $AbcUrl = "https://api.abcfinancial.com/rest/" . $club . "/clubs/plans";
  $thisMethod = "";
  $thisData = "";
  $data = json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );
  $resultArray = array();
  foreach ( $data->plans as & $plan ) {
    $planId = $plan->planId;
    $found = strpos($plan->planName, $keyword);
    if($found === false) {

      } else {
         $planLink = ABCPlanLink(ABCPlanArray( $club, $planId ));
    }
  }
  return $planLink;
}

// To use: ABCPlanIdsMulti()
function ABCPlanIdsMulti() {

   $iCart_abc_multiClubs = str_replace(' ', '', get_option('iCart_abc_multiClubs'));
   $clubNumbers = explode(',', $iCart_abc_multiClubs);

	//Assemble an array of all clubs
    $resultArray = array();
	foreach($clubNumbers as $club) {
		  $AbcUrl = "https://api.abcfinancial.com/rest/" . $club . "/clubs/plans";
          $thisMethod = "";
          $thisData = "";
          $data = json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );

          foreach ( $data->plans as & $plan ) {
            $thisplan = $club . ' - ' . $plan->planName;
            $resultArray[ $plan->planId ] = __( $thisplan, 'icart' );
          }
	}

  return $resultArray;
}

//returns an array a club's employees
function ABCEmployees( $club ) {
  if ( isset( $_GET[ 'club' ] ) ) {
    $club = $_GET[ 'club' ];
  }
  $AbcUrl = "https://api.abcfinancial.com/rest/" . $club . "/employees?employeeStatus=active&departmentId=A4AC3C52C62DB6D3E040007F01007557";
  $thisMethod = "";
  $thisData = "";
  $resultArray = json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );

  /*foreach($data->plans as &$plan){
  	$resultArray[$plan->planId] = __( $plan->planName, 'icart' );
  }*/
  return $resultArray;
}
//returns an array a club's events
function ABCEvents( $club, $dateFrom, $dateTo ) {
  $thisFrom = date( 'Y-m-d', strtotime( 'now' ) );
  $thisTo = '';
  if ( $dateFrom ) {
    $thisFrom = date( 'Y-m-d', strtotime( $dateFrom ) );
  }
  if ( $dateTo ) {
    $thisTo = '%2C' . date( 'Y-m-d', strtotime( $dateTo ) ) . '%2000%3A00%3A00.0';
  }
  $dateRange = $thisFrom . $thisTo;
  $AbcUrl = "https://api.abcfinancial.com/rest/" . $club . "/calendars/events?eventDateRange=" . $dateRange . "&eventCategory=appointment";
  $thisMethod = "";
  $thisData = "";
  $resultArray = json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );

  /*foreach($data->plans as &$plan){
  	$resultArray[$plan->planId] = __( $plan->planName, 'icart' );
  }*/
  return $resultArray;
}

//returns an array a club's events
function ABCItems( $club ) {
  $AbcUrl = "https://api.abcfinancial.com/rest/" . $club . "/clubs/items";
  $thisMethod = "";
  $thisData = "";
  $resultArray = json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );
  return $resultArray;
}

//returns an array a club's main info
function ABCClubInfo( $club ) {
  if ( isset( $_GET[ 'club' ] ) ) {
    $club = $_GET[ 'club' ];
  }
  $AbcUrl = "https://api.abcfinancial.com/rest/" . $club . "/clubs";
  $thisMethod = "";
  $thisData = "";
  $resultArray = json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );
  return $resultArray;
}

//returns the club name from a club Club Info array
function ABCClubName( $clubArray ) {
  return $clubArray->club->name;
}

//returns the club address
function ABCClubAddress( $clubArray ) {
	if($clubArray->club->name){

		  return '<div class="icartAddress">
		  			<h2 class="icartAddressClubName">' . $clubArray->club->name . '</h2>
					<div class="icart-club-address-container">'
		  . $clubArray->club->address1 . ' ' . $clubArray->club->address2 . '<br>'
		  . $clubArray->club->city . ', ' . $clubArray->club->state . ' ' . $clubArray->club->postalCode
			. '		</div>


				</div>';
	}
}
//get address from a club number
function ABCClubAddressByClubNumber(){
    if(get_post_meta( get_the_ID(), 'clubNumber', true )){
     $metaClub =  get_post_meta( get_the_ID(), 'clubNumber', true );
     $clubNumber = $metaClub;
    } else if($_GET['club']){
        $clubArray = ABCClubInfo( $_GET['club'] );
        $clubAddress = ABCClubAddress( $clubArray );
        return $clubAddress;
    } else {
        return false;
    }
}

add_shortcode('icartAddress', 'ABCClubAddressByClubNumber');




// Shortcode to output ABC data. to use: [icartdata datapoint='agreementTerms'] (replacing the agreementTerms with the datapoint of choice)
/*
function ABCDataPoint( $atts ) {
	// Attributes
	$atts = shortcode_atts(
		extract(
            array(
			'datapoint' => '',
                ),
                $atts,
                'icartdata'
            )
    );

    if($datapoint == 'agreementTerms' || $datapoint == 'agreementDescription' || $datapoint == 'agreementNote'){
        //$datapoint = base64_decode($datapoint);
    }
    echo $datapoint;
}
add_shortcode( 'icartdata', 'ABCDataPoint' );

*/

function decodeVar($datapoint){
    return base64_decode($datapoint);
}

//output the agreement description
function ABCAgreementDescription(){
    $thisId = get_the_ID();
    $datapoint = get_post_meta($thisId,'agreementDescription',true);
    if( $datapoint != "" ){
        return base64_decode($datapoint);
    } else {
        return false;
    }
}

add_shortcode( 'icart-agreementDescription', 'ABCAgreementDescription' );

//output the agreement note
function ABCAgreementNote(){
    $thisId = get_the_ID();
    $datapoint = get_post_meta($thisId,'agreementNote',true);
    if( $datapoint != "" ){
        return base64_decode($datapoint);
    } else {
        return false;
    }
}

add_shortcode( 'icart-agreementNote', 'ABCAgreementNote' );

//output the agreement terms
function ABCAgreementTerms(){
    $thisId = get_the_ID();
    $datapoint = get_post_meta($thisId,'agreementTerms',true);
    if( $datapoint != "" ){
        return base64_decode($datapoint);
    } else {
        return false;
    }
}

add_shortcode( 'icart-agreementTerms', 'ABCAgreementTerms' );


//shortcode that outputs the promoCode form
function ABCPromoForm(){
    $buttonBg = "#dddddd";
    if( get_option('iCart_abc_color_primary1') != "" ){
        $buttonBg = get_option('iCart_abc_color_primary1');
    }
    echo '<div style="text-align: center" style="max-width:300px">
    <form action=""  method="get">
    <div style="float:left; width:70%">
        <input type="text" name="promoCode" value="" placeholder="Promo code" required="" style="border:1px solid #ddd;">
    </div>
    <div style="float:left; width:30%">
        <input type="submit" name="redeem" value="Go" style="background:' . $buttonBg . '; color:black; border-radius:0; width:100%; border:1px solid #0042A0; margin-left:8px;">
    </div>
    <div style="clear:both"></div>
          </form>
    </div>';
}
add_shortcode('ic-promocode', 'ABCPromoForm');

function ABCCalendarLink($clubArray){
	$ABCCalendarLink = site_url() . '/club-calendar/?club=' . $clubArray->request->clubNumber;
	$ABCCleanName = str_replace("Charter Fitness - ", "", $clubArray->club->name);

	return '<a href="' . $ABCCalendarLink . '">' . $ABCCleanName . ' &bull; </a> ';
}
function ABCItemsLink($clubArray){
	$ABCItemsLink = site_url() . '/https://cfit.club/location-items//?club=' . $clubArray->request->clubNumber;
	$ABCCleanName = str_replace("Charter Fitness - ", "", $clubArray->club->name);

	return '<a href="' . $ABCItemsLink . '">' . $ABCCleanName . ' &bull; </a> ';
}
function ABCClubAddressBlock( $clubArray ) {
	if($clubArray->club->name){
		  $ABCCalendarLink = site_url() . '/club-calendar/?club=' . $clubArray->request->clubNumber;
          $ABCItemsLink = site_url() . '/location-items/?club=' . $clubArray->request->clubNumber;
		  return '<div class="icartAddressBlock">
		  			<h2 class="icartAddressClubName">' . $clubArray->club->name . '</h2>
					<div class="icart-club-address-container">'
		  . $clubArray->club->address1 . ' ' . $clubArray->club->address2 . '<br>'
		  . $clubArray->club->city . ', ' . $clubArray->club->state . ' ' . $clubArray->club->postalCode
			. '		</div>
					<div class="icartClubLinks">
						<a href="' . $ABCCalendarLink . '">
						<span><i class="fa fa-calendar"></i></span>
						<br>Calendar
						</a>
                        <a href="' . $ABCItemsLink . '">
						<span><i class="fa fa-shopping-bag"></i></span>
						<br>Items
						</a>
					</div>

				</div>';
	}
}
function ABCClubAddressBlockByKeyword( $clubArray, $keyword ) {
	if($clubArray->club->name){




		  $ABCPlanLink = ABCPlanLinkByKeyword($clubArray->request->clubNumber, $keyword);
		  return '<div class="icartAddressBlock">
		  			<h2 class="icartAddressClubName">' . $clubArray->club->name . '</h2>
					<div class="icart-club-address-container">'
		  . $clubArray->club->address1 . ' ' . $clubArray->club->address2 . '<br>'
		  . $clubArray->club->city . ', ' . $clubArray->club->state . ' ' . $clubArray->club->postalCode
			. '		</div>
                    <div>
                    <a href="' . $ABCPlanLink .'"><button>Join Now</button></a>
                    </div>


				</div>';
	}
}
function ABCLocationPlanBlock( $clubArray ) {
	if($clubArray->club->name){




		  $ABCLocationLink = ABCLocationLink($clubArray->request->clubNumber);

          return '<div class="icartAddressBlock">
		  			<h2 class="icartAddressClubName">' . $clubArray->club->name . '</h2>
					<div class="icart-club-address-container">'
		  . $clubArray->club->address1 . ' ' . $clubArray->club->address2 . '<br>'
		  . $clubArray->club->city . ', ' . $clubArray->club->state . ' ' . $clubArray->club->postalCode
			. '		</div>
                    <div style="padding:10px; text-align:center;">
                    <a href="' . $ABCLocationLink .'"><button style="background:#00ADEF; color:white; border-radius:0; border:1px solid #00ADEF">Join Online</button></a>
                    </div>


				</div>';
	}
}
//returns an array of ClubNumbers based on the values entered on the iCart admin options page
function ABCLocations(){
	$clubNumbers = "";

	//if multiple clubs have been set, return an array of club Information
	if(get_option('iCart_abc_multiClubs')){
		$iCart_abc_multiClubs = str_replace(' ', '', get_option('iCart_abc_multiClubs'));
		$clubNumbers = explode(',', $iCart_abc_multiClubs);
	} else {
		$iCart_abc_clubNumber = get_option('iCart_abc_clubNumber') . ',';
		$clubNumbers = explode(',', $iCart_abc_clubNumber);
	}
	return $clubNumbers;
}


//returns an array of club information specified in the iCart settings admin page.
function ABCClubArray(){
	//if multiple clubs have been set, return an array of club Information
	if(get_option('iCart_abc_multiClubs')){
		$iCart_abc_multiClubs = str_replace(' ', '', get_option('iCart_abc_multiClubs'));
		$clubNumbers = explode(',', $iCart_abc_multiClubs);
	} else {
		$iCart_abc_clubNumber = get_option('iCart_abc_clubNumber') . ',';
		$clubNumbers = explode(',', $iCart_abc_clubNumber);
	}
	$fullclubArray[] = "";
	$thisclubArray[] = "";
	//Assemble an array of all clubs
	foreach($clubNumbers as $thisclubNumber) {
		$thisclubArray = ABCClubInfo( $thisclubNumber);
		array_push($fullclubArray, $thisclubArray);
		//$fullclubArray['item'][] = $thisclubarray;
	}

	return array($fullclubArray);
}

//creates a cache of all clubs and plans.
function ABCPlanCache($clubNumber, $refresh, $promoCode, $campaignId){
    $thisdata = "";
    if($promoCode != ""){
        $thisData = array(
		"clubNumber" => $clubNumber,
		"onlyPromoPlans" => 'true'
	   );
    }
    $cache_key = 'plan_cache_'. $clubNumber . '_' . $promoCode . '_' . $campaignId;
    if($refresh == "yes"){
        wp_cache_delete( $cache_key );
    }
    $planCache = wp_cache_get( $cache_key );
    if ( false === $planCache ) {
        if(get_option('iCart_abc_multiClubs')){

            $fullclubArray[] = "";
            $thisclubArray[] = "";

           $iCart_abc_multiClubs = str_replace(' ', '', get_option('iCart_abc_multiClubs'));
           $clubNumbers = explode(',', $iCart_abc_multiClubs);

            //Assemble an array of all clubs

            foreach($clubNumbers as $clubNumber) {
                  $AbcUrl = "https://api.abcfinancial.com/rest/" . $clubNumber . "/clubs/plans";
                  $thisMethod = "";


                  $data = json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );

                  foreach ( $data->plans as & $plan ) {
                    //$thisplan = $club . ' - ' . $plan->planName;

                    //$resultArray[ $plan->planId ] = __( $thisplan, 'icart' );
                      if($promoCode != "" && $plan->promoCode == $promoCode){
                          $thisclubArray = ABCPlanArray($clubNumber, $plan->planId);
                          array_push($fullclubArray, $thisclubArray);
                      } else if($promoCode != "" && $plan->promoCode != $promoCode){
                         //array_push($fullclubArray, $thisclubArray);
                      } else {
                         $thisclubArray = ABCPlanArray($clubNumber, $plan->planId);
                         array_push($fullclubArray, $thisclubArray);
                      }


                  }
            }
        } else {
            $clubNumber = get_option('iCart_abc_clubNumber');

            $AbcUrl = "https://api.abcfinancial.com/rest/" . $clubNumber . "/clubs/plans";
            $thisMethod = "";


            $data = json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );

            foreach ( $data->plans as & $plan ) {
                    if($promoCode && $plan->promoCode == $promoCode){
                          $thisclubArray = ABCPlanArray($clubNumber, $plan->planId);
                          array_push($fullclubArray, $thisclubArray);
                      } else if($promoCode && $plan->promoCode != $promoCode){
                         //array_push($fullclubArray, $thisclubArray);
                      } else {
                         $thisclubArray = ABCPlanArray($clubNumber, $plan->planId);
                         array_push($fullclubArray, $thisclubArray);
                      }
                    //$thisclubArray = ABCPlanArray($clubNumber, $plan->planId);
                    //array_push($fullclubArray, $thisclubArray);
            }
       }
        //number of seconds when cache should expire
        $seconds = 60*60*3;

        //set plan cache
        wp_cache_set( $cache_key, $fullclubArray, $group=null, $seconds);


    }
    $planCache = wp_cache_get( $cache_key );
    return $planCache;


}

//creates a cache of all clubs and plans.
function ABCClubPlanCache($refresh, $promoCode, $campaignId, $clubNumber){
    $fullclubArray = array();
    $thisclubArray = array();
    if($promoCode && $promoCode != ""){
        //$promoCode = $promoCode;
        $thisData = array(
            "clubNumber" => $clubNumber,
            "onlyPromoPlans" => 'true'
	    );
        $thisCode = $promoCode;
        $promoText = $promoCode;
    } else {
        //$promoCode = "none";
        $thisCode = "none";
        $thisData = array(
            "clubNumber" => $clubNumber,
            "onlyPromoPlans" => 'false'
	    );

    }

    $promoText = "";

    $backupData = array(
		"clubNumber" => $clubNumber,
		"onlyPromoPlans" => 'false'
	   );

    $cache_key = 'singleplancache_' . $promoText . '_'. $clubNumber . '_' . $promoCode . '_' . $campaignId . '';
    if($refresh == "yes"){
        wp_cache_delete( $cache_key );
    }
    $planCache = wp_cache_get( $cache_key );
    if ( false === $planCache ) {
            $AbcUrl = "https://api.abcfinancial.com/rest/" . $clubNumber . "/clubs/plans";
            $thisMethod = "";
            $response = CallAPI( $thisMethod, $AbcUrl, $thisData );

            $data = json_decode( $response , false );
            $findme = "success";
            //$promoPos = "doogle";
            $thispos = strpos($response, $findme);
            $isRelevantCode = "no";

           foreach ( $data->plans as & $plan ) {
               if($plan->promoCode && $plan->promoCode == $promoCode){
                   $thisPlanId = $plan->planId;
                   $thisclubArray = ABCPlanArray($clubNumber, $thisPlanId);
                   array_push($fullclubArray, $thisclubArray);
                   $isRelevantCode = "yes";

               }


           }

            if($isRelevantCode == "no"){
                foreach ( $data->plans as & $plan ) {
                       $thisPlanId = $plan->planId;
                       $thisclubArray = ABCPlanArray($clubNumber, $thisPlanId);
                       array_push($fullclubArray, $thisclubArray);
                }
            }




        //number of seconds when cache should expire
        $seconds = 60*30;
        //set plan cache
        wp_cache_set( $cache_key, $fullclubArray, $group=null, $seconds);
       }

    //$planCache = ;
    return wp_cache_get( $cache_key );

}

//creates a cache of plan Id options
function ABCPlanIdOptions($clubNumber=null, $promoCode=null, $campaignId=null){
    $fullclubArray = array();
    $thisclubArray = array();

    $thisdata = "";
    if($promoCode){
        $thisData = array(
		"clubNumber" => $clubNumber,
		"onlyPromoPlans" => 'true'
	   );
    }
    $cache_key = 'clubplanoptionscache_'. $clubNumber . '_' . $promoCode . '_' . $campaignId;
    if($refresh == "yes"){
        wp_cache_delete( $cache_key );
    }
    $planCache = wp_cache_get( $cache_key );
    if ( false === $planCache ) {
            $AbcUrl = "https://api.abcfinancial.com/rest/" . $clubNumber . "/clubs/plans";
            $thisMethod = "";
            $data = json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );


            if ($data) {



            $resultArray = array();
            foreach ( $data->plans as & $plan ) {
                    /*if($promoCode && $plan->promoCode == $promoCode){
                          $resultArray = array();
                      foreach ( $data->plans as & $plan ) {
                        $resultArray[ $plan->planId ] = __( $plan->planName, 'icart' );
                      }
                      } else if($promoCode && $plan->promoCode != $promoCode){
                         //array_push($fullclubArray, $thisclubArray);
                      } else {
                         $thisclubArray = ABCPlanArray($clubNumber, $plan->planId);
                         array_push($fullclubArray, $thisclubArray);
                      }*/

                    $resultArray[ $plan->planId ] = __( $plan->planName, 'icart' );

                    //$thisclubArray = ABCPlanArray($clubNumber, $plan->planId);
                    //array_push($fullclubArray, $thisclubArray);
            }
            }
        //number of seconds when cache should expire
        $seconds = 60*60*12;
        //set plan cache
        wp_cache_set( $cache_key, $resultArray, $group=null, $seconds);
       }

    //$planCache = ;
    return wp_cache_get( $cache_key );

}

//updates the settings for the array of all clubs and plans.
function ABCClubPlanArrayUpdate($clubNumber, $promoCode=null, $campaignId=null){
    $fullclubArray = array();
    $thisclubArray = array();

    $thisdata = "";
    if($promoCode != ""){
        $thisData = array(
		"clubNumber" => $clubNumber,
		"onlyPromoPlans" => 'true'
	   );
    }


            $AbcUrl = "https://api.abcfinancial.com/rest/" . $clubNumber . "/clubs/plans";
            $thisMethod = "";
            $data = json_decode( CallAPI( $thisMethod, $AbcUrl, $thisData ), false );
            $findme   = 'success';
            $pos = strpos($data, $findme);


            if ($pos === false) {


            } else {
                foreach ( $data->plans as & $plan ) {
                    if($promoCode && $plan->promoCode == $promoCode){
                          $thisclubArray = ABCPlanArray($clubNumber, $plan->planId);
                          array_push($fullclubArray, $thisclubArray);

                      } else {
                         $thisclubArray = ABCPlanArray($clubNumber, $plan->planId);
                         array_push($fullclubArray, $thisclubArray);
                      }
                    //$thisclubArray = ABCPlanArray($clubNumber, $plan->planId);
                    //array_push($fullclubArray, $thisclubArray);
                }
            }


    return $fullclubArray;

}


//returns map markers for the Google Maps API. Used in the iCart Locations widget. Use ABCClubArray() to display all clubs
function ABCMapMarkers($clubArray){

	$mapMarkers = '<markers>';
	$i = 0;
	foreach($clubArray as $leveltwo) {
		foreach($leveltwo as $clubs) {
			foreach($clubs as $club) {

				$i++;
				//echo $club;
				$mapMarkers .= '<marker id="' . $i . '" name="' . $club->club->name . '" address="' . $club->club->address1 . ' ' . $club->club->address2 . ', ' . $club->club->city . ' ' . $club->club->state . ' ' . $club->club->postalCode . '" type="fitness club"/>';
			}
		}
	}

	$mapMarkers .= '</markers>';

	return $mapMarkers;
}
//outputs a list of items
function ABCItemList( $itemArray ) {
  $html = '<h3>Club Products</h3>
	<table>
		<tr>
			<th>Item</th>
			<th>Category</th>
			<th>Price</th>
		</tr>
	';
  foreach ( $itemArray->items as $item ) {
    $html .= '
		<tr>
			<td>' . $item->itemName . '</td>

			<td>' . $item->itemCategoryName . '</td>

			<td>' . $item->itemUnitPrice . '</td>
		</tr>
		';
  }
  $html .= "</table>";
  return $html;
}


//gets the item price from an item id
/*function ABCItemPrice($itemId){
	return $planArray->paymentPlan->firstDueDate;
}*/

//outputs employee select box
function ABCEmployeeSelect( $employeearray ) {
  $html = '<select name="icart-employee">
	<option value="">Employee</option>
	';
  foreach ( $employeearray->employees as $employee ) {
    $html .= '<option value="' . $employee->employeeId . '" style="text-transform:capitalize">' . $employee->personal->firstName . ' ' . $employee->personal->lastName . '</option>';
  }
  $html .= '</select>';
  return $html;
}

//outputs employee list
function ABCEmployeeList( $employeeArray ) {
  $html = '';
  foreach ( $employeeArray->employees as $employee ) {
    $link = site_url() . '/availability/?employeeId=' . $employee->employeeId;
    $html .= '<a href="' . $link . '">' . $employee->personal->firstName . ' ' . $employee->personal->lastName . '</a>';
  }
  $html .= "</table>";
  return $html;
}

//outputs calendar list
function ABCEventList( $eventarray ) {
  $html = '';
if($eventarray->events){
  foreach ( $eventarray->events as $event ) {
    $html .= 'Event Date: ' . $event->eventTimestamp . '<br>Event Name: ' . $event->employeeName . '<br>Event Name: ' . $event->eventName . '<hr>';
  }
} else {
    $html = "No events found for this time period.";
}


  return $html;
}


//Outputs the next payment due date for recurring charges
function ABCDueDate( $planArray ) {
  return $planArray->paymentPlan->firstDueDate;
}


//Outputs a summary of a plan's pricing.
function ABCClubFeeSummary( $planArray ) {
    $summary = '
	<table class="icart-price-summary-table">
		<tr>
			<th>Name</th>
			<th>Amount</th>
            <th>Due</th>
		</tr>';
    if ( $planArray->paymentPlan->clubFees ) {
        foreach ( $planArray->paymentPlan->clubFees as $clubFee ) {
          $feeDueDate = $clubFee->feeDueDate;
          $feeName = $clubFee->feeName;
          $feeAmount = $clubFee->feeAmount;
          $feeApply = $clubFee->feeApply;
          $feeRecurring= $clubFee->feeRecurring;

            $summary .= "

            <tr>
                <td>$feeName</td>
                <td>$feeAmount</td>
                <td>$feeDueDate</td>

            </tr>";

        }
  } 
  $summary .= "</table>";
  return $summary;
}


//Outputs a summary of a plan's pricing.
function ABCPriceSummary( $planArray ) {

  $paymentBreakdown = array( "name", "subTotal", "tax", "total" );
  $i = 1;
  if ( $planArray->paymentPlan->schedules ) {
    foreach ( $planArray->paymentPlan->schedules as $schedule ) {
      if ( $i == 1 ) {
        $schedulePreTaxAmount = ABCMonthly( $planArray );
      }
      $i++;
      //var_dump($schedulePreTaxAmount);
    }
  } else {
    $schedulePreTaxAmount = "$0";
  }

  $summary_th = '
	<table class="icart-price-summary-table">
		<tr>
			<th>Type</th>
			<th>Total</th>
		</tr>';
    $summary_th_tax = '
	<table class="icart-price-summary-table">
		<tr>
			<th>Type</th>
			<th>Subtotal</th>
            <th>Tax</th>
			<th>Total</th>
		</tr>';

$tableHeader = $summary_th;
  //add a custom class for even/odd rows
  $rowclass = "";
  if ( $i % 2 == 0 ) {
    $rowclass = "even";
  } else {
    $rowclass = "odd";
  }
  if ( $planArray->paymentPlan->downPayments ) {
    foreach ( $planArray->paymentPlan->downPayments as $downPayment ) {
      array_push( $paymentBreakdown, array( $downPayment->name, $downPayment->subTotal, $downPayment->tax, $downPayment->total ) );
      $thisTax = $downPayment->tax;
      $thisSubTotal = $downPayment->subTotal;
      $thisTotal = $downPayment->total;

      if ($thisSubTotal != "$0.00"){
          if($thisSubTotal != $thisTotal){

            $summary .= '
			<tr class="icart-summary-table-' . $rowclass . '">
				<td>' . $downPayment->name . '</td>

				<td>' . $thisSubTotal . '</td>
                <td>' . $thisTax . '</td>
				<td>' . $thisTotal . '</td>
			</tr>
			';
            $tableHeader = $summary_th_tax;
          } else {
              $summary .= '
			<tr class="icart-summary-table-' . $rowclass . '">
				<td>' . $downPayment->name . '</td>

				<td>' . $thisTotal . '</td>
			</tr>
			';
          }
        }
    }
  } else {
    $summary .= '
			<tr class="icart-summary-table-' . $rowclass . '">
				<td>No cost enrollment</td>


				<td>$0</td>
			</tr>
			';
  }
  $summary .= '
	</table>';
  return $tableHeader . $summary;
}


//Outputs a summary of a plan's FULL pricing including $0 items.
function ABCPriceSummaryFull( $planArray ) {

  $paymentBreakdown = array( "name", "subTotal", "tax", "total" );
  $i = 1;
  if ( $planArray->paymentPlan->schedules ) {
    foreach ( $planArray->paymentPlan->schedules as $schedule ) {
      if ( $i == 1 ) {
        $schedulePreTaxAmount = ABCMonthly( $planArray );
      }
      $i++;
      //var_dump($schedulePreTaxAmount);
    }
  } else {
    $schedulePreTaxAmount = "$0";
  }

  $summary_th = '
	<table class="icart-price-summary-table">
		<tr>
			<th>Type</th>
			<th>Total</th>
		</tr>';
    $summary_th_tax = '
	<table class="icart-price-summary-table">
		<tr>
			<th>Type</th>
			<th>Subtotal</th>
            <th>Tax</th>
			<th>Total</th>
		</tr>';

$tableHeader = $summary_th;
  //add a custom class for even/odd rows
  $rowclass = "";
  if ( $i % 2 == 0 ) {
    $rowclass = "even";
  } else {
    $rowclass = "odd";
  }
  if ( $planArray->paymentPlan->downPayments ) {
    foreach ( $planArray->paymentPlan->downPayments as $downPayment ) {
      array_push( $paymentBreakdown, array( $downPayment->name, $downPayment->subTotal, $downPayment->tax, $downPayment->total ) );
      $thisTax = $downPayment->tax;
      $thisSubTotal = $downPayment->subTotal;
      $thisTotal = $downPayment->total;

     
          if($thisSubTotal != $thisTotal){

            $summary .= '
			<tr class="icart-summary-table-' . $rowclass . '">
				<td>' . $downPayment->name . '</td>

				<td>' . $thisSubTotal . '</td>
                <td>' . $thisTax . '</td>
				<td>' . $thisTotal . '</td>
			</tr>
			';
            $tableHeader = $summary_th_tax;
          } else {
              $summary .= '
			<tr class="icart-summary-table-' . $rowclass . '">
				<td>' . $downPayment->name . '</td>

				<td>' . $thisTotal . '</td>
			</tr>
			';
          }
        
    }
  } else {
    $summary .= '
			<tr class="icart-summary-table-' . $rowclass . '">
				<td>No cost enrollment</td>


				<td>$0</td>
			</tr>
			';
  }
  $summary .= '
	</table>';
  return $tableHeader . $summary;
}




//Outputs a summary of a plan's schedules.
function ABCScheduleSummary( $planArray ) {
  $summary_th_tax = '
        <table class="icart-price-summary-table">
        <tr>
            <th>Name</th>


            <th>Total</th>
        </tr>';
  $tableHeader = $summary_th_tax;

  $i = 1;
  $extraProfitCenters = "";
  if ( $planArray->paymentPlan->schedules ) {
    foreach ( $planArray->paymentPlan->schedules as $schedule ) {

        $profitCenter = $schedule->profitCenter;
        $scheduleDueDate = $schedule->scheduleDueDate;
        $scheduleAmount = $schedule->scheduleAmount;
        $schedulePreTaxAmount = $schedule->schedulePreTaxAmount;
        $numberOfPayments = $schedule->numberOfPayments;
        $recurring = $schedule->recurring;
        $addon = $schedule->addon;
        $defaultChecked = $schedule->defaultChecked;
        $description = $schedule->description;
        $thisTaxAmount = floatval($scheduleAmount) - floatval($schedulePreTaxAmount);
        $thisTax = "$" . $thisTaxAmount;
        $thisSubTotal = $schedulePreTaxAmount;
        $thisTotal = $scheduleAmount;
        
        if( $profitCenter == "Smgrptrn" || $profitCenter == "SMGRPTRN" ){
            $scheduleName = "Small Group Training";
        } else {
            $scheduleName = $description;
        }

        if( $scheduleName == "" ){
            $scheduleName = $profitCenter;
        }


        //add a custom class for even/odd rows
        $rowclass = "";
        if ( $i % 2 == 0 ) {
        $rowclass = "even";
        } else {
        $rowclass = "odd";
        }


      if ($thisSubTotal != "$0.00" && $addon != true){


            $summary .= '
			<tr class="icart-summary-table-' . $rowclass . '">
				<td>' . $scheduleName . '</td>



				<td>' . $thisTotal . '</td>
			</tr>
			';


        }
        $i++;



    }
      $summary .= '
        </table>';
      return $tableHeader . $summary;
  } else {
      return false;
  }



}


//schedule summary without edit
function ABCScheduleSummaryFull( $planArray ) {
  $summary_th_tax = '
        <table class="icart-price-summary-table">
        <tr>
            <th>Name</th>


            <th>Total</th>
        </tr>';
  $tableHeader = $summary_th_tax;

  $i = 1;
  $extraProfitCenters = "";
  if ( $planArray->paymentPlan->schedules ) {
    foreach ( $planArray->paymentPlan->schedules as $schedule ) {

        $profitCenter = $schedule->profitCenter;
        $scheduleDueDate = $schedule->scheduleDueDate;
        $scheduleAmount = $schedule->scheduleAmount;
        $schedulePreTaxAmount = $schedule->schedulePreTaxAmount;
        $numberOfPayments = $schedule->numberOfPayments;
        $recurring = $schedule->recurring;
        $addon = $schedule->addon;
        $defaultChecked = $schedule->defaultChecked;
        $description = $schedule->description;
        $thisTaxAmount = floatval($scheduleAmount) - floatval($schedulePreTaxAmount);
        $thisTax = "$" . $thisTaxAmount;
        $thisSubTotal = $schedulePreTaxAmount;
        $thisTotal = $scheduleAmount;
        
        if( $profitCenter == "Smgrptrn" || $profitCenter == "SMGRPTRN" ){
            $scheduleName = "Small Group Training";
        } else {
            $scheduleName = $description;
        }

        if( $scheduleName == "" ){
            $scheduleName = $profitCenter;
        }


        //add a custom class for even/odd rows
        $rowclass = "";
        if ( $i % 2 == 0 ) {
        $rowclass = "even";
        } else {
        $rowclass = "odd";
        }


      if ($scheduleAmount){


            $summary .= '
			<tr class="icart-summary-table-' . $rowclass . '">
				<td>' . $scheduleName . '</td>



				<td>' . $thisTotal . '</td>
			</tr>
			';


        }
        $i++;



    }
      $summary .= '
        </table>';
      return $tableHeader . $summary;
  } else {
      return false;
  }



}



// returns the extra profit centers in comma list
function ABCExtraProfitCenters( $planArray ) {
  $extraProfitCenters = "";
  if ( $planArray->paymentPlan->schedules ) {
    $i = 0;
    foreach ( $planArray->paymentPlan->schedules as $schedule ) {
        $addon = $schedule->addon;
        $defaultChecked = $schedule->defaultChecked;
        $profitCenter = $schedule->profitCenter;
        if( $addon == "true" && $defaultChecked == "true"){
            if( $i != 0){
            $extraProfitCenters .= ",";
            }
            $extraProfitCenters .= $profitCenter;
          $i++;
        }

    }
      return $extraProfitCenters;
  } else {
      return false;
  }



}




//add iCart category to Elementor elements sidebar
function add_elementor_widget_categories( $elements_manager ) {

	$elements_manager->add_category(
		'icart-category',
		[
			'title' => __( 'iCart', 'icart' ),
			'icon' => 'fa fa-shopping-bag',
		]
	);

}
add_action( 'elementor/elements/categories_registered', 'add_elementor_widget_categories' );


/*
Admin settings
*/
function iCart_settings_init() {
	//register the admin iCart settings
	//default club number. By default this is set to the sandbox club: 9003
	add_option( 'iCart_abc_clubNumber', '9003' );
	register_setting( 'iCart_options_group', 'iCart_abc_clubNumber', 'iCart_callback' );

	//accepts a comma separated list of clubs, e.g. 1223,2332,2331
	add_option( 'iCart_abc_multiClubs', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_multiClubs', 'iCart_callback' );

	//the main URL of the client's website, e.g. https://bigjoesfitness.com.  This is optional and provides a way to send the user back to the main website, if necessary.
	add_option( 'iCart_abc_clubUrl', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_clubUrl', 'iCart_callback' );

	//The default club name
	add_option( 'iCart_abc_clubName', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_clubName', 'iCart_callback' );

    // an array of all clubs
	add_option( 'iCart_abc_clubArray', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_clubArray', 'iCart_callback' );

    // an array of all plans
	add_option( 'iCart_abc_planArray', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_planArray', 'iCart_callback' );

    //default campaignId
    add_option( 'iCart_abc_campaignId', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_campaignId', 'iCart_callback' );

    //default promoCode
    add_option( 'iCart_abc_promoCode', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_promoCode', 'iCart_callback' );

    //default colors
    add_option( 'iCart_abc_color_dark', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_color_dark', 'iCart_callback' );

    add_option( 'iCart_abc_color_light', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_color_light', 'iCart_callback' );

    add_option( 'iCart_abc_color_primary1', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_color_primary1', 'iCart_callback' );

    add_option( 'iCart_abc_color_primary2', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_color_primary2', 'iCart_callback' );

    add_option( 'iCart_abc_color_default_amenities', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_color_default_amenities', 'iCart_callback' );

    add_option( 'iCart_privacy_link', '' );
	register_setting( 'iCart_options_group', 'iCart_privacy_link', 'iCart_callback' );

    add_option( 'iCart_google_ua', '' );
	register_setting( 'iCart_options_group', 'iCart_google_ua', 'iCart_callback' );

    add_option( 'iCart_google_gtm', '' );
	register_setting( 'iCart_options_group', 'iCart_google_gtm', 'iCart_callback' );

    add_option( 'iCart_cron_schedule', '' );
	register_setting( 'iCart_options_group', 'iCart_cron_schedule', 'iCart_callback' );

    add_option( 'iCart_abc_webhook', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_webhook', 'iCart_callback' );

}





//Register Options Page
function iCart_register_options_page() {
	add_menu_page( 'iCart', 'iCart', 'manage_options', 'iCart', 'iCart_options_page', 'dashicons-products', 99 );

    //add_submenu_page('iCart', 'Ingest Club', 'Ingest Club', 'manage_options', 'iCart_ingest-club_page' );
    //add_submenu_page('iCart', 'Resync Plan Data', 'Resync Plan Data', 'manage_options', 'iCart-resync','iCart_plan_resync_page', 5 );
    add_submenu_page('iCart', 'Ingest Club Data', 'Ingest Club Data', 'manage_options', 'iCart-getplans','iCart_get_plans_page', 3 );



}


//iCart settings page (settings:iCart)
function iCart_options_page() {
   // if($_GET['planupdate'] || $_POST['planupdate'] == "yes" || get_option('iCart_abc_clubNumber') == ""){
       // update_option( 'iCart_abc_clubArray', ABCClubArray() );
   // }
     //update_option( 'iCart_abc_clubArray', ABCClubArray() );
    /*if($_GET['planupdate'] || $_POST['planupdate'] == "yes" || get_option('iCart_abc_clubNumber') == ""){

        update_option( 'iCart_abc_planArray', ABCClubPlanArrayUpdate() );

    }*/
	?>
<div class="iCartOptionsContainer">
	<div align="center">
		<img src="https://v.fastcdn.co/u/1f6b9b35/48334400-0-Icart-logo.png" alt="iCart" width="130">
	</div>
	<div class="iCartAdminForm">
	  <form method="post" action="options.php">
		  <?php settings_fields( 'iCart_options_group' ); ?>
		<fieldset>
		  <legend><span class="dashicons dashicons-admin-generic"></span> Main Settings</legend>

			<label for="iCart_abc_clubNumber">Default Club Number*:</label>
			<p style="font-size:.8em"><em>This is the default club number to be used for populating the plan widgets. Additional clubs can be specified below.</em></p>
		  <input type="text" id="iCart_abc_clubNumber" name="iCart_abc_clubNumber" value="<?php echo get_option('iCart_abc_clubNumber'); ?>" placeholder="e.g. 1234" required />

			<label for="iCart_abc_clubName">Default Club Name*:</label>
			<p style="font-size:.8em"><em>The name that will be used by default. Example: Joe's Fitness</em></p>
		  <input type="text" id="iCart_abc_clubName" name="iCart_abc_clubName" value="<?php echo get_option('iCart_abc_clubName'); ?>" placeholder="Joe's Fitness" required />
		</fieldset>
		<fieldset>
		  <label for="iCart_abc_multiClubs">Multiple locations:</label>
		  <p style="font-size:.8em"><em>If your club has multiple locations, enter all of the ABC club numbers as a commma separated list (including the default club).  Example: 1234,2311,4122,3444,4222   </em></p>
		  <input type="text" id="iCart_abc_multiClubs" name="iCart_abc_multiClubs" value="<?php echo get_option('iCart_abc_multiClubs'); ?>" placeholder="e.g. 1111,2222,3333,4444" />
		  <label for="iCart_abc_clubUrl">Club Website URL:</label>
			<p style="font-size:.8em"><em>The original primary url for the fitness club's main website. Example: https://joesfitness.com NOT https://join.joesfitness.com</em></p>
		  <input type="text" id="iCart_abc_clubUrl" name="iCart_abc_clubUrl" value="<?php echo get_option('iCart_abc_clubUrl'); ?>" placeholder="https://yourmainurl.com"  />

            <label for="iCart_abc_clubUrl">Default campaignId:</label>
			<p style="font-size:.8em"><em>Enter a default ABC campaignId if one is required. Leave blank if no campaignId is needed.</em></p>
            <input type="text" id="iCart_abc_campaignId" name="iCart_abc_campaignId" value="<?php echo get_option('iCart_abc_campaignId'); ?>"   />

             <label for="iCart_abc_clubUrl">Default promoCode:</label>
			<p style="font-size:.8em"><em>Enter a default ABC promoCode if desired. This will override pricing on any page that takes a promoCode.  Leave blank if no promoCode is needed.</em></p>
            <input type="text" id="iCart_abc_promoCode" name="iCart_abc_promoCode" value="<?php echo get_option('iCart_abc_promoCode'); ?>"   />

              <label for="iCart_abc_webhook">Zapier Webhook:</label>
			<p style="font-size:.8em"><em>Insert the web hook URL for a custom Zap, if applicable.  Otherwise it will use the default zapier webook.</em></p>
            <input type="text" id="iCart_abc_webhook" name="iCart_abc_webhook" value="<?php echo get_option('iCart_abc_webhook'); ?>"   />




		  <!--<legend><span class="dashicons dashicons-admin-generic"></span> Default Page Overrides</legend>
		  <p><strong>Use these controls if you want to override the default URLs.</strong></p>
		  <label for="iCart_abc_location_page">Locations Page (for clubs with multiple locations):</label>
		  <input type="text" id="iCart_abc_location_page" name="iCart_abc_location_page" value="<?php //echo get_option('iCart_abc_location_page'); ?>" placeholder="Default is /locations"  />
		  <label for="iCart_abc_plan_page">Membership Plan Page:</label>
		  <input type="text" id="iCart_abc_plan_page" name="iCart_abc_plan_page" value="<?php //echo get_option('iCart_abc_plan_page'); ?>" placeholder="Default is /plans"  />
		  <label for="iCart_abc_checkout_page">Checkout Page:</label>
		  <input type="text" id="iCart_abc_checkout_page" name="iCart_abc_checkout_page" value="<?php //echo get_option('iCart_abc_checkout_page'); ?>" placeholder="Default is /checkout"  />
		  <label for="iCart_abc_thanks_page">Thank You Page:</label>
		  <input type="text" id="iCart_abc_thanks_page" name="iCart_abc_thanks_page" value="<?php //echo get_option('iCart_abc_thanks_page'); ?>" placeholder="Default is /thanks"  />


   add_option( 'iCart_abc_color_dark', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_color_dark', 'iCart_callback' );

    add_option( 'iCart_abc_color_light', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_color_light', 'iCart_callback' );

    add_option( 'iCart_abc_color_primary1', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_color_primary1', 'iCart_callback' );

    add_option( 'iCart_abc_color_primary2', '' );
	register_setting( 'iCart_options_group', 'iCart_abc_color_primary2', 'iCart_callback' );


-->
		</fieldset>

          <fieldset>
		  <legend><span class="dashicons dashicons-admin-generic"></span>Tracking</legend>
            
            <label for="iCart_google_ua">Google Universal Analytics ID</label>
            <input type="text" id="iCart_google_ua" name="iCart_google_ua" value="<?php echo get_option('iCart_google_ua'); ?>" placeholder="UA-XXXXX"   />
              
            <label for="iCart_google_gtm">Google Tag Manager ID</label>
            <input type="text" id="iCart_google_gtm" name="iCart_google_gtm" value="<?php echo get_option('iCart_google_gtm'); ?>" placeholder="GTM-XXXXX"   />
            

		</fieldset>
          <fieldset>
		  <legend><span class="dashicons dashicons-admin-generic"></span> Brand Hex Colors</legend>
            <p>Use hexidecimal values with hash tag (e.g. #f9f9f9</p>
            <label for="iCart_abc_color_dark">Dark Color</label>
			<p style="font-size:.8em"><em>Use black or a very dark color.</em></p>
            <input type="text" id="iCart_abc_color_dark" name="iCart_abc_color_dark" value="<?php echo get_option('iCart_abc_color_dark'); ?>"   />
            <label for="iCart_abc_color_light">Light Color</label>
			<p style="font-size:.8em"><em>Use white or a very light color.</em></p>
            <input type="text" id="iCart_abc_color_light" name="iCart_abc_color_light" value="<?php echo get_option('iCart_abc_color_light'); ?>"   />
            <label for="iCart_abc_color_primary1">Primary Color 1</label>
			<p style="font-size:.8em"><em>A bright color.</em></p>
            <input type="text" id="iCart_abc_color_primary1" name="iCart_abc_color_primary1" value="<?php echo get_option('iCart_abc_color_primary1'); ?>"   />
          <label for="iCart_abc_color_primary2">Primary Color 2</label>
			<p style="font-size:.8em"><em>A bright color.</em></p>
            <input type="text" id="iCart_abc_color_primary2" name="iCart_abc_color_primary2" value="<?php echo get_option('iCart_abc_color_primary2'); ?>"   />



		</fieldset>
		<?php submit_button(); ?>
	  </form>
	</div>
</div>

<?php


}


//iCart Plan Resync (settings: Resync Plan Data )
function iCart_plan_resync_page() {

	?>
<div class="iCartOptionsContainer">
	<div align="center">
		<img src="https://v.fastcdn.co/u/1f6b9b35/48334400-0-Icart-logo.png" alt="iCart" width="130">
	</div>
	<div class="iCartAdminForm">
        <?php
        if($_POST['resync']){
            echo '<div style="padding:20px; margin:10px; border:1px solid green; color:darkgreen;">';

            echo ABCPlanResync();

            echo '</div>';
        }
        ?>
	  <form method="post" action="">
		  <?php settings_fields( 'iCart_options_group' ); ?>
		<fieldset>
		  <legend><span class="dashicons dashicons-admin-generic"></span> Resync ABC Plan Data</legend>
		  <p><em>This will update the plan pricing and term information for all of this club's published plans. Makes sure you back up the WordPress data first by going to <a href="export.php" target="_blank">Tools:Export</a> and exporting all content (in case something goes awry and it needs to be restored).</em></p>
            <p style="font-weight:bold"><input type="checkbox" required name="understand"> Content has been backed up using Tools:Export.</p>
            <p>
            <input name="resync" type="submit" value="Resync Plan Data"></p>
		</fieldset>

	  </form>
	</div>
</div>

<?php


}

//iCart Club Ingest (settings: Ingest Club Data )
function iCart_get_plans_page() {

	?>
<div class="iCartOptionsContainer">
	<div align="center">
		<img src="https://v.fastcdn.co/u/1f6b9b35/48334400-0-Icart-logo.png" alt="iCart" width="130">
	</div>
	<div class="iCartAdminForm">
        <?php
        if($_POST['clubNumber'] && $_POST['promocode']){
            echo '<div style="padding:20px; margin:10px; border:1px solid green; color:darkgreen;">';

            echo ABCPromoCodeIngest($_POST['clubNumber'], $_POST['promocode']);

            echo '</div>';
        }  else if($_POST['clubNumber']){
            echo '<div style="padding:20px; margin:10px; border:1px solid green; color:darkgreen;">';

            echo ABCClubIngest($_POST['clubNumber']);

            echo '</div>';
        }
        ?>
	  <form method="post" action="">
		  <?php settings_fields( 'iCart_options_group' ); ?>
		<fieldset>
		  <legend><span class="dashicons dashicons-admin-generic"></span> Ingest Club Data</legend>
		  <p><em>This will ingest a single club's data, plans, and promo plans. Posts will be marked as <i>draft</i> status and must be published after reviewing with the client.</em></p>

            <p>
                <label>Enter a club number:</label>
                <input type="text" required name="clubNumber">
            <p>
            <p>
                <label>Pull only plans with promocode (optional, leave blank to pull everything):</label>
                <input type="text" name="promocode">
            <p>
            <input name="resync" type="submit" value="Ingest Data"></p>
		</fieldset>

	  </form>
	</div>
</div>

<?php


}


//iCart Club Ingest (settings: Ingest Club Data )
function iCart_Plan_Configurator() {

	?>
<div class="iCartOptionsContainer">
	<div align="center">
		<img src="https://v.fastcdn.co/u/1f6b9b35/48334400-0-Icart-logo.png" alt="iCart" width="130">
	</div>
	<div class="iCartAdminForm">
        <?php
        if($_POST['clubNumber']){
            echo '<div style="padding:20px; margin:10px; border:1px solid green; color:darkgreen;">';

            echo ABCClubIngest($_POST['clubNumber']);

            echo '</div>';
        }
        ?>
	  <form method="post" action="">
		  <?php settings_fields( 'iCart_options_group' ); ?>
		<fieldset>
		  <legend><span class="dashicons dashicons-admin-generic"></span> Ingest Club Data</legend>
		  <p><em>This will ingest a single club's data, plans, and promo plans. Posts will be marked as <i>draft</i> status and must be published after reviewing with the client.</em></p>

            <p>
                <label>Enter a club number:</label>
                <input type="text" required name="clubNumber">
            <p>
            <input name="resync" type="submit" value="Ingest Data"></p>
		</fieldset>

	  </form>
	</div>
</div>

<?php


}

//custom additions to the wordpress admin bar
add_action('admin_bar_menu', 'icart_toolbar_items', 100);
function icart_toolbar_items($admin_bar){
    $admin_bar->add_menu( array(
        'id'    => 'icart',
        'title' => 'iCart',
        'href'  => '#',
        'meta'  => array(
            'title' => __('iCart'),            
        ),
    ));
    $admin_bar->add_menu( array(
        'id'    => 'icart-resync',
        'parent' => 'icart',
        'title' => 'Resync Plans',
        'href'  => '?resync=1',
        'meta'  => array(
            'title' => __('Resync Plans'),
            'class' => 'icart-resync-admin-bar'
        ),
    ));
 
}