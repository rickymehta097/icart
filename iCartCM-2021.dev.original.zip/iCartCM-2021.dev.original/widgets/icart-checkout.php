<?php

namespace iCart\ Widgets;
//get the  club number

if ( isset( $_GET[ 'club' ] ) ) {
    $clubNumber = $_GET[ 'club' ];
} else if ( isset( $_GET[ 'clubNumber' ] ) ) {
    $clubNumber = $_GET[ 'clubNumber' ];
} else if ( isset( $_POST[ 'clubNumber' ] ) ) {
    $clubNumber = $_POST[ 'clubNumber' ];
} else {
    $clubNumber = get_option( 'iCart_abc_clubNumber' );
}
//if form has been submitted, query the API

use Elementor\ Widget_Base;
use Elementor\ Controls_Manager;

if ( !defined( 'ABSPATH' ) )exit;
// Exit if accessed directly

/**
* iCart Checkout V2
*
* Elementor widget for iCart Checkout.
*
*/

class iCart_Checkout extends Widget_Base {
    public function get_name() {
        return 'iCart_Checkout';
    }

    public function get_title() {
        return __( 'iCart Checkout Version 2', 'icart-checkout' );
    }

    public function get_icon() {
        return 'fa fa-credit-card-alt';
    }

    public function get_categories() {
        return [ 'icart-category' ];
    }

    public function get_script_depends() {
        return [ 'icart-checkout' ];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'section_content', [
                'label' => __( 'Content', 'icart-checkout' ),
            ]
        );





        $this->add_control(
            'bankOption', [
                'label' => __( 'ACH for dues:', 'icart-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'optional',
                'options' => [

                    'optional' => __( 'Optional', 'icart-checkout' ),
                    'required' => __( 'Required', 'icart-checkout' ),
                    'hide' => __( 'Hide', 'icart-checkout' ),
                ],

            ]
        );

        $this->add_control(
            'humanVerification', [
                'label' => __( 'Human Verification:', 'icart-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hide', 'icart-checkout' ),
                    'show' => __( 'Show', 'icart-checkout' ),

                ],

            ]
        );

        $this->add_control(
            'driversLicenseDisplay', [
                'label' => __( 'Drivers License:', 'icart-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [
                    'hide' => __( 'Hide', 'icart-checkout' ),

                    'required' => __( 'Required', 'icart-checkout' ),
                    'optional' => __( 'Optional', 'icart-checkout' ),

                ],

            ]
        );
        $this->add_control(
            'genderDisplay', [
                'label' => __( 'Show Gender:', 'icart-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hide', 'icart-checkout' ),
                    'show' => __( 'Show', 'icart-checkout' )

                ],

            ]
        );
        $this->add_control(
            'homePhone', [
                'label' => __( 'Home Phone:', 'icart-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hidden', 'icart-checkout' ),
                    'required' => __( 'Required', 'icart-checkout' ),
                    'optional' => __( 'Optional', 'icart-checkout' )

                ],

            ]
        );
        $this->add_control(
            'country', [
                'label' => __( 'Country', 'icart-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'US',
                'options' => [

                    'US' => __( 'US', 'icart-checkout' ),
                    'CA' => __( 'CA', 'icart-checkout' )

                ],

            ]
        );
        $this->add_control(
            'showSalesPerson', [
                'label' => __( 'Show Salesperson Dropdown?', 'icart-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hide', 'icart-checkout' ),
                    'show' => __( 'Show', 'icart-checkout' )
                ],

            ]
        );
        $this->add_control(
            'addOns', [
                'label' => __( 'ABC Addons (optional)', 'icart-checkout' ),
                'description' => __( 'Comma separated ABC Addon Profit Center Codes', 'icart-checkout' ),
                'type' => Controls_Manager::TEXT,
            ]
        );
        $this->end_controls_section();

        //agreement check boxes
        $this->start_controls_section(
            'section_agreements',
            [
                'label' => __( 'Agreements', 'icart' ),
            ]
        );

        $this->add_control(
            'optIn', [
                'label' => __( 'Marketing opt-in check box:', 'icart-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'optional',
                'options' => [

                    'required' => __( 'Required', 'icart-checkout' ),
                    'optional' => __( 'Optional', 'icart-checkout' )

                ],

            ]
        );
        $this->add_control(
          'optInText',
                [
                  'label' => __( 'Marketing opt-in text', 'icart-checkout' ),
                  'type' => \Elementor\Controls_Manager::TEXTAREA,
                  'rows' => 7,
                  'default' => __( '', 'icart-checkout' ),
                  'placeholder' => __( 'By checking this box, you are agreeing to provide your mobile phone number and email address to receive calls, text messages, and/or email alerts from our club containing information about our products, events, or promotions. You can unsubscribe at any time. ', 'icart-checkout' ),
                ]
        );

        $this->add_control(
            'privacyLink', [
                'label' => __( 'Privacy policy link (optional)', 'icart-checkout' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => __( 'https://somewebsite.com/privacy', 'icart-checkout' ),
                'description' => __( 'Append a link to an external privacy policy to the end of the marketing opt-in text. Include the complete URL starting with https://', 'icart-checkout' ),
            ]
        );




        $this->add_control(
            'showAgreementTerms', [
                'label' => __( 'Agreement Terms check box:', 'icart-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hide', 'icart-checkout' ),
                    'show' => __( 'Required', 'icart-checkout' )

                ],

            ]
        );
        $this->add_control(
            'showAgreementNotes', [
                'label' => __( 'Agreement Notes check box:', 'icart-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hide', 'icart-checkout' ),
                    'show' => __( 'Required', 'icart-checkout' )

                ],

            ]
        );
        $this->add_control(
            'showABCPolicy', [
                'label' => __( 'ABC Privacy Policy check box:', 'icart-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hide', 'icart-checkout' ),
                    'show' => __( 'Required', 'icart-checkout' )

                ],

            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_style', [
                'label' => __( 'Style', 'icart-checkout' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'text_transform', [
                'label' => __( 'Text Transform', 'icart-checkout' ),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => __( 'None', 'icart-checkout' ),
                    'uppercase' => __( 'UPPERCASE', 'icart-checkout' ),
                    'lowercase' => __( 'lowercase', 'icart-checkout' ),
                    'capitalize' => __( 'Capitalize', 'icart-checkout' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $siteurl = get_option( 'siteurl' );
        //get the planId setting and pull the response from ABC
        //$planId = $settings[ 'planId' ];
        if ( isset( $_GET[ 'planId' ] ) ) {
            $planId = $_GET[ 'planId' ];
        } else if ( isset( $_POST[ 'planId' ] ) ) {
            $planId = $_POST[ 'planId' ];
        }
        if ( isset( $_GET[ 'club' ] ) ) {
            $clubNumber = $_GET[ 'club' ];
        } else if ( isset( $_POST[ 'clubNumber' ] ) ) {
            $clubNumber = $_POST[ 'clubNumber' ];

        }
        $planArray = ABCPlanArray( $clubNumber, $planId );
        //$totalContractValue = ABCTotalContractValue( $planArray );
        $agreementDescription = base64_decode( $planArray->paymentPlan->agreementDescription );
        $agreementNote = base64_decode( $planArray->paymentPlan->agreementNote );
        $agreementTerms = base64_decode( $planArray->paymentPlan->agreementTerms );
        $extraProfitCenters = ABCExtraProfitCenters( $planArray );
        $totalContractValue = ABCTotalContractValue( $planArray );
        $planValidation = $planArray->paymentPlan->planValidation;

        $agreementDescription = base64_decode( $planArray->paymentPlan->agreementDescription );
        $agreementNote = base64_decode( $planArray->paymentPlan->agreementNote );
        $agreementTerms = base64_decode( $planArray->paymentPlan->agreementTerms );


        //get country settings
        $country = "US";
        if($settings['country'] != ""){
          $country = $settings['country'];
        }
        if ( get_option( 'iCart_abc_clubName' ) && get_option( 'iCart_abc_clubName' ) != "" ) {
            $clubName = get_option( 'iCart_abc_clubName' );
        } else {
            $clubName = "this club";
        }

        ?>
<style>
    #icart-summary-column {
        display: none;
    }
    #screen-1{
        display:block;
    }

    #icart-checkout-column {
        margin: 0 auto;
    }

    #icart-checkout-longform-column {
        margin: 0 auto;
    }

    #elementor-popup-modal-iCartCheckoutPop .dialog-message {
        width: 640px;
        height: auto;
    }

    #elementor-popup-modal-iCartCheckoutPop {
        justify-content: center;
        align-items: center;
        pointer-events: all;
        background-color: rgba(0, 0, 0, .8);
    }

    #elementor-popup-modal-iCartCheckoutPop .dialog-close-button {
        display: block;
    }

    #elementor-popup-modal-iCartCheckoutPop .dialog-widget-content {
        box-shadow: 2px 8px 23px 3px rgba(0, 0, 0, 0.2);
    }

    .mfp-wrap .mfp-arrow,
    .mfp-wrap .mfp-close {
        background-color: transparent
    }

    .mfp-wrap .mfp-arrow:focus,
    .mfp-wrap .mfp-close:focus {
        outline-width: thin
    }

    .icart-popup-link {
        color: #0ca3ea !important;

        text-decoration: underline !important;

        cursor: pointer !important;
    }

    .icart-popup-link:hover {
        color: #022f44 !important;

        text-decoration: none !important;

        cursor: pointer !important;
    }

    .icart-popup {
        padding: 15px !important;
        box-sizing: border-box !important;
        line-height: 1.5em !important;
        font-size: 16px !important;
    }
    .icart-popup svg {
        width:120px;
        height:120px;
        margin:0 auto;
        margin-bottom:20px;
    }

    .elementor-location-popup {
        max-height: 650px;
    }

    .iCartCheckoutPopHeading {
        font-weight: normal;
        font-size: 19px;
        color: white;
        background: black;
        padding: 8px;
    }

    .checkboxColumn{
        float:left;
        text-align:left !important;
        margin-top:15px;
    }
    .privacyLink{
      color:dodgerblue;
      text-decoration:underline;
      cursor:pointer;
    }


    .checkboxColumn input[type=checkbox] {
	     cursor: pointer;
         width:22px;
         height:22px;

    }
    .badcheck{
       outline:2px solid red;
       outline-offset: 5px;
    }
    .icart-next-button, .icart-submit-button{
      display:block;
      float:right;
      color:white;
      background-color:dodgerblue !important;
      font-size:18px;
      border-radius:2px;
      box-shadow: 2px 5px 8px #ddd;
      border:1px solid #ccc !important;
      margin-top:25px;
      margin-bottom:10px;
      max-width:100px !important;
    }
    .icart-back-button{
      display:block;
      float:left;
      font-size:18px;
      background:#ccc !important;
      border:1px solid #ccc !important;
      padding:8px;
      color:#999;
      border-radius:2px;
      box-shadow: 2px 5px 8px #ddd;
      margin-top:25px;
      margin-bottom:10px;
      max-width:100px;
    }
    .icart-next-button:hover, .icart-submit-button:hover{
      display:inline-block;
      float:right;
      background:#333 !important;
    }


    <?php if ($_SESSION['icarterror'] && $_SESSION['icarterror'] != "") {

        ?>
    .tab {
            display: block;
        }

    #icart-summary-column {
            display: block;
        }
     fieldset{
        margin-top:20px;
    }



    .icart-next-button{
       display: none;
    }
    .icart-back-button{
       display: none;
    }



        <?php
    } //end if icart error

/*

#icart-checkout-form{
  display:none;
}
#icart-thanks{
  display:block;
}
.transaction-success{

    display:block;

}
*/


    ?>

</style>

<div data-elementor-type="popup" data-elementor-id="iCartCheckoutPop" class="elementor elementor-iCartCheckoutPop elementor-location-popup" data-elementor-settings="{&quot;open_selector&quot;:&quot;.termPop&quot;,&quot;triggers&quot;:[],&quot;timing&quot;:[]}">
    <div class="elementor-section-wrap">
        <section class="elementor-section elementor-top-section elementor-element elementor-element-12388fd elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="12388fd" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-f461d01" data-id="f461d01" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                            <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-3ea2b3b elementor-widget elementor-widget-heading" data-id="3ea2b3b" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default iCartCheckoutPopHeading"><?php echo $clubName;
                                            ?> Agreement Terms</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-8396209 elementor-widget elementor-widget-text-editor" data-id="8396209" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-text-editor icart-popup elementor-clearfix">

                                            <?php
                                            //var_dump( $agreementTerms );

                                            echo $agreementTerms;

                                            ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<div data-elementor-type="popup" data-elementor-id="iCartCheckoutPop" class="elementor elementor-iCartCheckoutPop elementor-location-popup" data-elementor-settings="{&quot;open_selector&quot;:&quot;.AbcPrivacyPop&quot;,&quot;triggers&quot;:[],&quot;timing&quot;:[]}">
    <div class="elementor-section-wrap">
        <section class="elementor-section elementor-top-section elementor-element elementor-element-12388fd elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="12388fd" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-f461d01" data-id="f461d01" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                            <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-3ea2b3b elementor-widget elementor-widget-heading" data-id="3ea2b3b" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default iCartCheckoutPopHeading">ABC Financial Privacy Policy</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-8396209 elementor-widget elementor-widget-text-editor" data-id="8396209" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-text-editor icart-popup elementor-clearfix">
                                            <div>
                                                <?php
                                            //scrape and output the privacy policy from ABC Financial
                                            $privacyUrl = 'https://abcfitness.com/privacy-policy/';
                                            $privacyClass = 'c-content';
                                            echo getHtmlContentByClass( $privacyUrl, $privacyClass );
                                            ?>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<div data-elementor-type="popup" data-elementor-id="iCartCheckoutPop" class="elementor elementor-iCartCheckoutPop elementor-location-popup" data-elementor-settings="{&quot;open_selector&quot;:&quot;.AbcTermsPop&quot;,&quot;triggers&quot;:[],&quot;timing&quot;:[]}">
    <div class="elementor-section-wrap">
        <section class="elementor-section elementor-top-section elementor-element elementor-element-12388fd elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="12388fd" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-f461d01" data-id="f461d01" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                            <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-3ea2b3b elementor-widget elementor-widget-heading" data-id="3ea2b3b" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default iCartCheckoutPopHeading">ABC Financial Terms &amp;
                                            Conditions</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-8396209 elementor-widget elementor-widget-text-editor" data-id="8396209" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-text-editor icart-popup elementor-clearfix">
                                            <div>
                                                <?php
                                            //scrape the ABC Financial Terms and Conditions Page
                                            $termsUrl = 'https://abcfitness.com/terms-conditions/';
                                            $termsClass = 'c-tabs-form__tabs-content-container';
                                            echo getHtmlContentByClass( $termsUrl, $termsClass );
                                            ?>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<div data-elementor-type="popup" data-elementor-id="iCartCheckoutPop" class="elementor elementor-iCartCheckoutPop elementor-location-popup" data-elementor-settings="{&quot;open_selector&quot;:&quot;.notePop&quot;,&quot;triggers&quot;:[],&quot;timing&quot;:[]}">
    <div class="elementor-section-wrap">
        <section class="elementor-section elementor-top-section elementor-element elementor-element-12388fd elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="12388fd" data-element_type="section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-f461d01" data-id="f461d01" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                            <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-3ea2b3b elementor-widget elementor-widget-heading" data-id="3ea2b3b" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default iCartCheckoutPopHeading"><?php echo $clubName;
                                            ?> Agreement Notes</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-8396209 elementor-widget elementor-widget-text-editor" data-id="8396209" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-text-editor icart-popup elementor-clearfix">

                                            <?php
                                            //var_dump( $agreementTerms );

                                            echo $agreementNote;

                                            ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<div class="transaction-success" style="display:none; margin:10px; padding:20px; color:#00aa1c; border:1px dotted #005b0f">
  <strong>Transaction successful!</strong> You are now a member of our club.
</div>
<form id="icart-checkout-form" action="" method="post" class="checkoutform" onSubmit="hideSubmit();">
    <!-- Payload dump: <?php echo $siteurl; echo var_dump($payload); ?> -->
    <div class="tab" id="screen-1">

        <?php if ( $_SESSION['icarterror'] ) {
                                                ?>

        <div style="color:#C00003; background:#FFDDDE; border: #C00003 1px solid; padding:20px; margin:20px;">
            <?php echo $_SESSION['icarterror'];
                                                ?>
        </div>
        <?php }
                                                ?>
        <fieldset>
            <legend class="thelegend">Contact</legend>

            <div class="formcolumn">
                <label>First Name</label>
                <input name="firstName" type="text" required class="input" id="firstName" placeholder="First Name" value="<?php echo $_POST['firstName']; ?>">
            </div>
            <div class="formcolumn">
                <label>Last Name</label>
                <input name="lastName" type="text" required class="input" id="lastName" placeholder="Last Name" value="<?php echo $_POST['lastName']; ?>">
            </div>
            <div style="clear:both"></div>
            <div class="formcolumn">
                <label>Email <span id="emailvalidationwarning" style="visibility:hidden; color:red; font-size:.8em">Please enter a valid email address.</span></label>
                <input name="email" type="email" required class="input" id="email" placeholder="Email" value="<?php echo $_POST['email']; ?>">

            </div>

            <div class="formcolumn">
                <label>Cell Phone <span id="cellPhonevalidationwarning" style="visibility:hidden; color:red; font-size:.8em">Please enter a 10 digit phone number.</span></label>
                <input name="cellPhone" type="tel" required class="input" id="cellPhone" placeholder="Cell Phone" value="<?php echo $_POST['cellPhone']; ?>">
            </div>

            <div style="clear:both"></div>




            <div class="checkboxColumn" style="width:8%; height:8%">

                <input type="checkbox" name="optIn" id="optIn" value="yes" <?php if ( $settings['optIn'] == 'required' ) { echo ' class="requiredCheck" '; } ?>>
            </div>
            <div class="checkboxColumn" style="width:90%; padding-left:2%">
              <?php

              if( $settings['optInText'] != "" ){
                echo $settings['optInText'];
              } else {
                echo "By checking this box, you are agreeing to provide your mobile phone number and email address to receive calls, text messages, and/or email alerts from $clubName containing information about our products, events, or promotions. You can unsubscribe at any time. ";
              }

              if( $settings['privacyLink'] != "" ){
                $privacyLink = $settings['privacyLink'];
                ?>
                 Read our <span class="privacyLink" onClick='window.open("<?php echo $privacyLink; ?>", "_blank", "toolbar=no,scrollbars=yes,resizable=yes,top=100,left=600,width=550,height=600")'>privacy policy</span> for more information.
                <?php
              }
              ?>

            </div>
            <input name="middleInitial" type="hidden" class="input" value="" maxlength="1">
            <?php

            $isTodayBillingSameAsDraft = "true";

            ?>
            <input type="hidden" name="isTodayBillingSameAsDraft" value="<?php echo $isTodayBillingSameAsDraft; ?>">
            <input type="hidden" name="extraProfitCenters" value="<?php echo $extraProfitCenters; ?>">
            <?php
                                                if ( $_GET[ 'campaignId' ] ) {
                                                    $campaignId = $_GET[ 'campaignId' ];
                                                } else if ( $_REQUEST[ 'campaignId' ] ) {
                                                    $campaignId = $_REQUEST[ 'campaignId' ];
                                                } else if ( get_option( 'iCart_abc_campaignId' ) && get_option( 'iCart_abc_campaignId' ) != "" ) {
                                                    $campaignId = get_option( 'iCart_abc_campaignId' );
                                                } else {
                                                    $campaignId = "";
                                                }

                                                ?>
            <?php
                                                $findme = "/es/";
                                                $searchthis = $_SERVER[HTTP_HOST] . $_SERVER[REQUEST_URI];
                                                $pos = strpos( $searchthis, $findme );
                                                $language = "English";

                                                if ( $pos === false ) {
                                                    $language = "English";
                                                } else {
                                                    $language = "Spanish";
                                                }
                                                ?>

            <input name="campaignId" type="hidden" class="input" value="<?php echo $campaignId; ?>" maxlength="1">

            <input name="clubNumber" type="hidden" class="input" id="clubNumber" value="<?php echo $clubNumber; ?>">
            <input name="planId" type="hidden" class="input" value="<?php echo $_GET['planId']; ?>">
            <input name="planValidation" type="hidden" class="input" value="<?php echo $planValidation; ?>">
            <div style="clear:both"></div>
            <button type="button" onclick="nextScreen('screen-1', 'screen-2')" class="icart-next-button">Next ▶︎</button>
            <div style="clear:both"></div>
        </fieldset>
    </div>
    <div class="tab" id="screen-2">
        <fieldset>
            <legend>Member Details</legend>
            <div style="width:70%; float:left">
                <label>Street Address</label>
                <input name="addressLine1" type="text" required class="input" value="<?php echo $_POST['addressLine1']; ?>">
            </div>
            <div style="width:30%; float:left">
                <label>Apt#</label>
                <input name="addressLine2" type="text" class="input" value="<?php echo $_POST['addressLine2']; ?>">
            </div>
            <div style="clear:both"></div>
            <div class="formcolumn" style="width:50%">
                <label>City</label>
                <input name="city" type="text" required class="input" placeholder="city" value="<?php echo $_POST['city']; ?>">
            </div>
            <div class="formcolumn" style="width:35%">
              <?php if($country == "CA") { ?>
              <label>Province</label>
                <select name="state" class="input" required>
                  <option value="AB">Alberta</option>
                	<option value="BC">British Columbia</option>
                	<option value="MB">Manitoba</option>
                	<option value="NB">New Brunswick</option>
                	<option value="NL">Newfoundland and Labrador</option>
                	<option value="NS">Nova Scotia</option>
                	<option value="ON">Ontario</option>
                	<option value="PE">Prince Edward Island</option>
                	<option value="QC" selected>Quebec</option>
                	<option value="SK">Saskatchewan</option>
                	<option value="NT">Northwest Territories</option>
                	<option value="NU">Nunavut</option>
                	<option value="YT">Yukon</option>
                </select>
              <?php } else { ?>
                <label>State</label>
                <select name="state" class="input" required>
                    <option value="">Please Select</option>
                    <?php if ( $_POST['state'] ) {
                                                    ?>
                    <option value="<?php echo $_POST['state']; ?>" selected><?php echo $_POST['state'];
                                                    ?></option>
                    <?php }
                                                    ?>
                    <option value="AL">Alabama</option>
                    <option value="AK">Alaska</option>
                    <option value="AZ">Arizona</option>
                    <option value="AR">Arkansas</option>
                    <option value="CA">California</option>
                    <option value="CO">Colorado</option>
                    <option value="CT">Connecticut</option>
                    <option value="DE">Delaware</option>
                    <option value="DC">District Of Columbia</option>
                    <option value="FL">Florida</option>
                    <option value="GA">Georgia</option>
                    <option value="HI">Hawaii</option>
                    <option value="ID">Idaho</option>
                    <option value="IL">Illinois</option>
                    <option value="IN">Indiana</option>
                    <option value="IA">Iowa</option>
                    <option value="KS">Kansas</option>
                    <option value="KY">Kentucky</option>
                    <option value="LA">Louisiana</option>
                    <option value="ME">Maine</option>
                    <option value="MD">Maryland</option>
                    <option value="MA">Massachusetts</option>
                    <option value="MI">Michigan</option>
                    <option value="MN">Minnesota</option>
                    <option value="MS">Mississippi</option>
                    <option value="MO">Missouri</option>
                    <option value="MT">Montana</option>
                    <option value="NE">Nebraska</option>
                    <option value="NV">Nevada</option>
                    <option value="NH">New Hampshire</option>
                    <option value="NJ">New Jersey</option>
                    <option value="NM">New Mexico</option>
                    <option value="NY">New York</option>
                    <option value="NC">North Carolina</option>
                    <option value="ND">North Dakota</option>
                    <option value="OH">Ohio</option>
                    <option value="OK">Oklahoma</option>
                    <option value="OR">Oregon</option>
                    <option value="PA">Pennsylvania</option>
                    <option value="RI">Rhode Island</option>
                    <option value="SC">South Carolina</option>
                    <option value="SD">South Dakota</option>
                    <option value="TN">Tennessee</option>
                    <option value="TX">Texas</option>
                    <option value="UT">Utah</option>
                    <option value="VT">Vermont</option>
                    <option value="VA">Virginia</option>
                    <option value="WA">Washington</option>
                    <option value="WV">West Virginia</option>
                    <option value="WI">Wisconsin</option>
                    <option value="WY">Wyoming</option>
                </select>
                <?php }  ?>
            </div>
            <div class="formcolumn" style="width:15%">
                <label>Zip</label>
                <input name="zipCode" type="text" required class="input" placeholder="Zip" value="<?php echo $_POST['zipCode']; ?>">
            </div>
            <div style="clear:both"></div>
            <div class="formcolumn">
                <label>Birthday ( MM/DD/YYYY )</label>
                <input type="text" name="birthday" id="birthday" value="<?php echo $_POST['birthday']; ?>" placeholder="MM/DD/YYYY" required>
            </div>
            <div class="formcolumn">
                <?php
                                                    // show or hide drivers license field
                                                    if ( $settings['driversLicenseDisplay'] != "hide" ) {
                                                        ?>
                <label for="driversLicense">Driver's License #:</label>
                <input type="text" id="driversLicense" name="driversLicense" value="<?php echo $_POST['driversLicense']; ?>" <?php if( $settings['driversLicenseDisplay'] == "required"){ echo "required"; } ?>>


                <?php
              }
            ?>
            </div>
            <?php

        if( $settings['homePhone'] != "hide" ) {
          ?>
                <div class="formcolumn">

                    <label>Home Phone <span id="homePhonevalidationwarning" style="visibility:hidden; color:red; font-size:.8em">Please enter a 10 digit phone number.</span></label>
                <input name="homePhone" type="text" <?php if ( $settings['homePhone'] == "required") { echo "required"; } ?> class="input" id="homePhone" placeholder="Home Phone" value="<?php echo $_POST['homePhone']; ?>">
                </div>
                <div style="clear:both"></div>

                <?php
          }
          ?>
            <div style="clear:both"></div>
            <input name="country" type="hidden" class="input" value="<?php echo $country; ?>">


            <?php

      if( $settings['genderDisplay'] == "show" ) {
      ?>
            <div class="formcolumn">
                <label>Your Gender</label>
                <select id="gender" name="gender">
                    <option value="Unknown" <?php if( !isset ($_POST['gender'])){ echo "selected"; } ?>>Your Gender</option>
                    <option value="Male" <?php if( $_POST['gender'] == "Male"){ echo "selected"; } ?>>Male</option>
                    <option value="Female" <?php if( $_POST['gender'] == "Female"){ echo "selected"; } ?>>Female</option>
                </select>
            </div>

            <?php
      } else {
      ?>

            <input name="gender" type="hidden" class="input" value="Unknown">
            <?php
      }
      ?>

            <?php

      if( $settings['showSalesPerson'] == "show" ) {
      ?>
            <div class="formcolumn">
                <select id="salesperson" name="salesperson">
                    <option value="">Salesperson (optional)</option>
                    <?php
                    $AbcUrl = "https://api.abcfinancial.com/rest/" . $clubNumber . "/employees/salespersons";
                    $thisData = array(
                        "clubNumber" => $clubNumber
                    );
                    $salesdata = json_decode(callApi("GET", $AbcUrl, $thisData), false);

                    foreach($salesdata->salespersons as &$salesperson){
                        echo '<option value = "' . $salesperson->employeeId . '">' . $salesperson->name . '</option>';
                    }
                    //var_dump($salesdata);
                ?>
                </select>
            </div>
            <?php
      } else {
      ?>
            <input type="hidden" id="salesperson" name="salesperson" value="">

            <?php
      }
      ?>
            <div style="clear:both"></div>
            <button type="button" onclick="prevScreen('screen-2','screen-1')" class="icart-back-button">◀ Back</button>
            <button type="button" onclick="nextScreen('screen-2','screen-3')" class="icart-next-button">Next ▶︎</button>
            <div style="clear:both"></div>
        </fieldset>
    </div>
    <div class="tab" id="screen-3">
        <fieldset>
            <legend>Credit Card Information</legend>
            <?php
    if( $settings['bankOption'] != "" ){
          $bankOption = $settings['bankOption'];
      } else {
          $bankOption = "optional";
      }


      //if($bankOption == "optional" || $bankOption == "required"){
         // echo "<p>Used for your down payment.</p>";
    //  }

      ?>

            <div class="formcolumn">
                <label>First Name</label>
                <input name="todayCcFirstName" type="text" required class="input" placeholder="First Name" value="<?php echo $_POST['todayCcFirstName']; ?>">
            </div>
            <div class="formcolumn">
                <label>Last Name</label>
                <input name="todayCcLastName" type="text" required class="input" placeholder="Last Name" value="<?php echo $_POST['todayCcLastName']; ?>">
            </div>
            <div style="clear:both"></div>
            <div class="formcolumn" style="width:20%">
                <label>Type</label>
                <select name="todayCcType" required>
                    <option value="visa" <?php if( $_POST['todayCcType'] == "visa"){echo "selected"; } ?>>Visa</option>
                    <option value="mastercard" <?php if( $_POST['todayCcType'] == "mastercard"){echo "selected"; } ?>>MasterCard</option>
                    <option value="americanexpress" <?php if( $_POST['todayCcType'] == "americanexpress"){echo "selected"; } ?>>AmEx</option>
                    <option value="discover" <?php if( $_POST['todayCcType'] == "discover"){echo "selected"; } ?>>Discover</option>
                </select>
            </div>
            <div class="formcolumn" style="width:80%">
                <label>Card Number</label>
                <input name="todayCcAccountNumber" type="text" required class="input" value="<?php echo $_POST['todayCcAccountNumber']; ?>">
            </div>
            <div style="clear:both"></div>
            <div class="formcolumn">
                <label>Expiration</label>
                <div class="formcolumn">
                    <select name="todayCcExpMonth" required>
                        <option value="">Month</option>
                        <?php if( $_POST['todayCcExpMonth']){ ?>
                        <option value="<?php echo $_POST['todayCcExpMonth']; ?>" selected><?php echo $_POST['todayCcExpMonth']; ?></option>
                        <?php } ?>
                        <option value="01">01</option>
                        <option value="02">02</option>
                        <option value="03">03</option>
                        <option value="04">04</option>
                        <option value="05">05</option>
                        <option value="06">06</option>
                        <option value="07">07</option>
                        <option value="08">08</option>
                        <option value="09">09</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                    </select>
                </div>
                <div class="formcolumn">
                    <select name="todayCcExpYear" required>
                        <option value="">Year</option>
                        <?php if( $_POST['todayCcExpYear']){ ?>
                        <option value="<?php echo $_POST['todayCcExpYear']; ?>" selected><?php echo $_POST['todayCcExpYear']; ?></option>
                        <?php } ?>
                        <option value="2020">2020</option>
                        <option value="2021">2021</option>
                        <option value="2022">2022</option>
                        <option value="2023">2023</option>
                        <option value="2024">2024</option>
                        <option value="2025">2025</option>
                        <option value="2026">2026</option>
                        <option value="2027">2027</option>
                        <option value="2028">2028</option>
                        <option value="2029">2029</option>
                        <option value="2030">2030</option>
                        <option value="2031">2031</option>
                    </select>
                </div>
                <div style="clear:both"></div>
            </div>
            <div class="formcolumn">
                <div class="formcolumn">
                    <label>CVV</label>
                    <input name="todayCcCvvCode" type="text" required class="input" value="<?php echo $_POST['todayCcCvvCode']; ?>">
                </div>
                <div class="formcolumn">
                    <label>Billing Zip</label>
                    <input name="todayCcBillingZip" type="text" required class="input" value="<?php echo $_POST['todayCcBillingZip']; ?>">
                </div>
                <div style="clear:both"></div>
            </div>
            <div style="clear:both"></div>
            <?php


      if($bankOption == "optional"){
        ?>
            <div style="<?php if( $bankOption == "required" || $bankOption == "hide" ){ echo 'display:none;
                                                        '; } else { echo 'display:block;
                                                        '; } ?> border-top:1px dotted #ddd; padding-top:10px; margin-top:10px;">
                <label><strong>Select a payment method for your recurring membership dues:</strong></label>
                <?php if( get_option('iCart_abc_clubName') == "The Dynamic Fitness" ) { ?>

                <table>
                    <tr>
                        <td style="width:30px"><input name="sameBilling" type="radio" value="true" <?php if($_POST['sameBilling'] != "false") { echo " checked "; } ?> onClick="hideElement()"></td>
                        <td> Credit Card </td>
                    </tr>
                    <tr>
                        <td><input name="sameBilling" type="radio" value="false" <?php if($_POST['sameBilling'] == "false") { echo " checked "; } ?> onClick="showElement()"></td>
                        <td> Bank Account (ACH) <br>
                            <strong>*Select to earn a $5 Amazon Gift Certificate!</strong>
                        </td>
                    </tr>
                </table>
                <?php } else { ?>
                <table>
                    <tr>
                        <td style="width:30px"><input name="sameBilling" type="radio" value="true" <?php if($_POST['sameBilling'] != "false") { echo " checked "; } ?> onClick="hideElement()"></td>
                        <td> Credit Card </td>
                    </tr>
                    <tr>
                        <td><input name="sameBilling" type="radio" value="false" <?php if($_POST['sameBilling'] == "false") { echo " checked "; } ?> onClick="showElement()"></td>
                        <td> Bank Account (ACH) </td>
                    </tr>
                </table>
                <?php } ?>
            </div>
            <?php } else { ?>
            <input name="sameBilling" type="hidden" value="false">

            <?php } ?>
        </fieldset>
        <?php
      if($bankOption == "optional" || $bankOption == "required"){

      ?>

        <fieldset id="icartbankinfo" style="<?php if( $bankOption == "optional" ){ echo 'display:none;
                                                        '; } else { echo 'display:block;
                                                        '; } ?> margin-top:20px">
            <legend>Bank Info</legend>
            <div style="margin-top:8px; margin-bottom:14px; color:#999">Please enter your banking information for your <i>recurring dues</i>:</div>
            <div class="formcolumn">
                <label>First Name</label>
                <input name="draftAccountFirstName" type="text" class="input" placeholder="Account First Name" value="<?php echo $_POST['draftAccountFirstName']; ?>">
            </div>
            <div class="formcolumn">
                <label>Last Name</label>
                <input name="draftAccountLastName" type="text" class="input" placeholder="Account Last Name" value="<?php echo $_POST['draftAccountLastName']; ?>">
            </div>
            <div style="clear:both"></div>
            <div class="formcolumn" style="width:33%">
                <label>Type</label>
                <select name="draftAccountType" required>
                    <option value="checking" <?php if( $_POST['draftAccountType'] == "checking"){echo "selected"; } ?>>checking</option>
                    <option value="savings" <?php if( $_POST['draftAccountType'] == "savings"){echo "selected"; } ?>>savings</option>
                </select>
            </div>
            <div class="formcolumn" style="width:33%">
                <label>Routing #</label>
                <input name="draftAccountRoutingNumber" type="text" class="input" placeholder="Routing Number" value="<?php echo $_POST['draftAccountRoutingNumber']; ?>">
            </div>
            <div class="formcolumn" style="width:33%">
                <label>Account #</label>
                <input name="draftAccountNumber" type="text" class="input" placeholder="Account Number" value="<?php echo $_POST['draftAccountNumber']; ?>">
            </div>
            <div style="clear:both"></div>
        </fieldset>


        <?php }




      //Terms Popup and Checkbox
      if( $settings['showAgreementTerms'] == "show" ) {
      ?>

        <div style="clear:both"></div>
        <div class="checkboxColumn" style="width:8%; ">

            <input type="checkbox" name="agreementTerms" id="agreementTerms" value="yes" class="requiredCheck">
        </div>
        <div class="checkboxColumn" style="width:90%; padding-left:2%">

            I have read and agree to <?php echo $clubName; ?>'s <a class="termPop icart-popup-link"> terms &amp;
                conditions</a> for this membership agreement.

        </div>

        <?php
        }

        //Notes Popup and Checkbox
        if ( $settings['showAgreementNotes'] == "show" ) {
            ?>

        <div style="clear:both"></div>
        <div class="checkboxColumn" style="width:8%; ">

            <input type="checkbox" name="agreementNote" id="agreementNote" value="yes" class="requiredCheck">
        </div>
        <div class="checkboxColumn" style="width:90%; padding-left:2%">

           I have read and agree to the <a class="notePop icart-popup-link">notes</a> for this membership agreement.

        </div>

        <?php
        }

        //ABC Privacy Popup and Checkbox
        if ( $settings['showABCPolicy'] == "show" ) {
            ?>

        <div style="clear:both"></div>
        <div class="checkboxColumn" style="width:8%; ">

            <input type="checkbox" name="agreementPrivacy" id="agreementPrivacy" value="yes" class="requiredCheck">
        </div>
        <div class="checkboxColumn" style="width:90%; padding-left:2%">

            I have read and agree to the payment processor's <a class="AbcPrivacyPop icart-popup-link">privacy policy</a> and the <a class="AbcTermsPop  icart-popup-link">payment terms &amp; conditions</a>.

        </div>
        <div style="clear:both"></div>
        <?php
      }



       //show or hide human verification based on widget choice
        $humanVerification = $settings['humanVerification'];
        switch ($humanVerification) {
            case "show":

                $chars = str_split($clubNumber);
                $imageString = "";
                foreach($chars as &$char){
                    $imageString .= '<img src = "' . PLUGIN_URL . 'assets/images/' . $char . '.jpg" style = "width:35px; height:35px; float:left">';

                }

                echo '
                                                        <fieldset>
                                                        <legend>Human verification</legend>
                                                        <div class = "formcolumn" style = "width:auto">
                                                        <div class = "mixedNumbaz" style = "padding:10px; border:1px solid #ddd; margin-top:25px">

                                                        ' . $imageString . '
                                                        <div style = "clear:both"></div>

                                                        </div>

                                                        </div>
                                                        <div class = "formcolumn" style = "width:35%">

                                                        <label class = "humanVerify">Type the numbers:</label>

                                                        <input type = "text" name = "humanVerify" id = "humanVerify" required>
                                                        <div style = "clear:both"></div>

                                                        </div>
                                                        <div style = "clear:both"></div>
                                                        </fieldset>
                                                        ';



                //$plugins_url;

                //https://join.icart.ai/wp-content/uploads/2020/10/1.jpg

                break;

            case "hide":

                break;
        }
        ?>
        <div style="clear:both"></div>
        <button type="button" onclick="prevScreen('screen-3','screen-2')" class="icart-back-button">◀ Back</button>
        <input type="hidden" value="submitted" name="checkoutformsubmit">
        <input type="submit" value="Finish" class="icart-submit-button" name="submit" id="submitButton" style="float:right!important; max-width:100px; display:block">
        <img src="https://clubflow.us/wp-content/uploads/2020/09/ZZ5H1.gif" width="40" style="width:50px; display:none; padding:12px; margin-top:12px; background:dodgerblue; color:white; border:3px solid dodgerblue; border-radius:3px; box-shadow:1px 1px 5px #f9f9f9; float:right" id="button-standby">
        <div style="clear:both"></div>
    </div>



    <div style="clear:both;"></div>

</form>
<?php
$abcWebHook = "https://hooks.zapier.com/hooks/catch/1226098/orpfma9/";
$memberWebHook = "https://hooks.zapier.com/hooks/catch/1226098/og13pwq/";
if ( get_option( 'iCart_abc_webhook' ) ) {
  $abcWebHook = get_option( 'iCart_abc_webhook' );
}
if ( get_option( 'iCart_abc_memberhook' ) ) {
  $memberWebHook = get_option( 'iCart_abc_memberhook' );
}
$dateStamp = date( "Y-m-d" );
?>

<script>
    function getWidth() {
        return Math.max(
            document.body.scrollWidth,
            document.documentElement.scrollWidth,
            document.body.offsetWidth,
            document.documentElement.offsetWidth,
            document.documentElement.clientWidth
        );
    }


    //show or hide bank account info
    var elem = document.getElementById("icartbankinfo");

    function hideElement() {
        elem.style.display = 'none';
    };

    function showElement() {
        elem.style.display = 'block';
    };
    //contact zapier once
    var zapcontact = (function() {
        var executed = false;
        return function() {
            if (!executed) {
                executed = true;
                var firstName = document.getElementById("firstName").value;
                var lastName = document.getElementById("lastName").value;
                var email = document.getElementById("email").value;
                var mobilephone = document.getElementById("cellPhone").value;
                var optIn = "no";
                var optInCheckBox = document.getElementById("optIn");

                if (optInCheckBox.checked == true) {
                    optIn = "yes";
                } else {
                    optIn = "no";
                }
                var optIn = document.getElementById("optIn").value;
                var location = "<?php echo $_GET['club']; ?>";
                var language = "<?php echo $language; ?>";

                var zapurl = "<?php echo $abcWebHook; ?>?clubName=<?php echo get_option('iCart_abc_clubName'); ?>&firstname=" + firstName + "&lastname=" + lastName + "&email=" + email + "&location=" + location + "&mobilephone=" + mobilephone + "&campaign=<?php echo $thisCampaign; ?>&datestamp=<?php echo $datestamp; ?>" + "&optIn=" + optIn + "&language=" + language;
                fetch(zapurl);
            }
        };
    })();

    //show next screen after validation
    function nextScreen(thistab, nexttab) {


        // This function will display the specified tab of the form ...
        if(validateForm(thistab)){
      document.getElementById(thistab).style.display = "none";
		document.getElementById("icart-summary-column").style.display = "block";

      document.getElementById(nexttab).style.display = "block";

     } else {
       event.preventDefault();
     }
    }

    //show next screen after validation
    function prevScreen(thistab,prevtab) {
        // This function will display the specified tab of the form ...

        document.getElementById(thistab).style.display = "none";


        document.getElementById(prevtab).style.display = "block";


    }

    //validate fields in tab
    function validateForm(thisscreen) {
      //alert(thisscreen);
        // This function deals with validation of the form fields
        var i, valid = true;
            var validationscreen = document.getElementById(thisscreen); //x
            var requiredfield = validationscreen.querySelectorAll("[required]"); //y
            var checksArr = validationscreen.querySelectorAll(".requiredCheck");
        // A loop that checks every input field in the current tab:
         for (i = 0; i < requiredfield.length; i++) {
            // If a field is empty...
            if (requiredfield[i].value == "") {
                // add an "invalid" class to the field:
                requiredfield[i].className += " invalid";
                // and set the current valid status to false:
                valid = false;
            }
            if(requiredfield[i].type == 'email'){
                var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
                if(document.getElementById("email").value.match(mailformat)){
                    document.getElementById("emailvalidationwarning").style.visibility = 'hidden';
                } else {
                    requiredfield[i].className += " invalid";
                    valid = false;
                    document.getElementById("emailvalidationwarning").style.visibility = 'visible';
                }

            }
            if(requiredfield[i].name == 'cellPhone'){
                var phoneformat = /^\d{10}$/;
                if(document.getElementById("cellPhone").value.match(phoneformat)){
                    document.getElementById("cellPhonevalidationwarning").style.visibility = 'hidden';
                } else {
                    requiredfield[i].className += " invalid";
                    valid = false;
                    document.getElementById("cellPhonevalidationwarning").style.visibility = 'visible';
                }

            }
            if(requiredfield[i].name == 'homePhone'){
                var phoneformat = /^\d{10}$/;
                if(document.getElementById("homePhone").value.match(phoneformat)){
                    document.getElementById("homePhonevalidationwarning").style.visibility = 'hidden';
                } else {
                    requiredfield[i].className += " invalid";
                    valid = false;
                    document.getElementById("homePhonevalidationwarning").style.visibility = 'visible';
                }

            }
        }

        for (i = 0; i < checksArr.length; i++) {
            // If a field is empty...
            if (!checksArr[i].checked) {
                // add an "invalid" class to the field:
                checksArr[i].className += " badcheck invalid";
                checksArr[i].style.borderColor = 'red';
                // and set the current valid status to false:
                valid = false;
            }
        }

        // If the valid status is true, proceed
        if (valid) {
            zapcontact();
        }
        return valid; // return the valid status
    }

    function hideSubmit() {
        document.getElementById("submitButton").style.display = 'none';
        document.getElementById("button-standby").style.display = 'block';
    }

    function showSubmit() {
        document.getElementById("submitButton").style.display = 'block';
        document.getElementById("button-standby").style.display = 'none';
    }
	  function showSummary() {
        document.getElementById("icart-summary-column").style.display = "block";
    }

</script>



<?php
      }

      protected function _content_template() {

      }
  }
