<?php
namespace iCart\Widgets;

if ( isset( $_GET[ 'club' ] ) ) {
  $club = $_GET[ 'club' ];
} else if ( isset( $_GET[ 'clubNumber' ] ) ) {
  $club = $_GET[ 'clubNumber' ];
} else if ( isset( $_POST[ 'clubNumber' ] ) ) {
  $club = $_POST[ 'clubNumber' ];
} else {
  $club = get_option( 'iCart_abc_clubNumber' );
}

use Elementor\Group_Control_Background;
use Elementor\Utils;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use ElementorPro\Base\Base_Widget;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * iCart price-summary
 *
 * Elementor widget for iCart price-summary. Outputs a table containing the itemized price breakdown for one plan
 *
 */
class iCart_Price_Summary extends Widget_Base {

	public function get_name() {
		return 'iCart_Price_Summary';
	}

	public function get_title() {
		return __( 'iCart Price Summary', 'icart' );
	}

	public function get_icon() {
		return 'fa fa-tag';
	}
 
	public function get_categories() {
		return [ 'icart-category' ];
	}

	/**
	 * Register the widget controls.
	 *
	 */
	protected function _register_controls() {
		//get the ABC planIds
		//$planIds = ABCPlanIds(get_option('iCart_abc_clubNumber'));
		//$firstPlanName = array_values($planIds)[0];
		//$firstPlanId = array_key_first($planIds);

		//Register the iCart widget controls for the Elementor editor
		$this->start_controls_section(
			'section_abc_plan',
			[
				'label' => __( 'Content', 'icart' ),
			]
		);


		$this->add_control(
			'title',
			[
				'label' => __( 'Title Override', 'icart' ),
				'type' => Controls_Manager::TEXT,
			]
		);
    $this->add_control(
        'dueDateOverride', [
            'label' => __( 'Due date override', 'icart' ),
            'description' => __( 'Overrides the first due date presented on the price summary.', 'icart' ),
            'type' => Controls_Manager::TEXT,
        ]
    );
         $this->add_control(
            'priceDisplay', [
                'label' => __( 'Due today breakdown:', 'icart' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'abbreviated',
                'options' => [

                    'abbreviated' => __( 'Abbreviated', 'icart' ),
                    'full' => __( 'Full w/ $0 lines', 'icart' ),
                    'hide' => __( 'Hidden', 'icart' )
                ],

            ]
        );
        $this->add_control(
            'scheduleDisplay', [
                'label' => __( 'Schedule breakdown:', 'icart' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'abbreviated',
                'options' => [

                    'abbreviated' => __( 'Abbreviated schedule', 'icart' ),
                    'full' => __( 'Full schedule w/ $0 lines', 'icart' ),
                    'hide' => __( 'Hidden', 'icart' )
                ],

            ]
        );
         $this->add_control(
            'clubFeeDisplay', [
                'label' => __( 'Club fee breakdown:', 'icart' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'hide',
                'options' => [

                    'hide' => __( 'Hide', 'icart' ),
                    'show' => __( 'Show', 'icart' )
                    
                ],

            ]
        );
    $this->add_control(
        'agreementDescription', [
            'label' => __( 'ABC Agreement Description:', 'icart' ),
            'type' => Controls_Manager::SELECT,
            'default' => 'hide',
            'options' => [
                'hide' => __( 'Hide', 'icart' ),
                'show' => __( 'Show', 'icart' ),

            ],

        ]
    );
		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Style', 'icart' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'header_bg_color',
			[
				'label' => __( 'Header background', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Schemes\Color::get_type(),
					'value' => Schemes\Color::COLOR_2,
				],
				'selectors' => [
					'.icart-price-summary .title' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'header_padding',
			[
				'label' => __( 'Padding', 'icart' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'.icart-price-summary .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_heading_style',
			[
				'label' => __( 'Title', 'icart' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'heading_color',
			[
				'label' => __( 'Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'.icart-price-summary .title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',
				'selector' => '.icart-price-summary .title',
				'scheme' => Schemes\Typography::TYPOGRAPHY_1,
			]
		);
		$this->end_controls_section();
	}

	protected function render() {
		//get the iCart widget settings
		$settings = $this->get_settings_for_display();

		//get the planId setting and pull the response from ABC
		$planId = $settings['planId'];
        if(isset($_GET['planId'])){
			$planId = $_GET['planId'];
		}
        $club = get_option( 'iCart_abc_clubNumber' );
        if ( isset( $_GET[ 'club' ] ) ) {
          $club = $_GET[ 'club' ];
        }

		//Pass the club number setting and the planId to abc and retrieve the abc response array
		$planArray = ABCPlanArray($club, $planId);

		//retrieve the plan name from the abc response array
		$planName = ABCPlanName($planArray);

        $agreementDescription = base64_decode( $planArray->paymentPlan->agreementDescription );
        
         $clubFeeTotalAmount =  $planArray->paymentPlan->clubFeeTotalAmount;

		//retrieve the plan monthly price and tax from the abc response array
		$planPreTax = ABCSchedulePreTaxAmount($planArray);
		$planPostTax = ABCScheduleAmount($planArray);
		$planTax = $planPostTax - $planPreTax;

		//retrieve the amount due today from the abc response array
		$planDueToday = ABCDueToday($planArray);

		//retrieve the price summary for one plan
		
        if( $settings['priceDisplay'] == "full"){
		    $planSummaryTable = ABCPriceSummaryFull($planArray);
		} else {
            $planSummaryTable = ABCPriceSummary($planArray);
		} 
        
        
         //schedule summary table
        if( $settings['scheduleDisplay'] == "full"){
		    $scheduleSummaryTable = ABCScheduleSummaryFull($planArray);
		} else {
            $scheduleSummaryTable = ABCScheduleSummary($planArray);
		} 
        
        $clubfeeSummaryTable = ABCClubFeeSummary($planArray);
        
		//retrieve the due date for the next monthly payment
		$planDueDate = ABCDueDate($planArray);

        $frequency = ABCScheduleFrequency( $planArray );
		?>
			<div class="icart-price-summary">
			     <?php
        if ( isset( $_GET[ 'club' ] ) ) {
          $club = $_GET[ 'club' ];
        } else if ( isset( $_GET[ 'clubNumber' ] ) ) {
          $club = $_GET[ 'clubNumber' ];
        } else if ( isset( $_POST[ 'clubNumber' ] ) ) {
          $club = $_POST[ 'clubNumber' ];
        } else {
          $club = get_option( 'iCart_abc_clubNumber' );
        }
	   $clubArray = ABCClubInfo($club);
       echo ABCClubAddress($clubArray);

	 ?>
                
                <div class="plandetail">
				<h3 class="title">
					<?php
					if($settings['title']){
						echo $settings['title'];
					} else {
						echo "Plan: " . $planName;
					}
					?>
				</h3>
        <?php
        if ( $settings['agreementDescription'] == "show"){
          echo '<div class="agreementDescription">' . $agreementDescription . '</div>';
        }
        ?>

				<div class="icart-price-summary-table-container" style="<?php if( $settings['priceDisplay'] == "hide" ) { echo "display:none"; } ?>">
					<h4 class="icart-price-summary-table-subhead">
						Due Now
					</h4>
					<h5 class="icart-price-summary-table-detail"> <?php echo $planDueToday; ?> <span style="font-size:.7em; color:#999; cursor: pointer;" onClick="duetodayToggle()" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[<span id="todaySymbol">+</span>] Details</span></h5>

					<div id="icartduetoday" style="display:none;" class="icart-duenow-table">
					<?php echo $planSummaryTable; ?>
				    </div>
				</div>
				<div class="icart-price-summary-table-container" style="border-top:1px solid #ddd; padding-top:20px; margin-top;20px; <?php if( $settings['scheduleDisplay'] == "hide" ) { echo "display:none"; } ?>">
					<h4 class="icart-price-summary-table-subhead">
						Recurring Payments
					</h4>

                    <h5 class="icart-price-summary-table-detail"><?php echo $planPostTax; ?> <?php echo $frequency; ?> <span style="font-size:.7em; color:#999; cursor: pointer" onClick="recurringToggle()">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[<span id="recurringSymbol">+</span>] Details</span></h5>

                    <div id="icartrecurring" style="display:none;">
                        <p>
                            <?php
                                //check for golds
                                if ( $settings['dueDateOverride'] == ""){
                                    echo 'Starting ' . $planDueDate;
                                } else {
                                    echo $settings['dueDateOverride'];
                                }


                            ?>

                            </p>
                        <?php echo $scheduleSummaryTable; ?>
                    </div>
				</div>
                
                <div class="icart-price-summary-table-container" style="border-top:1px solid #ddd; padding-top:20px; margin-top;20px; <?php if( $settings['clubFeeDisplay'] == "hide" ) { echo "display:none"; } else { echo "display:block"; } ?>">
					<h4 class="icart-price-summary-table-subhead">
						Upcoming Fees
					</h4>

                    <h5 class="icart-price-summary-table-detail"><?php echo $clubFeeTotalAmount; ?> <span style="font-size:.7em; color:#999; cursor: pointer" onClick="clubfeeToggle()">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[<span id="clubfeeSymbol">+</span>] Details</span></h5>

                    <div id="icartclubfee" style="display:none;">
                        <?php echo $clubfeeSummaryTable; ?>
                        
                    </div>
				</div>
                </div>
			</div>
<script>
    function recurringToggle(){
        var icartrecurring = document.getElementById("icartrecurring");
        if(icartrecurring.style.display === "block"){
            icartrecurring.style.display = 'none';
            document.getElementById("recurringSymbol").innerHTML = '+';
        } else {
            icartrecurring.style.display = 'block';
            document.getElementById("recurringSymbol").innerHTML = '-';
        }
    }
    function clubfeeToggle(){
        var icartclubfee = document.getElementById("icartclubfee");
        if(icartclubfee.style.display === "block"){
            icartclubfee.style.display = 'none';
            document.getElementById("clubfeeSymbol").innerHTML = '+';
        } else {
            icartclubfee.style.display = 'block';
            document.getElementById("clubfeeSymbol").innerHTML = '-';
        }
    }
    function duetodayToggle(){
        var duetoday = document.getElementById("icartduetoday");
        if(duetoday.style.display == "block"){
            duetoday.style.display = 'none';
            document.getElementById("todaySymbol").innerHTML = '+';
        } else {
            duetoday.style.display = 'block';
            document.getElementById("todaySymbol").innerHTML = '-';
        }
    }


</script>
		<?php
	}

	protected function _content_template() {
	}
}
