# iCart Elementor Plugin

This plugin is a connector between ABC API and WordPress. API Documentation can be found here: https://abcfinancial.3scale.net/docs/