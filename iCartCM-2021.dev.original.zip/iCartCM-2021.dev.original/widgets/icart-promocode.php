<?php
namespace iCart\Widgets;
/**
 * iCart Promocode widget.
 *
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Group_Control_Background;
use Elementor\Utils;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use ElementorPro\Base\Base_Widget;

class iCart_Promo_Code extends Widget_Base {

	
	public function get_name() {
		return 'icart-promocode';
	}

	
	public function get_title() {
		return __( 'iCart Promocode Form', 'icart' );
	}

	
	public function get_icon() {
		return 'eicon-button';
	}

	 
	public function get_categories() {
		return [ 'icart-category' ];
	}

	
	public static function get_button_sizes() {
		return [
			'xs' => __( 'Extra Small', 'icart' ),
			'sm' => __( 'Small', 'icart' ),
			'md' => __( 'Medium', 'icart' ),
			'lg' => __( 'Large', 'icart' ),
			'xl' => __( 'Extra Large', 'icart' ),
		];
	}

	//Register widget controls
	protected function _register_controls() {
		// Retrieve the ABC plan list to prepoulate the planId select box settings
		
		
		$this->start_controls_section(
			'section_button',
			[
				'label' => __( 'Promocode Form', 'icart' ),
			]
		);
		
		

		$this->add_control(
			'button_text',
			[
				'label' => __( 'button_text', 'icart' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => __( 'Redeem', 'icart' ),
				
			]
		);
		//Form action for promocode form
		$this->add_control(
		'form_action',
			[
				'label' => __( 'Form Action URL', 'icart' ),
				'type' => Controls_Manager::URL,
				'dynamic' => [
					'active' => true,
				]
			]
		);
        $this->add_control(
			'clubNumber',
			[
				'label' => __( 'Club Number (optional)', 'icart' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'icart-promocode', 'icart' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'scheme' => Schemes\Typography::TYPOGRAPHY_4,
				'selector' => '{{WRAPPER}} .elementor-button',
			]
		);

		

		$this->start_controls_tabs( 'tabs_button_style' );

		$this->start_controls_tab(
			'tab_button_normal',
			[
				'label' => __( 'Normal', 'icart' ),
			]
		);

		$this->add_control(
			'button_text_color',
			[
				'label' => __( 'Text Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .elementor-button' => 'fill: {{VALUE}}; color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'background_color',
			[
				'label' => __( 'Background Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Schemes\Color::get_type(),
					'value' => Schemes\Color::COLOR_4,
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-button' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label' => __( 'Hover', 'icart' ),
			]
		);

		$this->add_control(
			'hover_color',
			[
				'label' => __( 'Text Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-button:hover, {{WRAPPER}} .elementor-button:focus' => 'color: {{VALUE}};',
					'{{WRAPPER}} .elementor-button:hover svg, {{WRAPPER}} .elementor-button:focus svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_background_hover_color',
			[
				'label' => __( 'Background Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-button:hover, {{WRAPPER}} .elementor-button:focus' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_hover_border_color',
			[
				'label' => __( 'Border Color', 'icart' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-button:hover, {{WRAPPER}} .elementor-button:focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_animation',
			[
				'label' => __( 'Hover Animation', 'icart' ),
				'type' => Controls_Manager::HOVER_ANIMATION,
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .elementor-button',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label' => __( 'Border Radius', 'icart' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .elementor-button',
			]
		);

		$this->add_responsive_control(
			'text_padding',
			[
				'label' => __( 'Padding', 'icart' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_section();
	}
	
	
	protected function render() {
		//get the iCart widget settings
		$settings = $this->get_settings_for_display();
		//get the planId setting from the widget select box
		
		
		
		
		$this->add_render_attribute( 'wrapper', 'class', 'elementor-button-wrapper' );
        
        
        $form_action = "";
		if ( ! empty( $settings['form_action']['url'] ) ) {
			
			$form_action = $settings['form_action']['url'];
		}  
        $button_text = "Go";
		if ( ! empty( $settings['button_text'] ) ) {
			
			$button_text = $settings['button_text'];
		}
        $clubfield = "";
        
		if ( ! empty( $settings['clubNumber'] ) ) {
			
			$clubNumber = $settings['clubNumber'];
            $clubfield = '<input type="hidden" name="clubNumber" value="' . $clubNumber . '">';
		}
        
        

		$this->add_render_attribute( 'icart-promocode', 'class', 'elementor-button' );
		$this->add_render_attribute( 'icart-promocode', 'role', 'icart-promocode' );

		
		?>
		
		
		



    <div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> style="max-width:290px; margin:0 auto;">
            <form action="<?php echo $form_action; ?>"  method="get">
                <div style="float:left; width:69%; vertical-align:middle; padding-right:1%">
                    <input type="text" name="promoCode" value="" placeholder="Promo code" required="" class="promoCode-field">
                </div>
                <div style="float:left; width:1%; vertical-align:middle; padding-right:1%">
                    
                </div>
                <div style="float:left; width:30%;  vertical-align:middle;">
                    <input type="submit" name="submit" value="<?php echo $button_text; ?>" class="elementor-button" style="width:100%">
                </div>
                <?php echo $clubfield; ?>
                <div style="clear:both"></div>
            </form>
    </div>
		<?php
	}

	
	protected function content_template() {
		
	}


	

	
}