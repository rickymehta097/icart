<?php

/**
 * The template for displaying all inner page's
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * 
 */

get_header(); ?>

<div>
    <h1>Page</h1>
    <?php the_content(); ?>
</div>

<?php get_footer(); ?>