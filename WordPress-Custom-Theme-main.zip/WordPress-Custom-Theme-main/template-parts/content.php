<h1>Blog Single Page</h1>

<div id="comments" class="comments-area">
    <?php comments_template(); ?>
</div>