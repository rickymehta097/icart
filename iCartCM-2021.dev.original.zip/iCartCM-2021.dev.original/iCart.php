<?php
/**
 * Plugin Name: iCart CM 2021 - DUPE FIX
 * Description: ABC Financial API Integration
 * Plugin URI: https://icart.ai/
 * Author: iCart
 * Version: 2021.1.4
 * Author URI: https://icart.ai/
 * Text Domain: icart
 *
 */
error_reporting(0);
$plugin_url = plugin_dir_url( __FILE__ );
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;


//iCart functions
include_once("functions.php");



/**
 * Main iCart Price Summary Class
 */
final class iCart_Price_Summary {

		public function __construct() {
			// Load translation
			add_action( 'init', array( $this, 'i18n' ) );

			// Init Plugin
			add_action( 'plugins_loaded', array( $this, 'init' ) );
		}

		public function i18n() {
			load_plugin_textdomain( 'icart-price-summary' );
		}

		public function init() {
			require_once( 'plugin.php' );
		}

}


/**
 * Main iCart Checkout Class
 */
final class iCart_Checkout {

	public function __construct() {
		// Load translation
		add_action( 'init', array( $this, 'i18n' ) );

		// Init Plugin
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}
	public function i18n() {
		load_plugin_textdomain( 'icart-checkout' );
	}


	public function init() {
		require_once( 'plugin.php' );
	}

}



/**
 * Main iCart promocode class
 *
 */
final class iCart_Promo_Code{
	public function __construct() {
		// Load translation
		add_action( 'init', array( $this, 'i18n' ) );

		// Init Plugin
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function i18n() {
		load_plugin_textdomain( 'icart-promocode' );
	}

	public function init() {
		require_once( 'plugin.php' );
	}

}


/**
 * Main iCart Plan Query
 *
 */
final class iCart_Plan_Query{
	public function __construct() {
		// Load translation
		add_action( 'init', array( $this, 'i18n' ) );

		// Init Plugin
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function i18n() {
		load_plugin_textdomain( 'icart-plan-query' );
	}

	public function init() {
		require_once( 'plugin.php' );
	}

}

/**
 * Main iCart Auto Checkout - Gets user fields from ABC Plan info
 *
 */
final class iCart_Auto_Checkout{
	public function __construct() {
		// Load translation
		add_action( 'init', array( $this, 'i18n' ) );

		// Init Plugin
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function i18n() {
		load_plugin_textdomain( 'icart-auto-checkout' );
	}

	public function init() {
		require_once( 'plugin.php' );
	}

}



// Instantiate iCart Elementor Widgets
new iCart_Price_Summary();
new iCart_Promo_Code();
//new iCart_Auto_Checkout();
new iCart_Checkout();
new iCart_Plan_Query();
